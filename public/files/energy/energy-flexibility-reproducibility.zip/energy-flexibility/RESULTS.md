# Evaluated results — ideal flexibility reference study

14 September 2026. Independent retrospective analysis of openly licensed NESO ND data. All 245 days from 1 May to 31 December 2025 are included. The underlying source, forecast, parameters and full result tables are supplied with the project.

## Decision finding

At **1,000 MW / 2,000 MWh**, the frozen solver-selected forecast LP reduced the daily adjusted ND peak by **532.10 MW on average**, versus **514.41 MW** for the simple forecast-window rule. That modest average advantage came with a material downside: this LP selection worsened the peak on **15 of 245 days (6.12%)**, while the rule worsened none in this particular test set. This does not establish that the rule can never worsen a peak, or that every equally optimal forecast-LP selection has the same adverse-day count.

The hindsight LP achieved **964.13 MW** average relief under the same ideal storage constraints. This upper-bound reference is supplied with actual demand and cannot be credited as a forecast policy. The gap illustrates the importance of demand-shape information; it is not a causal estimate of the value of one particular forecast improvement.

The evidence supports examining the reliability of a complete scheduling policy—including its selection among tied optimum solutions—alongside its average peak benefit. A planner should not choose a policy from the forecast optimization objective alone. The post-hoc diagnostic below shows that the original comparison does not isolate forecast error from numerical tie selection. No financial return, real dispatch recommendation or universally superior policy follows from this experiment.

| Policy at 1,000 MW and two hours | Mean relief MW | Median relief MW | 10th–90th percentile MW | Days worsened | Worst relief MW |
| --- | ---: | ---: | ---: | ---: | ---: |
| No additional flexibility | 0.00 | 0.00 | 0.00–0.00 | 0 / 245 | 0.00 |
| Forecast-window rule | 514.41 | 513.00 | 0.00–1,000.00 | 0 / 245 | 0.00 |
| Forecast LP | 532.10 | 557.89 | 93.77–925.35 | 15 / 245 | −943.28 |
| Hindsight LP, perfect-information bound | 964.13 | 1,000.00 | 848.97–1,000.00 | 0 / 245 | 686.00 |

The forecast LP's mean daily percentage reduction was 1.71%. Mean daily forecast MAE was 1,664.74 MW. These are different quantities: average percentage relief uses each day's peak as its denominator, while MAE measures interval-level forecast error. Numerical values rounding to 1,000 MW can be 0.00001 MW lower because of the documented second-stage tolerance.

## Post-hoc exploration: selecting among tied LP schedules

Adversarial review found a material sensitivity after the original evaluation had been inspected. At 1,000 MW/two hours, two additional forecast-only selections preserve both the original optimal forecast peak (within its unchanged tolerance) and the minimum absolute throughput. They minimize or maximize stored-energy holding time, measured as the area under the state-of-charge trajectory. Neither formula reads actual demand when choosing its schedule.

| Schedule selection, 1,000 MW/two hours | Mean realized relief MW | Days worsened | Worst realized relief MW |
| --- | ---: | ---: | ---: |
| Frozen SciPy/HiGHS reference selection | 532.10 | 15 / 245 | −943.28 |
| Post-hoc minimum holding-time selection | 532.10 | 15 / 245 | −943.28 |
| Post-hoc maximum holding-time selection | 595.82 | 0 / 245 | 0.00 |

The maximum holding-time selection changes average outturn relief by **63.72 MW** and removes the 15 adverse outcomes in this inspected period while retaining the same two primary forecast objectives. Consequently, the original adverse-day count cannot be attributed to the LP formulation or forecast error alone: the remaining choice among tied schedules matters. The minimum holding-time probe matches the frozen reference results here; this does not establish that the solver generally minimizes holding time.

These are **post-hoc exploratory diagnostics**, not an independently validated improvement or an operational recommendation. The third-objective formulas were investigated after seeing the primary evaluation; choosing the better-looking one now would select a policy using the test period. No primary schedule, result, forecast or parameter has been replaced. A final operational preference between equally optimal schedules needs a decision-based justification, development-period selection and a fresh evaluation period.

The probe's 245 daily records show zero differences in planned peak and throughput, zero physical constraint violations and a maximum peak-cap tolerance excess of approximately 3.4 × 10⁻¹² MW. See `diagnostics/tie_sensitivity.py`, `diagnostics/tie_sensitivity_daily.csv` and `diagnostics/tie_sensitivity.json`. Running `python diagnostics/tie_sensitivity.py` reproduces this separate diagnostic without rewriting the primary outputs.

The simple rule's zero adverse days also remain sample-specific. An analytic counterexample in the diagnostic shows that a feasible forecast-based rule can charge during an actual peak and raise it. That constructed mathematical check is not an empirical dataset or a claim about observed NESO operations.

## Capacity trade-offs

Mean realized daily relief for the frozen reference forecast LP selection:

| Power | 1 hour | 2 hours | 4 hours |
| --- | ---: | ---: | ---: |
| 500 MW | 163.91 MW | 224.87 MW | 228.11 MW |
| 1,000 MW | 318.73 MW | 532.10 MW | 590.52 MW |
| 2,000 MW | 551.53 MW | 1,017.97 MW | 1,301.46 MW |

At 500 MW, expanding from two to four hours increased mean realized relief by only 3.24 MW in this evaluation. At 1,000 MW it added 58.42 MW; at 2,000 MW it added 283.49 MW. The value of extra energy capacity depends on the power limit and demand shape. These physical outcomes alone cannot determine whether an asset is worth buying.

Although these aggregate entries increase across the selected resource grid, individual realized forecast outcomes need not be monotonic. Increasing available capacity expands the hindsight feasible set; it also permits a different forecast schedule, which can perform differently against actual demand. The code checks monotonicity only where the mathematical implication is valid: the hindsight optimum.

## Two inspectable dates

**Default: 3 November 2025.** This is the first weekday of November, selected by a calendar rule before policy evaluation. Baseline peak was 35,100 MW. At 1,000 MW/two hours, the rule reduced it by 786 MW, the forecast LP by 870 MW and the hindsight LP by 1,000 MW. The default is not the best-performing day.

**Weak case: 30 August 2025.** At the same resource bounds, the forecast LP increased the peak by 943.28 MW. It charged approximately 943.28 MW at 17:30 London time, when actual ND reached its 24,487 MW daily peak; the frozen forecast for that interval was approximately 22,658.44 MW. Adjusted ND therefore reached 25,430.28 MW. The charging decision was feasible and based on the forecast, but its timing was unfavorable for outturn. This observation is retained and selectable rather than excluded as an inconvenient result.

## Development evidence and limitations

The 114 internal 2024 validation days already exposed a weak forecasting-policy combination. At 1,000 MW/two hours, the forecast LP averaged 431.77 MW relief and worsened 17 days; the simple rule averaged 526.72 MW relief and worsened none. The prescribed reference protocol was retained without using 2025 performance to tune or replace it. The 2025 average ordering differs, which reinforces the need to inspect temporal variation rather than claim a stable performance ranking.

The final forecast uses only 2024 seasonal/daytype/clock means. It has no weather, holidays or issued forecast information. The data are revised historic annual snapshots, not complete as-issued vintages. The ideal resource is lossless, begins and ends empty daily, and ignores network and real equipment restrictions. The daily examples demonstrate modelling and evaluation; they do not establish grid feasibility, deployed professional experience or NESO endorsement.

Potential later extensions include better openly sourced forecasting inputs and policies that explicitly account for forecast uncertainty. Their design should use a new development protocol and untouched evaluation period. No improvement from those extensions has been established here.

## Verification

The reference run evaluated 12 scenarios and four policies per day: **11,760 test result rows** plus **5,472 development rows**. It used **7,236 LP calls**, all returning optimal status, across 3,618 two-stage solves. Zero-capacity controls were solved analytically and repeated forecast schedules were cached. The latest run took about 74 seconds on the local development machine (the first run took about 91 seconds); these timings are not a performance benchmark.

Source hashes matched. The test horizon contains **11,762 actual half-hour intervals**, including the 50-interval October clock-change day. Independent physical and LP residual checks passed. Maximum excess beyond the permitted first-stage peak tolerance was approximately 3.4 × 10⁻¹² MW. Every evaluated nested-resource hindsight comparison passed. Independent tests and exported-data reconciliation are recorded separately in `QA_REVIEW.md` and `tests/`.

**Supported by National Energy SO Open Data.** Historic Demand Data 2024/2025, retrieved 14 September 2026; processing and model by Abdulaziz Aldoseri. [Source](https://www.neso.energy/data-portal/historic-demand-data) · [Licence](https://www.neso.energy/data-portal/neso-open-licence).
