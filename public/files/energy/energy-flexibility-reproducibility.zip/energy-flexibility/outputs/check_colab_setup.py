"""Exercise the notebook's Colab branch without hosted upload or package changes."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'.deps'))
from notebook_setup import prepare_colab_archive

notebook = json.loads((ROOT/'reference_study.ipynb').read_text(encoding='utf-8'))
sources = [''.join(cell['source']) for cell in notebook['cells'] if cell['cell_type']=='code']
branch = '# Optional setup:' + sources[0].split('# Optional setup:', 1)[1]
zip_bytes = (ROOT/'outputs/downloads/energy-flexibility-reproducibility.zip').read_bytes()
google = types.ModuleType('google')
colab = types.ModuleType('google.colab')
files = types.ModuleType('google.colab.files')
files.upload = lambda: {'energy-flexibility-reproducibility.zip':zip_bytes}
colab.files = files
google.colab = colab
original_cwd = Path.cwd()
with tempfile.TemporaryDirectory(prefix='energy-colab-check-') as temporary:
    destination = Path(temporary)/'energy-flexibility'
    def extract_for_test(payload, requested_destination):
        assert requested_destination.as_posix() == '/content/energy-flexibility'
        return prepare_colab_archive(payload, destination)
    def check_install(command, check):
        assert command == [sys.executable,'-m','pip','install','-r',str(destination/'requirements.txt')]
        assert check is True
        return subprocess.CompletedProcess(command, 0)
    namespace = {'prepare_colab_archive':extract_for_test,'Path':Path}
    try:
        with patch.dict(sys.modules, {'google':google,'google.colab':colab,'google.colab.files':files}), patch('subprocess.run', side_effect=check_install):
            exec(compile(branch, '<Colab setup branch>', 'exec'), namespace)
        assert Path.cwd() == destination
        for source in sources[1:]:
            exec(compile(source, '<notebook analysis cell>', 'exec'), namespace)
        report = {'status':'passed','colab_upload':'mocked documented files.upload return mapping',
            'pip_install':'mocked; pinned requirements command checked',
            'extraction':'real extraction to temporary project directory with manifest verification',
            'analysis':'all following notebook code cells executed against extracted project',
            'hosted_colab_execution':False}
        (ROOT/'outputs/colab_setup_check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(report,indent=2))
    finally:
        os.chdir(original_cwd)
