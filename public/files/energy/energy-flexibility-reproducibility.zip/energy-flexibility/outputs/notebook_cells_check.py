"""Validate and unpack the supplied project ZIP for a fresh Colab session."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import stat
import zipfile


def prepare_colab_archive(payload, destination):
    """Verify the package manifest, then extract only inside destination.

    The manifest detects corruption; it does not authenticate the publisher.
    Use the reproduction ZIP downloaded alongside this notebook.
    Existing identical files are retained; differing files are never overwritten.
    """
    destination = Path(destination)
    if destination.is_symlink():
        raise ValueError('The project destination must not be a symbolic link.')
    root = destination.resolve()
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        infos = archive.infolist()
        if len(infos) > 1000 or sum(info.file_size for info in infos) > 100_000_000:
            raise ValueError('Archive exceeds this small project\'s extraction limits.')
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise ValueError('Archive contains duplicate paths.')
        for info in infos:
            path = PurePosixPath(info.filename)
            if (path.is_absolute() or path.as_posix() != info.filename or '..' in path.parts or '\\' in info.filename
                    or ':' in info.filename or len(path.parts) < 2
                    or path.parts[0] != 'energy-flexibility'
                    or stat.S_ISLNK(info.external_attr >> 16) or info.is_dir()):
                raise ValueError('Archive contains an unexpected or unsafe path.')
        manifest_name = 'energy-flexibility/PACKAGE_MANIFEST.json'
        manifest = json.loads(archive.read(manifest_name))
        expected = {'energy-flexibility/' + row['path']: row for row in manifest}
        if len(expected) != len(manifest) or set(names) != set(expected) | {manifest_name}:
            raise ValueError('Archive contents do not match the package manifest.')
        required = {'energy-flexibility/energy_model.py', 'energy-flexibility/pipeline.py',
                    'energy-flexibility/requirements.txt',
                    'energy-flexibility/data/historic_demand_data_2024.csv',
                    'energy-flexibility/data/historic_demand_data_2025.csv'}
        if not required.issubset(expected):
            raise ValueError('Upload the complete energy-flexibility reproduction ZIP.')
        checked = {}
        for name in names:
            data = archive.read(name)
            if name != manifest_name:
                row = expected[name]
                if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                    raise ValueError('A packaged file failed checksum verification.')
            relative = PurePosixPath(name).relative_to('energy-flexibility')
            target = root.joinpath(*relative.parts)
            if not target.resolve().is_relative_to(root) or target.is_symlink():
                raise ValueError('Extraction would leave the project directory.')
            if target in checked:
                raise ValueError('Archive paths resolve to the same destination.')
            if target.exists() and (not target.is_file() or target.read_bytes() != data):
                raise ValueError('The destination contains different files. Use a fresh Colab runtime.')
            checked[target] = data
        for target in checked:
            for parent in target.parents:
                if parent == root:
                    break
                if parent in checked or (parent.exists() and not parent.is_dir()):
                    raise ValueError('An archive file conflicts with a required directory.')
        if root.exists() and not root.is_dir():
            raise ValueError('The project destination is not a directory.')
        # Every archive member and destination has been checked before any write.
        root.mkdir(parents=True, exist_ok=True)
        for target, data in checked.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                target.write_bytes(data)
    return root


# Optional setup: only this branch imports Google Colab.
try:
    from google.colab import files as colab_files
except ImportError:
    colab_files = None

if colab_files is None:
    print('Local Jupyter: using the existing project folder and installed requirements.')
else:
    import os
    import subprocess
    import sys
    uploaded = colab_files.upload()
    if len(uploaded) != 1:
        raise ValueError('Choose exactly one energy-flexibility reproduction ZIP.')
    upload_name, upload_bytes = next(iter(uploaded.items()))
    if not upload_name.lower().endswith('.zip'):
        raise ValueError('Upload the complete .zip package, not the notebook alone.')
    project_dir = prepare_colab_archive(upload_bytes, Path('/content/energy-flexibility'))
    subprocess.run([sys.executable, '-m', 'pip', 'install', '-r',
                    str(project_dir/'requirements.txt')], check=True)
    for package, expected_version in [('numpy', '2.3.5'), ('scipy', '1.16.3')]:
        already_loaded = sys.modules.get(package)
        if already_loaded is not None and getattr(already_loaded, '__version__', None) != expected_version:
            raise RuntimeError('A dependency was already loaded at a different version. Restart the Colab runtime and rerun the setup cell.')
    os.chdir(project_dir)
    print('Project ready. Continue with the analysis cells below.')


from pathlib import Path
from datetime import date
import json
import sys

ROOT = Path.cwd()
if not (ROOT / 'energy_model.py').is_file():
    raise RuntimeError('Start the notebook from the energy-flexibility project folder.')
sys.path.insert(0, str(ROOT))
import energy_model as model
from pipeline import HASHES, evaluation_dates
import numpy as np

actual = model.load_demand(ROOT / 'data/historic_demand_data_2025.csv', HASHES[2025])
training = model.load_demand(ROOT / 'data/historic_demand_data_2024.csv', HASHES[2024])
profile = model.fit_forecast(training)
print(f'Verified {len(training)} training days and {len(evaluation_dates())} evaluation days.')


selected_day = date(2025, 11, 3)
power_mw = 1000
duration_h = 2
energy_capacity_mwh = power_mw * duration_h
if selected_day not in evaluation_dates():
    raise ValueError('Select a day between 1 May and 31 December 2025.')

forecast = model.predict_forecast(selected_day, profile)
forecast_solution = model.solve_schedule(forecast, power_mw, energy_capacity_mwh)
rule = model.forecast_window_rule(forecast, power_mw, energy_capacity_mwh)
hindsight = model.solve_schedule(actual[selected_day], power_mw, energy_capacity_mwh)
baseline_peak = max(actual[selected_day])
for name, solution in [('Forecast LP', forecast_solution), ('Forecast-window rule', rule), ('Hindsight bound', hindsight)]:
    realized_peak = max(actual[selected_day] + solution['flow_mw'])
    print(f'{name:24} peak {realized_peak:,.2f} MW; relief {baseline_peak-realized_peak:,.2f} MW; throughput {solution["throughput_mwh"]:,.2f} MWh')
print('Physical checks:', model.validate_schedule(forecast_solution['flow_mw'], power_mw, energy_capacity_mwh))


labels = model.settlement_labels(selected_day)
print('Period | London time | Actual MW | Forecast MW | Charge MW | Opening MWh')
for i, label in enumerate(labels):
    print(f'{i+1:6} | {label["local_time"]} {label["utc_offset"]} | {actual[selected_day][i]:9.1f} | {forecast[i]:11.1f} | {forecast_solution["flow_mw"][i]:9.1f} | {forecast_solution["energy_mwh"][i]:11.1f}')
print('Closing energy:', forecast_solution['energy_mwh'][-1])
print('Autumn day intervals:', len(model.settlement_labels(date(2025, 10, 26))))


summary = json.loads((ROOT / 'outputs/summary.json').read_text(encoding='utf-8'))
for row in summary:
    if row['power_mw'] == power_mw and row['duration_h'] == duration_h:
        print(f'{row["policy"]:15} mean relief {row["mean_reduction_mw"]:8.2f} MW; worsened {row["worsened_days"]}/{row["days"]} days; worst {row["worst_reduction_mw"]:8.2f} MW')

saved_day = json.loads((ROOT / 'outputs/days' / f'{selected_day.isoformat()}.json').read_text(encoding='utf-8'))
scenario_key = f'{power_mw}_{duration_h}'
if scenario_key in saved_day['scenarios']:
    saved_schedule = saved_day['scenarios'][scenario_key]['policies']['forecast_lp']
    if np.allclose(forecast_solution['flow_mw'], saved_schedule['flow_mw'], atol=1e-5, rtol=0):
        print('Selected forecast schedule matches saved export.')
    else:
        np.testing.assert_allclose(forecast_solution['peak_mw'], saved_schedule['planned_peak_mw'], atol=2e-5, rtol=0)
        np.testing.assert_allclose(forecast_solution['throughput_mwh'], saved_schedule['throughput_mwh'], atol=2e-5, rtol=0)
        print('This environment selected a different tied schedule with the same two forecast objectives. The current rerun above may have different outturn results; the saved summary remains the frozen reference.')


diagnostic = json.loads((ROOT / 'diagnostics/tie_sensitivity.json').read_text(encoding='utf-8'))
print(diagnostic['classification'])
for name, row in diagnostic['time_based_tie_variants'].items():
    print(f'{name:20} mean relief {row["mean_mw"]:.2f} MW; worsened {row["worsened_days"]}/245 days')
print('Objective and physical checks:', diagnostic['max_absolute_objective_and_physical_residuals'])
print('Reproduce separately with: python diagnostics/tie_sensitivity.py')

