# Method and evaluation protocol

## Decision boundary

This is a one-node counterfactual on National Demand (ND), measured in MW. ND is GB's metered generation requirement excluding station load, pumping and exports. It is not total end-user demand. No embedded renewable series is subtracted, no TSD series is added, and no existing pumping is controlled or reconstructed.

The resource is an additional hypothetical ideal lossless store. Its daily initial and final energy are zero. The model omits network feasibility, ramp rates, reserves, prices, emissions, degradation, lifetime and actual asset availability. Outcomes describe conditional peak relief in this model. They establish neither realized savings nor deployability on the GB grid.

## Linear program

For each actual half-hour settlement t, choose signed charging power u[t] MW, stored energy e[t] MWh and peak z MW:

```
minimize z
forecast[t] + u[t] <= z
-P <= u[t] <= P
e[t] = e[t-1] + 0.5 * u[t]
0 <= e[t] <= E
e[0] = e[T] = 0
```

One signed flow per period represents a single net movement. There are no separate simultaneous charge/discharge variables. Positive u charges. Every unit discharged must first be charged within the day.

After establishing the first-stage optimum z*, minimize `0.5*sum(a[t])` subject to the same constraints, `a[t] >= u[t]`, `a[t] >= -u[t]` and `z <= z* + 1e-5 MW`. This is lexicographic throughput minimization within an explicit peak tolerance. Throughput includes both charging and discharging; it is not a degradation cost or the energy discharged alone. Multiple equal-peak, equal-throughput schedules can remain; the pinned solver returns one of them, so solver-version changes may affect realized outcomes of tied forecast schedules even when the optimization objective is unchanged.

This final numerical selection is part of the frozen reference policy, not an economically justified preference between tied schedules. The reported outturn means and adverse-day counts therefore describe that exact selected schedule family. An adversarial post-hoc diagnostic was subsequently added to quantify this sensitivity without changing the primary model, exports or evaluation period. See `diagnostics/` and the dedicated results section. Any future rule for selecting among ties must be fixed using development evidence and assessed on an untouched period before being presented as a validated improvement.

The diagnostic fixes the original first-stage peak cap and constrains absolute throughput to be no greater than the original minimum, with no added throughput slack. It then minimizes or maximizes `H = delta * sum(e[t+1]) = delta^2 * sum((T-t)*u[t])`, for zero-based `t=0,...,T-1` and `delta=0.5` hours. H has units MWh·h and measures stored-energy holding time. It is a diagnostic tie preference, not an observed cost, degradation estimate or economic objective. At the inspected 1,000 MW/two-hour scenario, both variant families retain exactly the reference planned peak and throughput in the recorded numerical results. The two schedules can still produce different realized peaks because their charging timing differs.

The formulas use only forecast and time, but the diagnostic was designed and assessed after primary outturn results were visible. Separation of forecast inputs from outturn inside the code does not turn that later policy selection into a fresh held-out validation. `diagnostics/tie_sensitivity.py` writes only its sibling diagnostic JSON/CSV and leaves `outputs/` unchanged.

SciPy 1.16.3 `linprog(method="highs")` solves the continuous LP. Optimality is reported only when both solver calls return successful status 0, and independent checks pass. The reader rejects nonfinite values, incorrect periods, missing dates and duplicate source keys. A zero capacity returns the analytic no-action solution without invoking a solver.

Reference: [SciPy HiGHS LP interface](https://docs.scipy.org/doc/scipy-1.16.3/reference/optimize.linprog-highs.html). The continuous model has no MIP gap. Residual and objective tolerance checks replace any inappropriate integer-optimality claim.

## Forecast and calendar

The estimator averages 2024 observations within month × weekday/weekend × London local half-hour bins. It ignores holidays and weather; those omissions are part of the deliberately narrow reference method. Training code rejects any observation outside 2024. The estimator uses no 2025 observations.

Calendar conversion starts at London local midnight, converts to UTC, advances by real 30-minute intervals and stops at the next local midnight. This produces 46, 48 or 50 periods. Repeated autumn clock bins share a forecast value but remain distinct observations and transitions; missing spring bins are omitted. Stored UTC offsets and `fold` values distinguish repetitions. Every actual interval remains 0.5 hours for energy accounting.

Within each 2024 month, fit using days 1–21 and evaluate days 22–month end. These 114 validation days are retrospective development checks. No hyperparameter search or outcome-dependent change is made. Then refit exactly the specified estimator on all of 2024 and test all 245 days from 1 May through 31 December 2025. The final fit can use more observations than a monthly development fit; these results serve different purposes.

The provider-reported 2024 resource modification timestamp is 8 April 2025 19:55:41.954513, before the May start. However, the downloaded annual revision is not a complete archived publication-vintage history. Known delays and retrospective revisions preclude calling this a vintage-certified operational backtest. Forecast schedules are fully fixed before the evaluation function applies them to actual 2025 ND.

## Baseline rule

Let j be the earliest maximum forecast settlement (one-based). Start the four-settlement discharge block at `s=min(max(j-1,1),T-3)`. Choose the preceding nonoverlapping four-settlement charge block with the smallest sum of forecast ND, breaking ties by earliest start. If no preceding block exists, do nothing.

Move `q=min(E,2*P)` MWh: uniformly charge at q/2 MW for two hours and discharge at q/2 MW for two hours. Windows never use outturn values. The rule obeys the same empty initial/final state and resource bounds as the LP. Its fixed windows are a transparent comparator, not a tuned industrial controller.

## Evaluation and numerical checks

Evaluate adjusted ND as `actual[t]+chosen_flow[t]`. Peak relief is `max(actual)-max(adjusted)` MW. Negative values are retained. Percentage relief divides by that day's baseline peak. Aggregates report equal-weight daily means, medians, linearly interpolated 10th/90th percentiles, worst day, mean absolute forecast error and percentage of days worsened. A loss greater than 0.0001 MW counts as worsened, avoiding classification on numerical noise. MAE is reported as both mean daily MAE and an interval-weighted overall value.

The code checks power and energy limits, net energy conservation, empty final state, energy transition residuals, all LP inequalities, throughput auxiliary consistency and preservation of the first-stage peak. The second-stage throughput must not exceed the first-stage feasible schedule. Hindsight optima are checked against every nested pair of power/energy resource sets on each day. No comparable monotonicity assertion is imposed on realized forecast outcomes.

A reached resource bound is reported as `binding_power` or `binding_energy` using a 0.0001-unit threshold. This descriptive flag means the schedule reaches the limit. It does not establish a strictly positive marginal value for expanding that resource; degeneracy or another constraint may make expansion unhelpful.

The default is 3 November 2025, the first weekday of November, with 1,000 MW and two hours' duration. This calendar rule was announced in the approved brief before policy results existed. All dates, including weak outcomes, remain selectable. No observation is deleted or imputed based on model performance.

## Browser exports

The complete export contains `meta`, `summary` and `cases`. Each date has local labels, actual ND, frozen forecasts and scenarios keyed `power_mw_duration_h`, for example `1000_2`. Each scenario holds four policy trajectories and outcomes. The smaller index holds `meta`, `summary`, `monthly_summary`, `dates` and `default_case`; daily payloads can load lazily. The notebook compares its selected-day rerun with the frozen export; if an environment selects a different tied schedule, it checks both objective levels and explicitly distinguishes the rerun from the saved reference instead of silently relabelling the primary results.

Trajectories are rounded to six decimal places for export. Daily CSV results retain full numerical precision. The UI should display MW/GW and MWh/GWh explicitly, distinguish forecast from actual ND, and always label hindsight and precomputed results. Source attribution belongs on every derivative chart or data export.
