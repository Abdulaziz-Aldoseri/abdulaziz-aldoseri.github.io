"""Reproduce frozen data preparation, development checks and 2025 evaluation."""
from __future__ import annotations

import csv
import gzip
import hashlib
import importlib.metadata
import json
import platform
import time
from collections import defaultdict
from datetime import date, timedelta, datetime, timezone
from pathlib import Path

import energy_model as model
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parent
TEST_START, TEST_END = date(2025, 5, 1), date(2025, 12, 31)
DEFAULT_DATE = date(2025, 11, 3)
POWERS_MW = (0, 500, 1000, 2000)
DURATIONS_H = (1, 2, 4)
POLICIES = {"no_action": "No additional flexibility", "rule": "Forecast-window rule",
            "forecast_lp": "Forecast LP", "hindsight_lp": "Hindsight LP (perfect-information bound)"}
HASHES = {2024: "fa7895b6e9ab5eb1b450949d969cb18ffeb6005359fc71c79c87e1c47e59cac6",
          2025: "8b8be946bbb084bc28fbf95a71fad0fceb5543b98e02755235130a42beaee4e0"}
SOURCE_URLS = {
    2024: "https://api.neso.energy/dataset/8f2fe0af-871c-488d-8bad-960426f24601/resource/f6d02c0f-957b-48cb-82ee-09003f2ba759/download/demanddata_2024.csv",
    2025: "https://api.neso.energy/dataset/8f2fe0af-871c-488d-8bad-960426f24601/resource/b2bde559-3455-4021-b179-dfe60c0337b0/download/demanddata_2025.csv"}
ATTRIBUTION = "Supported by National Energy SO Open Data. Historic Demand Data 2024/2025, retrieved 14 September 2026; processing and model by Abdulaziz Aldoseri."


def evaluation_dates():
    return tuple(TEST_START + timedelta(days=i) for i in range((TEST_END - TEST_START).days + 1))


def development_forecasts(train_days):
    """For each 2024 month: fit first 21 calendar days, validate remaining days."""
    if any(day.year != 2024 for day in train_days):
        raise ValueError("Development accepts 2024 only")
    predictions = {}
    for month in range(1, 13):
        fit_days = {day: value for day, value in train_days.items() if day.month == month and day.day <= 21}
        profile = model.fit_forecast(fit_days)
        for day in sorted(train_days):
            if day.month == month and day.day > 21:
                predictions[day] = model.predict_forecast(day, profile)
    return predictions


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _plain(value):
    if isinstance(value, np.ndarray):
        return [round(float(x), 6) for x in value]
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(item) for item in value]
    return value


def write_json(path, obj, compact=False):
    path.write_text(json.dumps(_plain(obj), ensure_ascii=False, allow_nan=False,
        indent=None if compact else 2, separators=(",", ":") if compact else None) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def evaluate(actual_days, forecasts, export_cases=False):
    """Compute schedules exclusively from forecasts, then score against outturn."""
    rows, cases, cache = [], {}, {}
    diag_max = defaultdict(float)
    solve_times, lp_calls, solved_instances = [], 0, 0
    for day in sorted(forecasts):
        forecast, actual = forecasts[day], actual_days[day]
        if forecast.shape != actual.shape:
            raise ValueError("Forecast/outturn shape mismatch")
        baseline_peak, mae = float(max(actual)), float(np.mean(np.abs(actual-forecast)))
        case = {"labels": model.settlement_labels(day), "actual_mw": actual,
                "forecast_mw": forecast, "forecast_mae_mw": mae, "scenarios": {}}
        hindsight_optima = {}
        for power in POWERS_MW:
            for duration in DURATIONS_H:
                capacity = power * duration
                cache_key = (forecast.tobytes(), power, capacity)
                if cache_key not in cache:
                    started = time.perf_counter()
                    lp = model.solve_schedule(forecast, power, capacity)
                    solve_times.append(time.perf_counter()-started)
                    lp_calls += lp["lp_calls"]
                    solved_instances += int(lp["lp_calls"] > 0)
                    cache[cache_key] = (lp, model.forecast_window_rule(forecast, power, capacity))
                forecast_lp, rule = cache[cache_key]
                started = time.perf_counter()
                hindsight = model.solve_schedule(actual, power, capacity)
                solve_times.append(time.perf_counter()-started)
                lp_calls += hindsight["lp_calls"]
                solved_instances += int(hindsight["lp_calls"] > 0)
                hindsight_optima[(power, duration)] = hindsight["stage1_peak_mw"]
                no_action = model.solve_schedule(forecast, 0, 0)
                policies = {"no_action": no_action, "rule": rule,
                            "forecast_lp": forecast_lp, "hindsight_lp": hindsight}
                scenario = {"power_mw": power, "duration_h": duration,
                            "energy_capacity_mwh": capacity, "policies": {}}
                for policy, solution in policies.items():
                    for key, value in solution["diagnostics"].items():
                        diag_max[key] = max(diag_max[key], abs(float(value)))
                    flow = solution["flow_mw"]
                    # Actual demand is accessed here only after the schedule exists.
                    adjusted = actual + flow
                    peak = float(np.max(adjusted))
                    reduction = baseline_peak - peak
                    if abs(reduction) < 1e-7:
                        reduction = 0.0
                    row = {"date": day.isoformat(), "month": day.month,
                        "daytype": "weekday" if day.weekday() < 5 else "weekend", "periods": len(actual),
                        "power_mw": power, "duration_h": duration, "energy_capacity_mwh": capacity,
                        "policy": policy, "baseline_peak_mw": baseline_peak, "peak_mw": peak,
                        "reduction_mw": reduction, "reduction_pct": 100*reduction/baseline_peak,
                        "throughput_mwh": solution["throughput_mwh"], "forecast_mae_mw": mae,
                        "binding_power": solution["binding_power"], "binding_energy": solution["binding_energy"],
                        "status": solution["solver_status"]}
                    rows.append(row)
                    if export_cases:
                        scenario["policies"][policy] = {key: row[key] for key in
                            ("peak_mw", "reduction_mw", "reduction_pct", "throughput_mwh", "binding_power", "binding_energy", "status")}
                        scenario["policies"][policy].update(flow_mw=flow,
                            energy_mwh=solution["energy_mwh"], adjusted_mw=adjusted,
                            planned_peak_mw=solution["peak_mw"])
                if export_cases:
                    case["scenarios"][f"{power}_{duration}"] = scenario
        # Same-day perfect-information feasible sets nest as either resource grows.
        for (power, duration), optimum in hindsight_optima.items():
            for (other_power, other_duration), other in hindsight_optima.items():
                if other_power >= power and other_power*other_duration >= power*duration:
                    if other > optimum + 2e-5:
                        raise RuntimeError("Hindsight resource monotonicity failed")
        if export_cases:
            cases[day.isoformat()] = case
    diagnostics = {"max_residuals": dict(diag_max), "lp_calls": lp_calls,
        "solved_two_stage_instances": solved_instances,
        "forecast_cache_entries": len(cache), "max_schedule_runtime_seconds": max(solve_times),
        "median_schedule_runtime_seconds": float(np.median(solve_times)),
        "hindsight_monotonicity": "passed every evaluated day and nested capacity pair"}
    return rows, cases, diagnostics


def aggregate(rows, extra_group=()):
    groups = defaultdict(list)
    keys = ("policy", "power_mw", "duration_h") + tuple(extra_group)
    for row in rows:
        groups[tuple(row[key] for key in keys)].append(row)
    result = []
    for group, values in sorted(groups.items()):
        relief = np.array([row["reduction_mw"] for row in values])
        pct = np.array([row["reduction_pct"] for row in values])
        worst = min(values, key=lambda row: (row["reduction_mw"], row["date"]))
        entry = dict(zip(keys, group))
        entry.update(days=len(values), mean_reduction_mw=float(np.mean(relief)),
            median_reduction_mw=float(np.median(relief)), q10_reduction_mw=float(np.quantile(relief,.1)),
            q90_reduction_mw=float(np.quantile(relief,.9)), mean_reduction_pct=float(np.mean(pct)),
            median_reduction_pct=float(np.median(pct)), worsened_days=int(np.sum(relief < -1e-4)),
            worsened_pct=float(100*np.mean(relief < -1e-4)), worst_date=worst["date"],
            worst_reduction_mw=worst["reduction_mw"], mean_throughput_mwh=float(np.mean([r["throughput_mwh"] for r in values])),
            mean_forecast_mae_mw=float(np.mean([r["forecast_mae_mw"] for r in values])),
            power_binding_pct=float(100*np.mean([r["binding_power"] for r in values])),
            energy_binding_pct=float(100*np.mean([r["binding_energy"] for r in values])))
        result.append(entry)
    return result


def main():
    started = time.perf_counter()
    output = ROOT / "outputs"
    output.mkdir(exist_ok=True)
    # Save protocol before computing any development or test policy outcomes.
    protocol = {"protocol_version": "1.0", "frozen_before_evaluation": True,
        "development": "2024, independently per month: fit days 1-21; evaluate remaining calendar days; no tuning loop",
        "final_fit": "All of 2024 only; arithmetic mean by month, weekday/weekend and local half-hour",
        "test_start": TEST_START.isoformat(), "test_end": TEST_END.isoformat(), "test_days": len(evaluation_dates()),
        "powers_mw": POWERS_MW, "durations_h": DURATIONS_H,
        "default_date_rule": "First weekday in November 2025", "default_date": DEFAULT_DATE.isoformat(),
        "peak_tolerance_mw": model.PEAK_TOLERANCE_MW, "feasibility_tolerance": model.FEASIBILITY_TOLERANCE,
        "quantile_method": "numpy linear interpolation", "worsened_threshold_mw": 1e-4,
        "sources": [{"year": year, "path": f"data/historic_demand_data_{year}.csv",
                     "sha256": HASHES[year], "url": SOURCE_URLS[year]} for year in HASHES],
        "code_sha256": {name: _hash(ROOT/name) for name in ("energy_model.py", "pipeline.py", "requirements.txt")}}
    write_json(output/"protocol.json", protocol)
    train = model.load_demand(ROOT/"data/historic_demand_data_2024.csv", HASHES[2024])
    actual = model.load_demand(ROOT/"data/historic_demand_data_2025.csv", HASHES[2025])
    dev_predictions = development_forecasts(train)
    dev_rows, _, dev_diag = evaluate(train, dev_predictions)
    write_csv(output/"development_daily_results.csv", dev_rows)
    write_json(output/"development_summary.json", aggregate(dev_rows))
    print(f"Development: {len(dev_predictions)} days; {dev_diag['lp_calls']} LP calls", flush=True)
    profile = model.fit_forecast(train)
    write_json(output/"frozen_forecast_profile.json", [{"month": key[0], "daytype": key[1], "local_time": key[2], "forecast_mw": value} for key,value in sorted(profile.items())])
    forecasts = {day: model.predict_forecast(day, profile) for day in evaluation_dates()}
    rows, cases, test_diag = evaluate(actual, forecasts, export_cases=True)
    summary = aggregate(rows)
    write_csv(output/"daily_results.csv", rows)
    write_json(output/"summary.json", summary)
    write_json(output/"monthly_summary.json", aggregate(rows, ("month",)))
    write_json(output/"weekday_summary.json", aggregate(rows, ("daytype",)))
    error_rows = [{"date": day.isoformat(), "periods": len(actual[day]),
        "mae_mw": float(np.mean(np.abs(forecasts[day]-actual[day]))),
        "bias_mw": float(np.mean(forecasts[day]-actual[day])),
        "actual_peak_mw": float(max(actual[day])), "forecast_peak_mw": float(max(forecasts[day]))} for day in evaluation_dates()]
    write_csv(output/"forecast_errors.csv", error_rows)
    meta = {"schema_version": "1.0", "title": "How much peak relief can flexibility provide?",
        "provenance": "Independent retrospective decision study; precomputed evaluated scenarios",
        "source": {"provider": "National Energy System Operator", "title": "Historic Demand Data 2024/2025",
            "url": "https://www.neso.energy/data-portal/historic-demand-data",
            "licence": "National Energy SO Open Data Licence v1.0",
            "licence_url": "https://www.neso.energy/data-portal/neso-open-licence", "attribution": ATTRIBUTION,
            "retrieved": "2026-09-14", "sha256": HASHES},
        "units": {"power": "MW", "energy": "MWh", "time_step_hours": .5},
        "demand_definition": "GB National Demand (ND): metered generation requirement excluding station load, pumping and exports; not total end-user demand",
        "assumptions": ["Hypothetical additional ideal lossless store", "Empty initial and final state every day",
            "One-node model; no network, ramp, reserve, price or asset constraints", "Forecast frozen from 2024; no 2025 outturn informs forecast policy",
            "Hindsight LP is a perfect-information bound, not an operational policy", "Revised annual data; not an as-issued vintage-certified backtest"],
        "period": {"start": TEST_START.isoformat(), "end": TEST_END.isoformat(), "days": len(cases)},
        "default_date": DEFAULT_DATE.isoformat(), "default_date_rule": protocol["default_date_rule"],
        "default_power_mw": 1000, "default_duration_h": 2,
        "powers_mw": POWERS_MW, "durations_h": DURATIONS_H, "policies": POLICIES,
        "forecast_mae_mw": float(np.mean([row["mae_mw"] for row in error_rows])),
        "forecast_mae_weighted_by_intervals_mw": float(sum(row["mae_mw"]*row["periods"] for row in error_rows)/sum(row["periods"] for row in error_rows)),
        "numerical_precision": "Trajectories rounded to six decimal places in JSON; daily CSV uses full precision",
        "binding_definition": "A resource bound is reached by this schedule; does not by itself establish marginal value",
        "throughput_definition": "0.5 hours times sum of absolute net flow; includes charging and discharging"}
    write_json(output/"public_results.json", {"meta": meta, "summary": summary, "cases": cases}, compact=True)
    (output/"public_results.json.gz").write_bytes(gzip.compress((output/"public_results.json").read_bytes(), mtime=0))
    # Small index and daily payloads allow fast static-hosted browser interactions.
    public_days = output/"days"
    public_days.mkdir(exist_ok=True)
    for day, case in cases.items():
        write_json(public_days/f"{day}.json", case, compact=True)
    write_json(output/"public_index.json", {"meta": meta, "summary": summary,
        "monthly_summary": aggregate(rows,("month",)), "dates": list(cases),
        "default_case": cases[DEFAULT_DATE.isoformat()]}, compact=True)
    verification = {"source_hashes_verified": True, "source_rows": {"2024":sum(map(len,train.values())),"2025":sum(map(len,actual.values()))},
        "test_days":len(cases),"test_intervals":sum(len(actual[d]) for d in evaluation_dates()),
        "test_rows":len(rows),"development_days":len(dev_predictions),"development_rows":len(dev_rows),
        "development":dev_diag,"test":test_diag,"versions":{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"tzdata":importlib.metadata.version("tzdata")},
        "runtime_seconds":time.perf_counter()-started,"generated_utc":datetime.now(timezone.utc).isoformat(),
        "protocol_sha256":_hash(output/"protocol.json"),"public_results_bytes":(output/"public_results.json").stat().st_size,
        "public_results_gzip_bytes":(output/"public_results.json.gz").stat().st_size}
    write_json(output/"verification.json", verification)
    print(json.dumps(verification,indent=2),flush=True)


if __name__ == "__main__":
    main()
