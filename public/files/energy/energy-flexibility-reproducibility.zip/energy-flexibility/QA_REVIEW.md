# Independent QA review — energy flexibility reference model

Review date: 14 September 2026. Scope: model mathematics, forecast information boundaries, evaluation protocol and reported aggregates. This review does not certify actual GB grid dispatch, asset economics, operational deployment or data-vintage availability.

## Review status

**Passed on the final regenerated artifacts.** The complete suite passed 36 independent automated tests: 28 covering model mathematics, inputs and evaluation protocol, plus eight for the added notebook setup. Independent reconciliation passed for every exported trajectory and all aggregate groups. Explanatory metadata formatting changed between the two reference runs; model equations and evaluation choices did not change. The later Colab preparation helper does not change numerical model results.

Final reviewed execution protocol SHA-256: `55522489dc2e24002c9a734f198389d60a7aec308724cfa62835176e3ed3ca5f`. Source and model-code hashes recorded by that protocol match the reviewed files.

**Subsequent adversarial finding:** passing those numerical checks did not establish that the public decision interpretation was robust to selection among tied optima. A material sensitivity was found and is documented under “Adversarial interpretation follow-up” below. The primary results remain correct and unchanged; their interpretation is now explicitly limited to the frozen solver-selected schedule family.

## Independent checks

`tests/test_energy_model.py` uses standard-library `unittest` and NumPy. It checks externally observable model behavior without reproducing the LP matrix construction.

- Known optima separate power MW from energy MWh: a two-settlement `[0, 4]` demand profile reaches peak 2 MW with 4 MW power and 2 MWh capacity; 0.5 MWh capacity raises that optimum to 3 MW; 0.5 MW power raises it to 3.5 MW. Every interval is 0.5 hours.
- An opening spike with an empty store cannot be met using later charging. A flat forecast and the throughput tie-break should produce zero action. Zero power or zero energy gives the control.
- A separate sequential feasibility algorithm bounds the achievable peak. For a proposed peak, it maintains the maximum energy reachable under the allowed charging headroom and tests whether every mandatory discharge is possible. Larger reachable energy dominates smaller energy before a later discharge. Any surplus at the end can be removed by reducing earlier charging without increasing a peak, so this tests existence of a cyclic schedule rather than treating the greedy trajectory itself as cyclic. Bisection on feasibility gives an oracle independent of the LP solver.
- Resource monotonicity is tested on the hindsight optimum. It is deliberately not imposed on realized outcomes of forecast schedules.
- Returned trajectories are checked for power bounds, energy bounds, half-hour energy transitions, zero initial/final state, reported peak and absolute energy movement. Throughput is total charging plus discharging energy, not discharge energy alone.
- The rule is checked against a hand-worked charging-window tie, insufficient prior charging opportunity and deterministic feasible output on all three day lengths.
- Calendar tests check absent spring clock bins, distinct autumn repeated settlements/folds, chronological UTC uniqueness and half-hour spacing on 46/48/50-settlement days.
- Forecast tests verify month × weekday/weekend × local-clock means, repeated autumn clock predictions, missing-group rejection and explicit rejection of 2025 training rows.
- Pipeline tests instrument all 12 development fits and confirm that each contains exactly days 1–21 of its own month. Deliberately extreme held-out observations cannot enter their corresponding predictions. Changing the 2025 outturn while holding the forecast fixed changes the hindsight solution and leaves every forecast-based policy schedule unchanged.
- Input and external-schedule checks reject altered source hashes, missing columns/dates, nonfinite ND, duplicate source keys, excess power/energy, discharge before available charge and nonzero terminal energy.

## Protocol interpretation

The fixed test horizon is 1 May–31 December 2025 inclusive: **245 days and 11,762 half-hour settlements**. It contains the 50-settlement autumn clock-change day. The first ordinary weekday of November is **3 November 2025**. The frozen seasonal estimator is fitted only to 2024 observations. Month-specific development validation must fit on that month's first 21 calendar days and predict only the remaining days.

The 2024 provider modification timestamp predates this test horizon, but the downloaded files do not establish complete as-issued data vintages. Results are retrospective and chronologically separated; they are not a certified operational backtest.

## Commands and results

From the project directory, using Python 3.12 and the pinned dependencies:

```sh
python -m unittest discover -s tests -v
python tests/audit_saved_results.py
```

Final execution of the complete suite: **36 tests passed**, including 27 LP comparisons with the independent reachability oracle. The saved-output audit does not rerun the optimization. It independently calculates means, medians, linearly interpolated quantiles, adverse-day counts, binding percentages and worst dates using the standard library. Exact test output is retained in `tests/unit_test_output.txt`; the concise public-safe verification record is `tests/verification.json`.

| Reconciled item | Result |
| --- | --- |
| Held-out daily result rows and exported policy trajectories | 11,760, all checked |
| Development result rows | 5,472 |
| Overall test aggregate groups | 48 |
| Monthly test aggregate groups | 384 |
| Weekday/weekend test aggregate groups | 96 |
| Development aggregate groups | 48 |
| Raw 2025 ND, baseline peaks and exported observed arrays | Match |
| Frozen forecast profile and every exported date's clock mapping | Match |
| Source hashes and code hashes recorded in the execution protocol | Match |
| Default case in the initial browser index and daily payload | Match, 3 November 2025 |
| Maximum exported energy-transition residual | Approximately 0.000001 MWh |
| Maximum exported terminal residual reconstructed from rounded flows | Approximately 0.000005 MWh |

The last two values are consistent with six-decimal trajectory exports. They are separate from the full-precision solver residuals in `outputs/verification.json`. Audit details and the audit script hash are saved in `tests/saved_results_audit.json`.

## Findings and dispositions

No mathematical or aggregation defect was found. The signed-flow formulation, empty boundary states, half-hour units, baseline timing and two-stage objective implement the frozen brief. Calendar tests cover both annual daylight-saving transitions; the held-out annual export includes the autumn transition.

At 1,000 MW and 2,000 MWh, independently reconciled mean daily relief is 532.10 MW for the frozen solver-selected forecast LP, 514.41 MW for the window rule and 964.13 MW for the hindsight reference. This LP selection worsens 15 of 245 daily peaks, with worst relief −943.28 MW on 30 August 2025; the rule worsens none in this test set. The average/downside trade-off describes this particular selection only. The adversarial follow-up demonstrates that another equally optimal schedule selection changes it materially.

Reviewed public-facing prose in `README.md`, `METHODS.md`, `RESULTS.md`, `data/README.md` and the notebook source. The text preserves the 2024-only training boundary, revised annual-data caveat, hypothetical lossless resource, daily empty boundary states, limited ND interpretation and hindsight information advantage. It excludes financial returns, deployment, actual grid-security claims and NESO endorsement. Data attribution and original-code licensing are distinguished. No private career records are included in these reviewed project materials.

Residual limits are substantive: source snapshots are revised and do not establish full as-issued availability; the simple forecast excludes weather and holidays; the model omits network and equipment constraints. Equal-peak/equal-throughput LP ties can remain, so the selected forecast schedule can depend on solver version. The pinned versions and execution hashes make that choice inspectable rather than establishing unique optimal scheduling behavior.

## Notebook setup follow-up

The notebook now includes an optional Colab branch for uploading the complete reproduction ZIP, checking its manifest, preparing a project directory and installing pinned requirements. Eight independent fixture-based tests verify correct extraction, identical-file reuse without rewriting, corruption rejection, preservation of existing differing files, manifest coverage, path traversal/absolute-path rejection, symbolic-link rejection, canonical path handling and file/parent conflicts. Review identified canonical-path and ancestor-conflict gaps; the implementation owner corrected them before the passing run.

The model owner also executed the local notebook code-cell sequence and a mocked Colab upload/install branch with real archive extraction and all subsequent analysis cells. The latter is recorded in `outputs/colab_setup_check.json`; upload and package installation were mocked. **An actual hosted Colab runtime has not been tested.** Manifest hashes detect corruption and do not authenticate the publisher; the instructions direct readers to the supplied reproduction package.

After an additional host-path alias guard was added, the eight focused setup tests passed again, including a case-insensitive path alias on the review host. No numerical model or evaluation artifacts changed.

## Adversarial interpretation follow-up

A new adversarial probe deliberately tried to falsify the decision-facing comparison rather than repeat the existing test suite. It found a **material interpretation issue**: the original peak-minimization and minimum-throughput objectives leave multiple schedules, whose charging times can have different outturn consequences. The earlier methodological tie caveat was correct but insufficiently prominent and did not quantify the effect.

At 1,000 MW and 2,000 MWh, a third objective maximizing `H = delta * sum(e[t+1])`, with `delta=0.5` hours, selects longer holding times among solutions preserving both original objective levels. The 245-day result averages **595.8237277671 MW** of relief with **zero adverse days**, compared with **532.0995825411 MW and 15 adverse days** for the frozen primary selection. Minimizing H reproduces the primary selection's results here. Neither third-objective formula uses outturn to choose a schedule.

The independent cumulative-energy LP probe reports zero planned-peak differences, zero throughput differences and zero physical constraint violations across both variants; the maximum excess beyond the unchanged peak tolerance is approximately 3.39e-12 MW. No added throughput slack is used. Source snapshots are hash-checked, forecasts are refitted from 2024 only, and every primary daily result is reproduced before comparison. See `diagnostics/tie_sensitivity.py`, `diagnostics/tie_sensitivity_daily.csv` and `diagnostics/tie_sensitivity.json`.

These are **post-hoc exploratory diagnostics**, not a newly validated alternative policy: the formulas were investigated after the original 2025 evaluation was visible. Choosing the better-looking one now would use the test period for policy selection. The primary model, forecasts, schedules and results were deliberately retained. Any future replacement needs a predeclared decision-based tie rule and a fresh evaluation period.

The revised README, METHODS, RESULTS and notebook interpretation now identify the frozen selection, quantify the sensitivity, reject a general optimization-versus-rule ranking and disclose post-hoc selection. The revised website findings and control note state the same boundary. Numerical correctness and decision-claim robustness are separate review questions; this follow-up corrects the latter rather than silently retuning the former.
