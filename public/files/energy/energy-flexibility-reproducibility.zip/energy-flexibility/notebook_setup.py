"""Validate and unpack the supplied project ZIP for a fresh Colab session."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import stat
import zipfile


def prepare_colab_archive(payload, destination):
    """Verify the package manifest, then extract only inside destination.

    The manifest detects corruption; it does not authenticate the publisher.
    Use the reproduction ZIP downloaded alongside this notebook.
    Existing identical files are retained; differing files are never overwritten.
    """
    destination = Path(destination)
    if destination.is_symlink():
        raise ValueError('The project destination must not be a symbolic link.')
    root = destination.resolve()
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        infos = archive.infolist()
        if len(infos) > 1000 or sum(info.file_size for info in infos) > 100_000_000:
            raise ValueError('Archive exceeds this small project\'s extraction limits.')
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise ValueError('Archive contains duplicate paths.')
        for info in infos:
            path = PurePosixPath(info.filename)
            if (path.is_absolute() or path.as_posix() != info.filename or '..' in path.parts or '\\' in info.filename
                    or ':' in info.filename or len(path.parts) < 2
                    or path.parts[0] != 'energy-flexibility'
                    or stat.S_ISLNK(info.external_attr >> 16) or info.is_dir()):
                raise ValueError('Archive contains an unexpected or unsafe path.')
        manifest_name = 'energy-flexibility/PACKAGE_MANIFEST.json'
        manifest = json.loads(archive.read(manifest_name))
        expected = {'energy-flexibility/' + row['path']: row for row in manifest}
        if len(expected) != len(manifest) or set(names) != set(expected) | {manifest_name}:
            raise ValueError('Archive contents do not match the package manifest.')
        required = {'energy-flexibility/energy_model.py', 'energy-flexibility/pipeline.py',
                    'energy-flexibility/requirements.txt',
                    'energy-flexibility/data/historic_demand_data_2024.csv',
                    'energy-flexibility/data/historic_demand_data_2025.csv'}
        if not required.issubset(expected):
            raise ValueError('Upload the complete energy-flexibility reproduction ZIP.')
        checked = {}
        for name in names:
            data = archive.read(name)
            if name != manifest_name:
                row = expected[name]
                if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                    raise ValueError('A packaged file failed checksum verification.')
            relative = PurePosixPath(name).relative_to('energy-flexibility')
            target = root.joinpath(*relative.parts)
            if not target.resolve().is_relative_to(root) or target.is_symlink():
                raise ValueError('Extraction would leave the project directory.')
            if target in checked:
                raise ValueError('Archive paths resolve to the same destination.')
            if target.exists() and (not target.is_file() or target.read_bytes() != data):
                raise ValueError('The destination contains different files. Use a fresh Colab runtime.')
            checked[target] = data
        for target in checked:
            for parent in target.parents:
                if parent == root:
                    break
                if parent in checked or (parent.exists() and not parent.is_dir()):
                    raise ValueError('An archive file conflicts with a required directory.')
        if root.exists() and not root.is_dir():
            raise ValueError('The project destination is not a directory.')
        # Every archive member and destination has been checked before any write.
        root.mkdir(parents=True, exist_ok=True)
        for target, data in checked.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                target.write_bytes(data)
    return root
