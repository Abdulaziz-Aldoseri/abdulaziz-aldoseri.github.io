"""POST-HOC exploratory counterexample probes; do not replace the frozen study.

Run from the project directory: python diagnostics/tie_sensitivity.py
Only diagnostics/ outputs are written. The primary model and results are untouched.
"""
from pathlib import Path
import sys
import json
import csv
import statistics

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
import energy_model as model
import pipeline
import numpy as np
from scipy.optimize import linprog


def tie_variant(forecast, power, capacity, direction):
    reference = model.solve_schedule(forecast, power, capacity)
    n = len(forecast)
    constraints, rhs = [], []
    for t in range(n):
        row = np.zeros(2*n); row[t] = 1
        constraints.append(row); rhs.append(reference["stage1_peak_mw"] + 1e-5 - forecast[t])
        row = np.zeros(2*n); row[t] = 1; row[n+t] = -1
        constraints.append(row); rhs.append(0)
        row = np.zeros(2*n); row[t] = -1; row[n+t] = -1
        constraints.append(row); rhs.append(0)
        row = np.zeros(2*n); row[:t+1] = .5
        constraints.append(row); rhs.append(capacity)
        constraints.append(-row); rhs.append(0)
    row = np.zeros(2*n); row[n:] = .5
    constraints.append(row); rhs.append(reference["throughput_mwh"])
    equal = np.zeros((1, 2*n)); equal[0, :n] = 1
    objective = np.zeros(2*n)
    # Sum of states after each settlement. Neither time-based tie rule reads
    # actual demand: one minimizes holding time and the other maximizes it.
    objective[:n] = direction * .25 * np.arange(n, 0, -1)
    result = linprog(objective, A_ub=np.array(constraints), b_ub=np.array(rhs),
                     A_eq=equal, b_eq=[0], bounds=[(-power,power)]*n+[(0,power)]*n,
                     method="highs", options={"primal_feasibility_tolerance":1e-8,
                                              "dual_feasibility_tolerance":1e-8})
    assert result.success, result.message
    flow = result.x[:n]
    physical = model.validate_schedule(flow, power, capacity, tolerance=2e-5)
    assert max(forecast+flow) <= reference["stage1_peak_mw"] + 2e-5
    assert .5*sum(abs(flow)) <= reference["throughput_mwh"] + 2e-5
    throughput = float(.5 * sum(abs(flow)))
    planned_peak = float(max(forecast+flow))
    return {"flow":flow,"primary_flow":reference["flow_mw"],
            "primary_stage1_peak_mw":reference["stage1_peak_mw"],
            "primary_planned_peak_mw":reference["peak_mw"],
            "primary_throughput_mwh":reference["throughput_mwh"],
            "variant_planned_peak_mw":planned_peak,
            "variant_throughput_mwh":throughput,
            "peak_cap_excess_mw":max(0.,planned_peak-reference["stage1_peak_mw"]-1e-5),
            "planned_peak_difference_mw":planned_peak-reference["peak_mw"],
            "throughput_difference_mwh":throughput-reference["throughput_mwh"],
            "holding_mwh_h":float(.5 * np.sum(np.cumsum(flow)*.5)),
            "physical_max_violation":physical["max_violation"],
            "solver_status":int(result.status)}


def main():
    out = PROJECT / "outputs"
    training = model.load_demand(PROJECT/"data/historic_demand_data_2024.csv",pipeline.HASHES[2024])
    actual_days = model.load_demand(PROJECT/"data/historic_demand_data_2025.csv",pipeline.HASHES[2025])
    profile = model.fit_forecast(training)
    with (out/"daily_results.csv").open(newline="",encoding="utf-8") as handle:
        rows = [r for r in csv.DictReader(handle) if r["power_mw"]=="1000" and r["duration_h"]=="2"]
    groups = {policy:[float(r["reduction_mw"]) for r in rows if r["policy"]==policy]
              for policy in ("forecast_lp","rule")}
    summary = {policy:{"mean_mw":statistics.mean(v), "sample_sd_mw":statistics.stdev(v),
                       "q10_mw":float(np.quantile(v,.1)), "q90_mw":float(np.quantile(v,.9)),
                       "worsened_days":sum(x< -1e-4 for x in v)} for policy,v in groups.items()}
    variants = {"min_holding_time":[],"max_holding_time":[]}
    cache = {}
    daily = []
    primary_by_day = {r["date"]:r for r in rows if r["policy"]=="forecast_lp"}
    rule_by_day = {r["date"]:r for r in rows if r["policy"]=="rule"}
    for day in pipeline.evaluation_dates():
        actual = actual_days[day]
        forecast = model.predict_forecast(day, profile)
        record = {"date":day.isoformat(),"periods":len(actual),"power_mw":1000,
                  "energy_capacity_mwh":2000,"primary_relief_mw":float(primary_by_day[day.isoformat()]["reduction_mw"]),
                  "rule_relief_mw":float(rule_by_day[day.isoformat()]["reduction_mw"])}
        for name,direction in [("min_holding_time",1),("max_holding_time",-1)]:
            key = forecast.tobytes(),direction
            if key not in cache:
                cache[key] = tie_variant(forecast,1000,2000,direction)
            solution = cache[key]
            reduction = float(max(actual)-max(actual+solution["flow"]))
            primary_rerun = float(max(actual)-max(actual+solution["primary_flow"]))
            assert abs(primary_rerun-record["primary_relief_mw"]) < 2e-5
            variants[name].append({"date":day.isoformat(),"reduction_mw":reduction})
            record[name+"_relief_mw"] = reduction
            for field,value in solution.items():
                if field not in ("flow","primary_flow"):
                    record[name+"_"+field] = value
        daily.append(record)
    variant_summaries = {}
    for name, values in variants.items():
        relief = [r["reduction_mw"] for r in values]
        variant_summaries[name] = {"mean_mw":statistics.mean(relief),
                                  "worsened_days":sum(x< -1e-4 for x in relief),
                                  "worst":min(values,key=lambda r:r["reduction_mw"])}
    # An equally good forecast still permits opposite realized consequences.
    forecast = np.array([10.,10,14])
    actual = np.array([14.,10,14])
    alternatives = [np.array([2.,0,-2]),np.array([0.,2,-2])]
    counterexample = []
    for flow in alternatives:
        model.validate_schedule(flow,2,1)
        counterexample.append({"flow":flow.tolist(),"forecast_peak":float(max(forecast+flow)),
                               "throughput_mwh":float(.5*sum(abs(flow))),
                               "actual_peak":float(max(actual+flow)),
                               "relief_mw":float(max(actual)-max(actual+flow))})
    # A rule cannot be regarded as inherently safe based on 245 observed cases.
    forecast = np.array([0.,0,0,0,0,4,4,4,4,0,0,0])
    actual = np.array([5.,5,5,5,0,4,4,4,4,0,0,0])
    rule = model.forecast_window_rule(forecast,2,4)
    rule_counterexample={"forecast":forecast.tolist(),"actual":actual.tolist(),
                         "flow":rule["flow_mw"].tolist(),
                         "actual_peak_before":float(max(actual)),
                         "actual_peak_after":float(max(actual+rule["flow_mw"]))}
    numeric_checks = {field:max(abs(r[name+"_"+field]) for r in daily for name in variants)
                      for field in ("peak_cap_excess_mw","planned_peak_difference_mw",
                                    "throughput_difference_mwh","physical_max_violation")}
    report={"classification":"POST-HOC exploratory diagnostic; not an independently validated policy comparison",
            "third_objective":"H = delta * sum(e[t+1]) = delta^2 * sum((T-t)*u[t]), t=0..T-1; delta=0.5h. Minimize or maximize H only after preserving both frozen objective levels.",
            "holding_unit":"MWh h", "peak_constraint":"forecast_peak <= primary_stage1_peak + 0.00001 MW",
            "throughput_constraint":"absolute throughput <= primary minimum throughput; no added throughput slack",
            "scenario":{"power_mw":1000,"energy_capacity_mwh":2000,"duration_h":2,"test_days":245},
            "default_capacity_dispersion":summary,"time_based_tie_variants":variant_summaries,
            "tie_variant_distinct_lp_solves":len(cache),"analytic_tie_counterexample":counterexample,
            "max_absolute_objective_and_physical_residuals":numeric_checks,
            "rule_can_worsen_counterexample":rule_counterexample,
            "scope":"Third-objective formulas were investigated after inspecting the frozen evaluation. Their construction uses forecast and time only; selecting one now would be post-hoc selection. Neither replaces the frozen primary policy or establishes future performance."}
    path=Path(__file__).with_suffix(".json")
    path.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    with Path(__file__).with_name("tie_sensitivity_daily.csv").open("w",encoding="utf-8",newline="") as handle:
        writer = csv.DictWriter(handle,fieldnames=list(daily[0]))
        writer.writeheader(); writer.writerows(daily)
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
