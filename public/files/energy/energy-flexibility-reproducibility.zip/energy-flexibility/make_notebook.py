"""Generate the portable reference notebook from small, reviewable code cells.

Only Python stdlib is needed to generate it; executing its cells uses requirements.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def markdown(text):
    return {"cell_type":"markdown", "metadata":{}, "source":text.splitlines(keepends=True)}

def code(text):
    return {"cell_type":"code", "execution_count":None, "metadata":{}, "outputs":[], "source":text.splitlines(keepends=True)}

cells = [
markdown("""# How much peak relief can flexibility provide?

Independent decision study by Abdulaziz Aldoseri. Explore an additional ideal store's daily peak relief, then inspect the gap between forecast scheduling and hindsight potential.

The displayed forecast LP is the frozen solver-selected reference. Multiple schedules can share its best forecast peak and minimum throughput. A separate, explicitly post-hoc diagnostic below shows that selection among those ties materially affects outturn results. It does not replace the original policy or establish a validated improvement.

**Supported by National Energy SO Open Data.** Historic Demand Data 2024/2025, retrieved 14 September 2026; processing and model by Abdulaziz Aldoseri. [Source](https://www.neso.energy/data-portal/historic-demand-data) · [National Energy SO Open Data Licence v1.0](https://www.neso.energy/data-portal/neso-open-licence).

**Local Jupyter:** install `requirements.txt`, start this notebook in the extracted project folder and run the cells in order. The optional setup cell below skips itself outside Colab.

**Google Colab:** open [Colab](https://colab.research.google.com/), choose File → Upload notebook, and upload this `.ipynb`. Run the setup cell below and choose the complete `energy-flexibility-reproducibility.zip` downloaded with it. The cell verifies and extracts the project into `/content/energy-flexibility`, installs pinned requirements in the Colab runtime and selects that folder. Use a fresh CPU runtime. If installation reports that a runtime restart is needed, restart and rerun the cells; identical uploaded files can be reused safely. No Drive access is needed.

`python pipeline.py` regenerates every result. The Colab setup uses Google's documented upload helper; actual hosted Colab execution has not been performed for this release. [Colab file upload implementation](https://github.com/googlecolab/colabtools/blob/main/google/colab/files.py) · [Colab file and library setup guidance](https://research.google.com/colaboratory/faq.html).
"""),
code((ROOT/'notebook_setup.py').read_text(encoding='utf-8') + """

# Optional setup: only this branch imports Google Colab.
try:
    from google.colab import files as colab_files
except ImportError:
    colab_files = None

if colab_files is None:
    print('Local Jupyter: using the existing project folder and installed requirements.')
else:
    import os
    import subprocess
    import sys
    uploaded = colab_files.upload()
    if len(uploaded) != 1:
        raise ValueError('Choose exactly one energy-flexibility reproduction ZIP.')
    upload_name, upload_bytes = next(iter(uploaded.items()))
    if not upload_name.lower().endswith('.zip'):
        raise ValueError('Upload the complete .zip package, not the notebook alone.')
    project_dir = prepare_colab_archive(upload_bytes, Path('/content/energy-flexibility'))
    subprocess.run([sys.executable, '-m', 'pip', 'install', '-r',
                    str(project_dir/'requirements.txt')], check=True)
    for package, expected_version in [('numpy', '2.3.5'), ('scipy', '1.16.3')]:
        already_loaded = sys.modules.get(package)
        if already_loaded is not None and getattr(already_loaded, '__version__', None) != expected_version:
            raise RuntimeError('A dependency was already loaded at a different version. Restart the Colab runtime and rerun the setup cell.')
    os.chdir(project_dir)
    print('Project ready. Continue with the analysis cells below.')
"""),
code("""from pathlib import Path
from datetime import date
import json
import sys

ROOT = Path.cwd()
if not (ROOT / 'energy_model.py').is_file():
    raise RuntimeError('Start the notebook from the energy-flexibility project folder.')
sys.path.insert(0, str(ROOT))
import energy_model as model
from pipeline import HASHES, evaluation_dates
import numpy as np

actual = model.load_demand(ROOT / 'data/historic_demand_data_2025.csv', HASHES[2025])
training = model.load_demand(ROOT / 'data/historic_demand_data_2024.csv', HASHES[2024])
profile = model.fit_forecast(training)
print(f'Verified {len(training)} training days and {len(evaluation_dates())} evaluation days.')
"""),
markdown("""## Decision model

Minimize adjusted forecast peak `z`, subject to `forecast[t]+u[t]<=z`, `-P<=u[t]<=P`, `e[t]=e[t-1]+0.5*u[t]`, `0<=e[t]<=E` and `e[0]=e[T]=0`. Positive flow charges. The second LP minimizes `0.5*sum(abs(u))` while retaining the optimum peak within 0.00001 MW.

Remaining tied schedules are selected numerically by the pinned SciPy/HiGHS run. This is part of the frozen reference policy; equal forecast objectives do not imply equal realized outcomes.

This is a continuous LP. The store is hypothetical and lossless. The model is one node with no prices, real asset parameters or network constraints. ND is metered generation requirement, not total end-user demand. Hindsight uses outturn and is a perfect-information bound.

Change only the date and capacity values below to inspect another evaluated day. The forecast remains frozen from 2024.
"""),
code("""selected_day = date(2025, 11, 3)
power_mw = 1000
duration_h = 2
energy_capacity_mwh = power_mw * duration_h
if selected_day not in evaluation_dates():
    raise ValueError('Select a day between 1 May and 31 December 2025.')

forecast = model.predict_forecast(selected_day, profile)
forecast_solution = model.solve_schedule(forecast, power_mw, energy_capacity_mwh)
rule = model.forecast_window_rule(forecast, power_mw, energy_capacity_mwh)
hindsight = model.solve_schedule(actual[selected_day], power_mw, energy_capacity_mwh)
baseline_peak = max(actual[selected_day])
for name, solution in [('Forecast LP', forecast_solution), ('Forecast-window rule', rule), ('Hindsight bound', hindsight)]:
    realized_peak = max(actual[selected_day] + solution['flow_mw'])
    print(f'{name:24} peak {realized_peak:,.2f} MW; relief {baseline_peak-realized_peak:,.2f} MW; throughput {solution[\"throughput_mwh\"]:,.2f} MWh')
print('Physical checks:', model.validate_schedule(forecast_solution['flow_mw'], power_mw, energy_capacity_mwh))
"""),
markdown("""## Inspect the trajectory and clock changes

Every interval is half an hour. Autumn repetitions carry distinct UTC offsets and remain separate storage transitions. Energy has T+1 boundaries; `energy[t]` below is the state at the beginning of the interval.
"""),
code("""labels = model.settlement_labels(selected_day)
print('Period | London time | Actual MW | Forecast MW | Charge MW | Opening MWh')
for i, label in enumerate(labels):
    print(f'{i+1:6} | {label[\"local_time\"]} {label[\"utc_offset\"]} | {actual[selected_day][i]:9.1f} | {forecast[i]:11.1f} | {forecast_solution[\"flow_mw\"][i]:9.1f} | {forecast_solution[\"energy_mwh\"][i]:11.1f}')
print('Closing energy:', forecast_solution['energy_mwh'][-1])
print('Autumn day intervals:', len(model.settlement_labels(date(2025, 10, 26))))
"""),
markdown("""## All-day evidence

The reference grid covers 0, 500, 1,000 and 2,000 MW at 1, 2 and 4 hours. The following figures use every test day. Negative relief is retained. A reached resource bound does not by itself prove that expansion has value.
"""),
code("""summary = json.loads((ROOT / 'outputs/summary.json').read_text(encoding='utf-8'))
for row in summary:
    if row['power_mw'] == power_mw and row['duration_h'] == duration_h:
        print(f'{row[\"policy\"]:15} mean relief {row[\"mean_reduction_mw\"]:8.2f} MW; worsened {row[\"worsened_days\"]}/{row[\"days\"]} days; worst {row[\"worst_reduction_mw\"]:8.2f} MW')

saved_day = json.loads((ROOT / 'outputs/days' / f'{selected_day.isoformat()}.json').read_text(encoding='utf-8'))
scenario_key = f'{power_mw}_{duration_h}'
if scenario_key in saved_day['scenarios']:
    saved_schedule = saved_day['scenarios'][scenario_key]['policies']['forecast_lp']
    if np.allclose(forecast_solution['flow_mw'], saved_schedule['flow_mw'], atol=1e-5, rtol=0):
        print('Selected forecast schedule matches saved export.')
    else:
        np.testing.assert_allclose(forecast_solution['peak_mw'], saved_schedule['planned_peak_mw'], atol=2e-5, rtol=0)
        np.testing.assert_allclose(forecast_solution['throughput_mwh'], saved_schedule['throughput_mwh'], atol=2e-5, rtol=0)
        print('This environment selected a different tied schedule with the same two forecast objectives. The current rerun above may have different outturn results; the saved summary remains the frozen reference.')
"""),
markdown("""## Post-hoc diagnostic: tied schedules

The following diagnostic was developed after inspecting the frozen results. It preserves the optimal forecast peak cap and original minimum throughput, then separately minimizes or maximizes `H=0.5*sum(e[t+1])`, the area under stored energy in MWh·h. Its schedule formulas use forecast and time only, but selecting between them after seeing these results would be test-period policy selection.

At 1,000 MW/two hours, maximum holding time gives 595.82 MW average relief and zero worsened days, compared with the frozen selection's 532.10 MW and 15 worsened days. Thus the 15-day finding describes one numerical selection, not every optimum of the forecast LP. No primary outputs have been changed. This is not a validated operational improvement; a justified tie preference needs development evidence and a fresh test period.
"""),
code("""diagnostic = json.loads((ROOT / 'diagnostics/tie_sensitivity.json').read_text(encoding='utf-8'))
print(diagnostic['classification'])
for name, row in diagnostic['time_based_tie_variants'].items():
    print(f'{name:20} mean relief {row[\"mean_mw\"]:.2f} MW; worsened {row[\"worsened_days\"]}/245 days')
print('Objective and physical checks:', diagnostic['max_absolute_objective_and_physical_residuals'])
print('Reproduce separately with: python diagnostics/tie_sensitivity.py')
"""),
markdown("""## Interpretation

At 1,000 MW and two hours, the frozen forecast LP mean relief was 532.10 MW versus 514.41 MW for the rule. That particular LP selection worsened 15 of 245 peaks; the rule worsened none in this test set. Hindsight averaged 964.13 MW and uses unavailable future information. The tie diagnostic shows that the original comparison does not isolate forecast quality from numerical selection among optima. Neither the original average gain nor the post-hoc alternative establishes a reliable operational improvement.

The frozen forecast is an intentionally simple seasonal/daytype mean, with no weather or holiday inputs. Historic annual files are revised and are not complete as-issued vintages. Potential findings concern this ideal model, not real grid security, deployed equipment, savings or NESO endorsement. See `METHODS.md`, `RESULTS.md`, `data/README.md` and `QA_REVIEW.md` for the full record.
""")]

for i, cell in enumerate(cells):
    cell['id'] = f'reference-{i:02d}'
notebook = {"cells": cells, "metadata": {"kernelspec": {"display_name":"Python 3", "language":"python", "name":"python3"},
    "language_info": {"name":"python", "version":"3.12"}}, "nbformat":4, "nbformat_minor":5}
(ROOT/'reference_study.ipynb').write_text(json.dumps(notebook,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
# This companion verification script is exactly the notebook's code cells.
(ROOT/'outputs/notebook_cells_check.py').write_text('\n\n'.join(''.join(c['source']) for c in cells if c['cell_type']=='code')+'\n',encoding='utf-8')
print('Created reference_study.ipynb and outputs/notebook_cells_check.py')
