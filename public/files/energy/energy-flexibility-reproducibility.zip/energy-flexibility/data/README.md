# Open source data

**Supported by National Energy SO Open Data.** Historic Demand Data 2024/2025, retrieved 14 September 2026; processing and model by Abdulaziz Aldoseri.

Provider: National Energy System Operator (NESO). Geography: Great Britain. Observation unit: settlement date and actual half-hour period. Required variables: settlement date, settlement period and National Demand (ND, MW). All 22 original CSV columns are retained unchanged; only ND enters the model.

[Dataset landing page](https://www.neso.energy/data-portal/historic-demand-data) · [National Energy SO Open Data Licence v1.0](https://www.neso.energy/data-portal/neso-open-licence)

| Snapshot | Rows | SHA-256 |
| --- | --- | --- |
| `historic_demand_data_2024.csv` | 17,568 | `fa7895b6e9ab5eb1b450949d969cb18ffeb6005359fc71c79c87e1c47e59cac6` |
| `historic_demand_data_2025.csv` | 17,520 | `8b8be946bbb084bc28fbf95a71fad0fceb5543b98e02755235130a42beaee4e0` |

- [2024 exact resource](https://api.neso.energy/dataset/8f2fe0af-871c-488d-8bad-960426f24601/resource/f6d02c0f-957b-48cb-82ee-09003f2ba759/download/demanddata_2024.csv)
- [2025 exact resource](https://api.neso.energy/dataset/8f2fe0af-871c-488d-8bad-960426f24601/resource/b2bde559-3455-4021-b179-dfe60c0337b0/download/demanddata_2025.csv)

Resource URLs can be revised; the SHA-256 identifies the actual snapshot. A freshly downloaded file with a different hash should trigger a new source review, not silent replacement. No rows were excluded, imputed or altered. Dates are normalized in memory. The October repeated hour remains separate; energy steps remain half an hour.

ND is an aggregate metered generation requirement excluding station load, pumping and exports. It is not total end-user consumption. The source does not contain real storage capacities, forecasts issued at a known time, efficiency, prices, site/network limits or observed investment returns. The model's power and duration controls are explicitly hypothetical scenario assumptions.

The provider reports delayed publication, retrospective corrections and known quality concerns. Structural completeness is not proof of measurement accuracy. The 2025 source was last modified on 9 June 2026 according to provider metadata; it is a retrospective snapshot. The 2024 provider modification timestamp precedes the May 2025 test start, but a full as-issued vintage history was not obtained.

The source licence was inspected on 14 September 2026 through the provider's web pages. Direct HTML retrieval was challenged; no locally saved raw licence HTML is claimed. Recheck current terms before public release. Data attribution does not imply endorsement and does not include provider logo rights.
