"""Ideal daily flexibility model. Positive net flow charges; units are MW/MWh.

Only the forecast passed by the caller informs either forecast-based schedule.
No file loading or outturn access occurs inside the scheduling functions.
"""
from __future__ import annotations

import csv
import hashlib
import math
import sys
from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

# Optional project-local dependency install; normal virtualenv installs work too.
_deps = Path(__file__).resolve().parent / ".deps"
if _deps.is_dir():
    sys.path.insert(0, str(_deps))

import numpy as np
from scipy.optimize import linprog

DT_HOURS = 0.5
PEAK_TOLERANCE_MW = 1e-5
FEASIBILITY_TOLERANCE = 1e-5
LONDON = ZoneInfo("Europe/London")


def settlement_labels(day: date) -> list[dict]:
    """UTC-stepped half hours between consecutive London local midnights."""
    if not isinstance(day, date) or isinstance(day, datetime):
        raise ValueError("day must be a datetime.date")
    start = datetime.combine(day, time(), LONDON).astimezone(timezone.utc)
    stop = datetime.combine(day + timedelta(days=1), time(), LONDON).astimezone(timezone.utc)
    labels = []
    cursor = start
    while cursor < stop:
        local = cursor.astimezone(LONDON)
        offset = local.strftime("%z")
        labels.append({"period": len(labels) + 1, "local_time": local.strftime("%H:%M"),
                       "utc_offset": offset[:3] + ":" + offset[3:], "fold": local.fold,
                       "iso_utc": cursor.isoformat().replace("+00:00", "Z")})
        cursor += timedelta(minutes=30)
    return labels


def _parse_day(value: str) -> date:
    for fmt in ("%Y-%m-%d", "%d-%b-%Y"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"Invalid settlement date: {value!r}")


def load_demand(path: str | Path, expected_sha256: str | None = None) -> dict[date, np.ndarray]:
    """Read a complete annual source file; reject gaps, duplicates and bad ND."""
    path = Path(path)
    if expected_sha256 and hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256:
        raise ValueError("Source checksum does not match the frozen snapshot")
    rows = defaultdict(dict)
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not {"SETTLEMENT_DATE", "SETTLEMENT_PERIOD", "ND"}.issubset(reader.fieldnames or []):
            raise ValueError("Missing required source columns")
        for row in reader:
            day = _parse_day(row["SETTLEMENT_DATE"])
            period = int(row["SETTLEMENT_PERIOD"])
            nd = float(row["ND"])
            if not math.isfinite(nd) or nd <= 0:
                raise ValueError("ND must be finite and positive")
            if period in rows[day]:
                raise ValueError(f"Duplicate settlement: {day}, {period}")
            rows[day][period] = nd
    if not rows:
        raise ValueError("Empty demand file")
    years = {day.year for day in rows}
    if len(years) != 1:
        raise ValueError("Expected exactly one full calendar year")
    year = next(iter(years))
    first, stop = date(year, 1, 1), date(year + 1, 1, 1)
    expected = {first + timedelta(days=i) for i in range((stop - first).days)}
    if set(rows) != expected:
        raise ValueError("Missing dates in annual source")
    result = {}
    for day in sorted(rows):
        n = len(settlement_labels(day))
        if sorted(rows[day]) != list(range(1, n + 1)):
            raise ValueError(f"Missing or malformed settlement periods: {day}")
        result[day] = np.array([rows[day][p] for p in range(1, n + 1)], dtype=float)
    return result


def _daytype(day: date) -> str:
    return "weekday" if day.weekday() < 5 else "weekend"


def fit_forecast(days: dict[date, np.ndarray]) -> dict[tuple[int, str, str], float]:
    """Frozen estimator: 2024 month x daytype x local half-hour arithmetic mean."""
    if not days or any(day.year != 2024 for day in days):
        raise ValueError("This frozen protocol permits fitting on 2024 observations only")
    bins = defaultdict(list)
    for day, values in sorted(days.items()):
        demand, _, _ = _inputs(values, 0, 0)
        labels = settlement_labels(day)
        if len(demand) != len(labels):
            raise ValueError(f"Forecast training shape does not match calendar: {day}")
        for label, value in zip(labels, demand):
            bins[(day.month, _daytype(day), label["local_time"])].append(float(value))
    return {key: float(np.mean(values)) for key, values in bins.items()}


def predict_forecast(day: date, profile: dict[tuple[int, str, str], float]) -> np.ndarray:
    keys = [(day.month, _daytype(day), label["local_time"]) for label in settlement_labels(day)]
    if any(key not in profile for key in keys):
        raise ValueError("Forecast profile has missing month/daytype/clock bins")
    result = np.array([profile[key] for key in keys], dtype=float)
    if not np.all(np.isfinite(result)):
        raise ValueError("Forecast profile contains nonfinite values")
    return result


def _inputs(demand, power_mw, energy_mwh):
    values = np.asarray(demand, dtype=float)
    if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
        raise ValueError("Demand must be a nonempty one-dimensional finite sequence")
    power, energy = float(power_mw), float(energy_mwh)
    if not math.isfinite(power) or not math.isfinite(energy) or min(power, energy) < 0:
        raise ValueError("Power and energy bounds must be finite and nonnegative")
    return values, power, energy


def validate_schedule(flow, power_mw, energy_mwh, tolerance=FEASIBILITY_TOLERANCE) -> dict:
    flow, power, capacity = _inputs(flow, power_mw, energy_mwh)
    energy = np.r_[0.0, np.cumsum(flow) * DT_HOURS]
    diagnostic = {
        "power_violation_mw": float(max(0.0, np.max(np.abs(flow)) - power)),
        "energy_lower_violation_mwh": float(max(0.0, -np.min(energy))),
        "energy_upper_violation_mwh": float(max(0.0, np.max(energy) - capacity)),
        "terminal_residual_mwh": float(abs(energy[-1])),
    }
    diagnostic["max_violation"] = max(diagnostic.values())
    if diagnostic["max_violation"] > tolerance:
        raise ValueError(f"Infeasible schedule: {diagnostic}")
    return diagnostic


def _result(demand, flow, power, capacity):
    diagnostic = validate_schedule(flow, power, capacity)
    energy = np.r_[0.0, np.cumsum(flow) * DT_HOURS]
    return {"flow_mw": flow, "energy_mwh": energy,
            "peak_mw": float(np.max(demand + flow)),
            "throughput_mwh": float(DT_HOURS * np.sum(np.abs(flow))),
            "binding_power": bool(power > 0 and np.max(np.abs(flow)) >= power - 1e-4),
            "binding_energy": bool(capacity > 0 and np.max(energy) >= capacity - 1e-4),
            "diagnostics": diagnostic}


def solve_schedule(demand, power_mw, energy_mwh, peak_tolerance_mw=PEAK_TOLERANCE_MW) -> dict:
    """Lexicographic continuous LP: minimize peak, then absolute throughput.

    Variables u[0:T], e[1:T+1], z, a[0:T]. Empty start/end and one signed
    net-flow variable per interval prevent free initial energy and simultaneous
    charging/discharging variables. Throughput counts both charge and discharge.
    """
    demand, power, capacity = _inputs(demand, power_mw, energy_mwh)
    if not math.isfinite(peak_tolerance_mw) or peak_tolerance_mw < 0:
        raise ValueError("Peak tolerance must be finite and nonnegative")
    n = len(demand)
    if power == 0 or capacity == 0:
        result = _result(demand, np.zeros(n), power, capacity)
        result.update(stage1_peak_mw=float(max(demand)), solver_status="analytic_zero_capacity",
                      stage1_status=0, stage2_status=0, lp_calls=0, stage1_throughput_mwh=0.0)
        return result
    # All constraints explicitly retain engineering units; stage1 uses the same
    # polytope as stage2, but the auxiliary bounds only matter in stage2.
    size, zindex, astart = 3 * n + 1, 2 * n, 2 * n + 1
    aeq, beq = np.zeros((n, size)), np.zeros(n)
    for t in range(n):
        aeq[t, t] = -DT_HOURS
        aeq[t, n + t] = 1
        if t:
            aeq[t, n + t - 1] = -1
    aub, bub = np.zeros((3 * n, size)), np.r_[-demand, np.zeros(2 * n)]
    for t in range(n):
        aub[t, t], aub[t, zindex] = 1, -1
        aub[n + t, t], aub[n + t, astart + t] = 1, -1
        aub[2 * n + t, t], aub[2 * n + t, astart + t] = -1, -1
    bounds = [(-power, power)] * n + [(0, capacity)] * (n - 1) + [(0, 0)] + [(None, None)] + [(0, power)] * n
    objective = np.zeros(size)
    objective[zindex] = 1
    options = {"primal_feasibility_tolerance": 1e-8, "dual_feasibility_tolerance": 1e-8}
    first = linprog(objective, A_ub=aub, b_ub=bub, A_eq=aeq, b_eq=beq,
                    bounds=bounds, method="highs", options=options)
    if not first.success:
        raise RuntimeError(f"First-stage LP failed: {first.status}: {first.message}")
    optimum = float(first.fun)
    objective[:] = 0
    objective[astart:] = DT_HOURS
    bounds[zindex] = (None, optimum + peak_tolerance_mw)
    second = linprog(objective, A_ub=aub, b_ub=bub, A_eq=aeq, b_eq=beq,
                     bounds=bounds, method="highs", options=options)
    if not second.success:
        raise RuntimeError(f"Second-stage LP failed: {second.status}: {second.message}")
    result = _result(demand, second.x[:n].copy(), power, capacity)
    first_throughput = float(DT_HOURS * np.sum(np.abs(first.x[:n])))
    peak_excess = max(0.0, result["peak_mw"] - optimum - peak_tolerance_mw)
    residual = float(np.max(np.abs(aeq @ second.x - beq)))
    inequality = float(max(0, np.max(aub @ second.x - bub)))
    aux_excess = abs(float(second.fun) - result["throughput_mwh"])
    if max(peak_excess, residual, inequality, aux_excess) > FEASIBILITY_TOLERANCE:
        raise RuntimeError("Lexicographic solution failed independent residual checks")
    if result["throughput_mwh"] > first_throughput + FEASIBILITY_TOLERANCE:
        raise RuntimeError("Second-stage throughput exceeds feasible first-stage schedule")
    result["diagnostics"].update(peak_tolerance_excess_mw=peak_excess,
        energy_equation_residual_mwh=residual, inequality_violation_mw=inequality,
        auxiliary_throughput_residual_mwh=aux_excess,
        stage1_peak_gap_mw=float(result["peak_mw"] - optimum))
    result.update(stage1_peak_mw=optimum, solver_status="optimal", stage1_status=int(first.status),
                  stage2_status=int(second.status), lp_calls=2, stage1_throughput_mwh=first_throughput)
    return result


def forecast_window_rule(demand, power_mw, energy_mwh) -> dict:
    """Two-hour earliest-peak discharge and cheapest prior two-hour charge rule."""
    demand, power, capacity = _inputs(demand, power_mw, energy_mwh)
    n = len(demand)
    flow = np.zeros(n)
    charge_start = discharge_start = None
    if n >= 4 and power > 0 and capacity > 0:
        # Zero-based equivalent of s=min(max(j-1,1),T-3) in the frozen brief.
        discharge_start = min(max(int(np.argmax(demand)) - 1, 0), n - 4)
        starts = list(range(discharge_start - 3))
        if starts:
            charge_start = min(starts, key=lambda start: (float(np.sum(demand[start:start+4])), start))
            rate = min(capacity, power * 2.0) / 2.0
            flow[charge_start:charge_start+4] = rate
            flow[discharge_start:discharge_start+4] = -rate
    result = _result(demand, flow, power, capacity)
    result.update(solver_status="rule", lp_calls=0, charge_start=charge_start, discharge_start=discharge_start)
    return result
