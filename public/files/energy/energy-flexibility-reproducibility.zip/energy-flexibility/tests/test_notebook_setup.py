"""Small ZIP fixtures test Colab preparation without Colab, network or installs."""

import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from notebook_setup import prepare_colab_archive


BASE = {
    "energy_model.py": b"# fixture model\n",
    "pipeline.py": b"# fixture pipeline\n",
    "requirements.txt": b"numpy==2.3.5\n",
    "data/historic_demand_data_2024.csv": b"fixture 2024 bytes\n",
    "data/historic_demand_data_2025.csv": b"fixture 2025 bytes\n",
}


def archive_bytes(extra=None, altered=None, raw_extra=None):
    files = dict(BASE)
    files.update(extra or {})
    manifest = [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                for name, data in sorted(files.items())]
    content = io.BytesIO()
    with zipfile.ZipFile(content, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in files.items():
            archive.writestr("energy-flexibility/" + name, (altered or {}).get(name, data))
        archive.writestr("energy-flexibility/PACKAGE_MANIFEST.json", json.dumps(manifest))
        for name, data in raw_extra or []:
            archive.writestr(name, data)
    return content.getvalue()


class NotebookSetupTests(unittest.TestCase):
    def test_valid_package_extracts_verified_bytes_and_is_idempotent(self):
        payload = archive_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            result = prepare_colab_archive(payload, destination)
            self.assertEqual(result, destination.resolve())
            for name, data in BASE.items():
                self.assertEqual((destination / name).read_bytes(), data)
            initial_times = {path: path.stat().st_mtime_ns for path in destination.rglob("*") if path.is_file()}
            self.assertEqual(prepare_colab_archive(payload, destination), result)
            self.assertEqual(initial_times, {path: path.stat().st_mtime_ns for path in initial_times})

    def test_path_traversal_and_absolute_windows_or_posix_paths_are_rejected(self):
        for member in ["energy-flexibility/../escape.txt", "/tmp/escape.txt",
                       "C:/escape.txt", "energy-flexibility\\escape.txt", "other-root/escape.txt"]:
            with self.subTest(member=member), tempfile.TemporaryDirectory() as temporary:
                destination = Path(temporary) / "study"
                with self.assertRaises(ValueError):
                    prepare_colab_archive(archive_bytes(raw_extra=[(member, b"escape")]), destination)
                self.assertFalse(destination.exists())
                self.assertFalse((Path(temporary) / "escape.txt").exists())

    def test_corruption_is_rejected_before_writing(self):
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            with self.assertRaisesRegex(ValueError, "checksum"):
                prepare_colab_archive(archive_bytes(altered={"pipeline.py": b"tampered bytes"}), destination)
            self.assertFalse(destination.exists())

    def test_existing_different_file_is_preserved_and_nothing_else_written(self):
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            destination.mkdir()
            sentinel = destination / "pipeline.py"
            sentinel.write_bytes(b"my existing work")
            with self.assertRaisesRegex(ValueError, "different files"):
                prepare_colab_archive(archive_bytes(), destination)
            self.assertEqual(sentinel.read_bytes(), b"my existing work")
            self.assertEqual({path.name for path in destination.iterdir()}, {"pipeline.py"})

    def test_unmanifested_member_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            with self.assertRaisesRegex(ValueError, "manifest"):
                prepare_colab_archive(archive_bytes(raw_extra=[("energy-flexibility/extra.py", b"unexpected")]), destination)
            self.assertFalse(destination.exists())

    def test_symbolic_link_member_is_rejected(self):
        link = zipfile.ZipInfo("energy-flexibility/link")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            with self.assertRaises(ValueError):
                prepare_colab_archive(archive_bytes(raw_extra=[(link, b"../outside")]), destination)
            self.assertFalse(destination.exists())

    def test_noncanonical_path_aliases_are_rejected_before_writing(self):
        names = ["data//extra.txt", "data/./extra.txt"]
        if os.path.normcase("A") == os.path.normcase("a"):
            names.append("DATA/historic_demand_data_2024.csv")
        for name in names:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temporary:
                destination = Path(temporary) / "study"
                with self.assertRaises(ValueError):
                    prepare_colab_archive(archive_bytes(extra={name: b"ambiguous"}), destination)
                self.assertFalse(destination.exists())

    def test_file_parent_collision_is_rejected_before_writing(self):
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "study"
            with self.assertRaises(ValueError):
                prepare_colab_archive(archive_bytes(extra={"conflict": b"file", "conflict/child.py": b"child"}), destination)
            self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
