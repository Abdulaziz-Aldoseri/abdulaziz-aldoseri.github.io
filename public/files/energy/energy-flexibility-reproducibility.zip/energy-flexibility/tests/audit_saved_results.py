"""Reconcile saved evaluation outputs independently of pipeline aggregation.

Does not rerun optimization. Uses standard-library aggregation and direct source
rows to check every published trajectory and all overall/month/daytype summaries.
Run: python tests/audit_saved_results.py
"""

from collections import defaultdict
import csv
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def close(actual, expected, tolerance=1e-7):
    assert abs(float(actual) - float(expected)) <= tolerance, (actual, expected, tolerance)


def quantile(values, probability):
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    left = int(position)
    right = min(left + 1, len(ordered) - 1)
    return ordered[left] + (position - left) * (ordered[right] - ordered[left])


def read_rows(name):
    with (OUT / name).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        for key in ("month", "periods", "power_mw", "duration_h", "energy_capacity_mwh"):
            row[key] = int(row[key])
        for key in ("baseline_peak_mw", "peak_mw", "reduction_mw", "reduction_pct", "throughput_mwh", "forecast_mae_mw"):
            row[key] = float(row[key])
        for key in ("binding_power", "binding_energy"):
            assert row[key] in ("True", "False")
            row[key] = row[key] == "True"
    return rows


def check_summary(rows, name, extra=()):
    keys = ("policy", "power_mw", "duration_h") + extra
    grouped = defaultdict(list)
    for row in rows:
        grouped[tuple(row[key] for key in keys)].append(row)
    entries = json.loads((OUT / name).read_text(encoding="utf-8"))
    assert len(entries) == len(grouped)
    seen = set()
    for entry in entries:
        key = tuple(entry[field] for field in keys)
        assert key not in seen
        seen.add(key)
        selected = grouped[key]
        relief = [row["reduction_mw"] for row in selected]
        percentages = [row["reduction_pct"] for row in selected]
        worst = min(selected, key=lambda row: (row["reduction_mw"], row["date"]))
        worsened = sum(value < -1e-4 for value in relief)
        expected = {
            "days": len(selected), "mean_reduction_mw": statistics.mean(relief),
            "median_reduction_mw": statistics.median(relief), "q10_reduction_mw": quantile(relief, .1),
            "q90_reduction_mw": quantile(relief, .9), "mean_reduction_pct": statistics.mean(percentages),
            "median_reduction_pct": statistics.median(percentages), "worsened_days": worsened,
            "worsened_pct": 100 * worsened / len(selected), "worst_reduction_mw": worst["reduction_mw"],
            "mean_throughput_mwh": statistics.mean(row["throughput_mwh"] for row in selected),
            "mean_forecast_mae_mw": statistics.mean(row["forecast_mae_mw"] for row in selected),
            "power_binding_pct": 100 * sum(row["binding_power"] for row in selected) / len(selected),
            "energy_binding_pct": 100 * sum(row["binding_energy"] for row in selected) / len(selected),
        }
        for field, value in expected.items():
            close(entry[field], value)
        assert entry["worst_date"] == worst["date"]
    return len(entries)


def main():
    protocol = json.loads((OUT / "protocol.json").read_text(encoding="utf-8"))
    for source in protocol["sources"]:
        assert hashlib.sha256((ROOT / source["path"]).read_bytes()).hexdigest() == source["sha256"]
    for filename, expected in protocol["code_sha256"].items():
        assert hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() == expected, filename

    raw = defaultdict(dict)
    with (ROOT / "data/historic_demand_data_2025.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            raw[row["SETTLEMENT_DATE"]][int(row["SETTLEMENT_PERIOD"])] = float(row["ND"])
    rows = read_rows("daily_results.csv")
    expected_dates = {(date(2025, 5, 1) + timedelta(days=i)).isoformat() for i in range(245)}
    assert len(rows) == 245 * 12 * 4
    assert {row["date"] for row in rows} == expected_dates
    row_index = {}
    for row in rows:
        key = row["date"], row["power_mw"], row["duration_h"], row["policy"]
        assert key not in row_index
        row_index[key] = row
        actual = raw[row["date"]]
        assert row["periods"] == len(actual)
        close(row["baseline_peak_mw"], max(actual.values()))
        close(row["reduction_mw"], row["baseline_peak_mw"] - row["peak_mw"])
        close(row["reduction_pct"], 100 * row["reduction_mw"] / row["baseline_peak_mw"])
        assert row["energy_capacity_mwh"] == row["power_mw"] * row["duration_h"]
        parsed = date.fromisoformat(row["date"])
        assert row["month"] == parsed.month
        assert row["daytype"] == ("weekday" if parsed.weekday() < 5 else "weekend")
        if row["power_mw"] == 0 or row["policy"] == "no_action":
            close(row["reduction_mw"], 0)
            close(row["throughput_mwh"], 0)
        if row["policy"] == "hindsight_lp":
            assert row["reduction_mw"] >= -2e-5
            assert row["status"] in ("optimal", "analytic_zero_capacity")

    counts = {"overall": check_summary(rows, "summary.json"),
              "monthly": check_summary(rows, "monthly_summary.json", ("month",)),
              "daytype": check_summary(rows, "weekday_summary.json", ("daytype",))}
    dev_rows = read_rows("development_daily_results.csv")
    assert len(dev_rows) == 114 * 12 * 4
    assert all(date.fromisoformat(row["date"]).year == 2024 and date.fromisoformat(row["date"]).day > 21 for row in dev_rows)
    counts["development"] = check_summary(dev_rows, "development_summary.json")

    index = json.loads((OUT / "public_index.json").read_text(encoding="utf-8"))
    assert set(index["dates"]) == expected_dates
    assert index["meta"]["default_date"] == "2025-11-03"
    assert index["summary"] == json.loads((OUT / "summary.json").read_text(encoding="utf-8"))
    assert index["monthly_summary"] == json.loads((OUT / "monthly_summary.json").read_text(encoding="utf-8"))
    assert "Supported by National Energy SO Open Data" in index["meta"]["source"]["attribution"]
    profile = {(row["month"], row["daytype"], row["local_time"]): row["forecast_mw"]
               for row in json.loads((OUT / "frozen_forecast_profile.json").read_text(encoding="utf-8"))}
    max_transition_residual = max_terminal_residual = 0.
    interval_count = 0
    for day in sorted(expected_dates):
        case = json.loads((OUT / "days" / f"{day}.json").read_text(encoding="utf-8"))
        if day == "2025-11-03":
            assert case == index["default_case"]
        demand = [raw[day][period] for period in sorted(raw[day])]
        assert case["actual_mw"] == demand
        n = len(demand)
        interval_count += n
        parsed = date.fromisoformat(day)
        daytype = "weekday" if parsed.weekday() < 5 else "weekend"
        for label, prediction in zip(case["labels"], case["forecast_mw"]):
            close(prediction, profile[(parsed.month, daytype, label["local_time"])], 6e-7)
        close(case["forecast_mae_mw"], statistics.mean(abs(a-b) for a, b in zip(demand, case["forecast_mw"])), 6e-7)
        assert len(case["scenarios"]) == 12
        for scenario in case["scenarios"].values():
            power, duration = scenario["power_mw"], scenario["duration_h"]
            capacity = power * duration
            for policy, output in scenario["policies"].items():
                saved = row_index[(day, power, duration, policy)]
                flow, state = output["flow_mw"], output["energy_mwh"]
                assert len(flow) == n and len(state) == n + 1
                assert len(output["adjusted_mw"]) == n
                close(state[0], 0, 5e-5)
                close(state[-1], 0, 5e-5)
                max_terminal_residual = max(max_terminal_residual, abs(sum(flow) * .5))
                close(sum(flow) * .5, 0, 5e-5)
                assert min(state) >= -5e-5 and max(state) <= capacity + 5e-5
                assert max(abs(value) for value in flow) <= power + 5e-5
                for t in range(n):
                    residual = abs(state[t + 1] - state[t] - .5 * flow[t])
                    max_transition_residual = max(max_transition_residual, residual)
                    assert residual <= 5e-5
                    close(output["adjusted_mw"][t], demand[t] + flow[t], 2e-6)
                close(saved["peak_mw"], max(output["adjusted_mw"]), 2e-6)
                close(saved["throughput_mwh"], .5 * sum(abs(value) for value in flow), 5e-5)
                for field in ("peak_mw", "reduction_mw", "reduction_pct", "throughput_mwh"):
                    close(output[field], saved[field])
    assert interval_count == 11762
    report = {"status": "passed", "test_days": 245, "test_intervals": interval_count,
              "daily_rows": len(rows), "development_rows": len(dev_rows), "summary_groups_verified": counts,
              "exported_trajectories_verified": len(rows),
              "max_export_energy_transition_residual_mwh": max_transition_residual,
              "max_export_terminal_residual_mwh": max_terminal_residual,
              "source_and_protocol_code_hashes": "verified", "default_day": "2025-11-03",
              "aggregation_method": "independent standard-library mean/median/linear-quantile calculations",
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT / "tests/saved_results_audit.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
