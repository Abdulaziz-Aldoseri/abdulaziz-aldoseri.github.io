"""Information-boundary and fixed-protocol checks independent of saved results."""

from datetime import date, timedelta
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import energy_model as model
import pipeline


class ProtocolTests(unittest.TestCase):
    def test_fixed_2025_horizon_and_default_calendar_rule(self):
        days = pipeline.evaluation_dates()
        self.assertEqual(len(days), 245)
        self.assertEqual(days[0], date(2025, 5, 1))
        self.assertEqual(days[-1], date(2025, 12, 31))
        self.assertTrue(all(b - a == timedelta(days=1) for a, b in zip(days, days[1:])))
        self.assertEqual(sum(len(model.settlement_labels(day)) for day in days), 11762)
        first_weekday = next(date(2025, 11, day) for day in range(1, 8) if date(2025, 11, day).weekday() < 5)
        self.assertEqual(pipeline.DEFAULT_DATE, first_weekday)
        self.assertEqual(pipeline.DEFAULT_DATE, date(2025, 11, 3))

    def test_resource_grid_matches_frozen_design(self):
        self.assertEqual(tuple(pipeline.POWERS_MW), (0, 500, 1000, 2000))
        self.assertEqual(tuple(pipeline.DURATIONS_H), (1, 2, 4))
        self.assertEqual(set(pipeline.POLICIES), {"no_action", "rule", "forecast_lp", "hindsight_lp"})

    def test_each_development_forecast_uses_only_earlier_days_in_its_month(self):
        days = [date(2024, 1, 1) + timedelta(days=i) for i in range(366)]
        train = {day: np.full(len(model.settlement_labels(day)), day.month * 100. if day.day <= 21 else 99999.)
                 for day in days}
        fit_sets = []
        original_fit = model.fit_forecast

        def audited_fit(observations):
            fit_sets.append(set(observations))
            return original_fit(observations)

        with patch.object(model, "fit_forecast", side_effect=audited_fit):
            predictions = pipeline.development_forecasts(train)
        self.assertEqual(len(fit_sets), 12)
        self.assertEqual(set(predictions), {day for day in days if day.day > 21})
        self.assertEqual(len(predictions), 114)
        for month, used in enumerate(fit_sets, start=1):
            self.assertEqual(used, {date(2024, month, day) for day in range(1, 22)})
            self.assertLess(max(used), min(day for day in predictions if day.month == month))
        for day, prediction in predictions.items():
            # Large values held out on days22+ would expose leakage immediately.
            np.testing.assert_array_equal(prediction, np.full(len(prediction), day.month * 100.))

    def test_development_rejects_test_year_before_fitting(self):
        with self.assertRaises(ValueError):
            pipeline.development_forecasts({date(2025, 5, 1): np.zeros(48)})

    def test_outturn_changes_cannot_change_forecast_policy_schedule(self):
        day = date(2025, 11, 3)
        forecast = np.ones(48)
        forecast[28] = 11
        changed_actual = np.ones(48)
        changed_actual[0] = 11
        # A tiny grid isolates the information boundary without rerunning the
        # annual experiment. The opening-spike oracle must change its decision.
        with patch.object(pipeline, "POWERS_MW", (2,)), patch.object(pipeline, "DURATIONS_H", (1,)):
            _, first, _ = pipeline.evaluate({day: forecast.copy()}, {day: forecast}, export_cases=True)
            _, second, _ = pipeline.evaluate({day: changed_actual}, {day: forecast}, export_cases=True)
        first_policies = first[day.isoformat()]["scenarios"]["2_1"]["policies"]
        second_policies = second[day.isoformat()]["scenarios"]["2_1"]["policies"]
        for policy in ["no_action", "rule", "forecast_lp"]:
            np.testing.assert_array_equal(first_policies[policy]["flow_mw"], second_policies[policy]["flow_mw"])
        self.assertFalse(np.allclose(first_policies["hindsight_lp"]["flow_mw"], second_policies["hindsight_lp"]["flow_mw"]))


if __name__ == "__main__":
    unittest.main()
