"""Independent mathematical and calendar checks for the energy reference study.

Run from the project directory: python -m unittest discover -s tests -v
The sequential peak-feasibility oracle below does not construct or solve an LP.
"""

from datetime import date, timedelta
from pathlib import Path
import math
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import energy_model as model


def independent_peak_oracle(demand, power, capacity):
    """Bisection on a greedy reachability test, independent of LP matrix assembly.

    For a proposed peak, keeping as much energy as possible dominates every lower
    reachable state before a later mandatory discharge. Surplus terminal energy
    can be removed by reducing earlier charging, which cannot raise the peak.
    Thus the test certifies existence of an empty-to-empty schedule, rather than
    treating its maximally charged trajectory as the returned cyclic schedule.
    """
    demand = np.asarray(demand, dtype=float)

    def feasible(peak):
        state = 0.0
        for value in demand:
            headroom = peak - value
            if headroom >= 0:
                state = min(capacity, state + 0.5 * min(power, headroom))
            else:
                required = -headroom
                if required > power + 1e-10 or 0.5 * required > state + 1e-10:
                    return False
                state -= 0.5 * required
        return True

    lower = max(float(demand[0]), float(demand.mean()), float(demand.max()) - power)
    upper = float(demand.max())
    for _ in range(70):
        midpoint = (lower + upper) / 2
        if feasible(midpoint):
            upper = midpoint
        else:
            lower = midpoint
    return upper


class ScheduleAssertions(unittest.TestCase):
    def assert_feasible(self, result, demand, power, capacity):
        flow = np.asarray(result["flow_mw"])
        state = np.asarray(result["energy_mwh"])
        self.assertEqual(flow.shape, (len(demand),))
        self.assertEqual(state.shape, (len(demand) + 1,))
        self.assertTrue(np.isfinite(flow).all())
        self.assertTrue(np.isfinite(state).all())
        self.assertLessEqual(float(np.abs(flow).max()), power + 2e-5)
        self.assertGreaterEqual(float(state.min()), -2e-5)
        self.assertLessEqual(float(state.max()), capacity + 2e-5)
        self.assertAlmostEqual(float(state[0]), 0, delta=2e-5)
        self.assertAlmostEqual(float(state[-1]), 0, delta=2e-5)
        np.testing.assert_allclose(np.diff(state), 0.5 * flow, atol=2e-5, rtol=0)
        self.assertAlmostEqual(float(flow.sum()) * 0.5, 0, delta=2e-5)
        self.assertAlmostEqual(result["peak_mw"], float(np.max(demand + flow)), delta=2e-5)
        self.assertAlmostEqual(result["throughput_mwh"], float(np.abs(flow).sum()) * 0.5, delta=2e-5)


class OptimizationTests(ScheduleAssertions):
    def test_two_settlement_analytic_optimum_and_units(self):
        demand = np.array([0.0, 4.0])
        result = model.solve_schedule(demand, 4, 2)
        self.assert_feasible(result, demand, 4, 2)
        self.assertAlmostEqual(result["stage1_peak_mw"], 2, delta=1e-6)
        np.testing.assert_allclose(result["flow_mw"], [2, -2], atol=3e-5, rtol=0)
        np.testing.assert_allclose(result["energy_mwh"], [0, 1, 0], atol=3e-5, rtol=0)
        self.assertAlmostEqual(result["throughput_mwh"], 2, delta=3e-5)

    def test_energy_and_power_bottlenecks_have_distinct_optima(self):
        demand = np.array([0.0, 4.0])
        for power, capacity, expected in [(4, 0.5, 3), (0.5, 4, 3.5), (4, 2, 2)]:
            with self.subTest(power=power, capacity=capacity):
                result = model.solve_schedule(demand, power, capacity)
                self.assert_feasible(result, demand, power, capacity)
                self.assertAlmostEqual(result["stage1_peak_mw"], expected, delta=1e-6)

    def test_opening_spike_cannot_be_supplied_retroactively(self):
        demand = np.array([10.0, 0, 0, 0])
        result = model.solve_schedule(demand, 20, 20)
        self.assert_feasible(result, demand, 20, 20)
        self.assertAlmostEqual(result["stage1_peak_mw"], 10, delta=1e-6)
        np.testing.assert_allclose(result["flow_mw"], 0, atol=2e-5, rtol=0)

    def test_flat_profile_lexicographic_objective_removes_pointless_cycling(self):
        demand = np.full(48, 1234.0)
        result = model.solve_schedule(demand, 2000, 8000)
        self.assert_feasible(result, demand, 2000, 8000)
        self.assertAlmostEqual(result["stage1_peak_mw"], 1234, delta=1e-6)
        self.assertAlmostEqual(result["throughput_mwh"], 0, delta=2e-5)

    def test_zero_resources_return_control(self):
        demand = np.array([3.0, 1, 4, 1, 5])
        for power, capacity in [(0, 0), (0, 5), (5, 0)]:
            with self.subTest(power=power, capacity=capacity):
                result = model.solve_schedule(demand, power, capacity)
                self.assert_feasible(result, demand, power, capacity)
                np.testing.assert_allclose(result["flow_mw"], 0, atol=1e-8, rtol=0)

    def test_single_settlement_is_control(self):
        result = model.solve_schedule([10], 100, 100)
        self.assert_feasible(result, np.array([10.0]), 100, 100)
        self.assertAlmostEqual(result["stage1_peak_mw"], 10, delta=1e-6)

    def test_lp_matches_independent_reachability_oracle(self):
        rng = np.random.default_rng(142026)
        cases = [np.array([0., 0, 9]), np.array([0., 9, 0, 9]), np.array([8., 1, 9, 2])]
        cases.extend(rng.uniform(0, 100, size=n) for n in [4, 7, 10, 46, 48, 50])
        for demand in cases:
            for power, capacity in [(0.7, 0.2), (5, 3), (30, 40)]:
                with self.subTest(length=len(demand), power=power, capacity=capacity):
                    result = model.solve_schedule(demand, power, capacity)
                    self.assert_feasible(result, demand, power, capacity)
                    expected = independent_peak_oracle(demand, power, capacity)
                    self.assertAlmostEqual(result["stage1_peak_mw"], expected, delta=2e-5)
                    self.assertLessEqual(result["peak_mw"], result["stage1_peak_mw"] + 2e-5)

    def test_hindsight_optimum_is_monotonic_in_resources(self):
        rng = np.random.default_rng(1409)
        demand = rng.uniform(20_000, 40_000, 48)
        for vary_power in [True, False]:
            peaks = []
            for limit in [0, 250, 500, 1000, 2000, 4000]:
                power, capacity = (limit, 2000) if vary_power else (1000, limit)
                peaks.append(model.solve_schedule(demand, power, capacity)["stage1_peak_mw"])
            self.assertTrue(all(b <= a + 2e-5 for a, b in zip(peaks, peaks[1:])))

    def test_invalid_demand_and_capacity_are_rejected(self):
        for function in [model.solve_schedule, model.forecast_window_rule]:
            for demand in [[], [float("nan")], [float("inf")]]:
                with self.subTest(function=function.__name__, demand=demand):
                    with self.assertRaises((ValueError, TypeError)):
                        function(demand, 1, 1)
            for power, capacity in [(-1, 1), (1, -1), (math.inf, 1), (1, math.nan)]:
                with self.subTest(function=function.__name__, power=power, capacity=capacity):
                    with self.assertRaises((ValueError, TypeError)):
                        function([1, 2], power, capacity)


class RuleTests(ScheduleAssertions):
    def test_window_selection_energy_units_and_earliest_ties(self):
        # Earliest maximum is period 7, so discharge begins period 6. The two
        # available charge blocks tie, requiring periods 1..4, not 2..5.
        demand = np.array([1., 1, 1, 1, 1, 2, 9, 8, 7, 1, 1, 1])
        result = model.forecast_window_rule(demand, 4, 4)
        expected = np.array([2., 2, 2, 2, 0, -2, -2, -2, -2, 0, 0, 0])
        np.testing.assert_allclose(result["flow_mw"], expected, atol=1e-10, rtol=0)
        self.assert_feasible(result, demand, 4, 4)

    def test_no_preceding_charge_window_means_no_action(self):
        for demand in [np.array([9., 1, 1, 1, 1, 1, 1, 1]), np.array([1., 9, 1])]:
            result = model.forecast_window_rule(demand, 4, 4)
            self.assert_feasible(result, demand, 4, 4)
            np.testing.assert_allclose(result["flow_mw"], 0, atol=1e-10, rtol=0)

    def test_rule_is_deterministic_and_feasible_for_calendar_lengths(self):
        rng = np.random.default_rng(907)
        for length in [46, 48, 50]:
            demand = rng.uniform(10_000, 30_000, length)
            for power, capacity in [(0, 0), (500, 250), (1000, 8000)]:
                result = model.forecast_window_rule(demand, power, capacity)
                repeat = model.forecast_window_rule(demand, power, capacity)
                self.assert_feasible(result, demand, power, capacity)
                np.testing.assert_array_equal(result["flow_mw"], repeat["flow_mw"])


class ValidationTests(unittest.TestCase):
    def test_infeasible_external_schedules_are_rejected(self):
        for flow, power, capacity in [([2., -2.], 1, 2), ([2., -2.], 2, 0.5),
                                      ([-1., 1.], 2, 2), ([1., 0.], 2, 2)]:
            with self.subTest(flow=flow, power=power, capacity=capacity):
                with self.assertRaisesRegex(ValueError, "Infeasible schedule"):
                    model.validate_schedule(flow, power, capacity)

    def test_source_rejects_missing_columns_nonfinite_nd_duplicates_and_missing_dates(self):
        header = "SETTLEMENT_DATE,SETTLEMENT_PERIOD,ND\n"
        cases = [("SETTLEMENT_DATE,SETTLEMENT_PERIOD\n", "Missing required source columns"),
                 (header + "2025-01-01,1,nan\n", "finite and positive"),
                 (header + "2025-01-01,1,10\n2025-01-01,1,20\n", "Duplicate settlement"),
                 (header + "2025-01-01,1,10\n", "Missing dates")]
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "source.csv"
            for body, message in cases:
                with self.subTest(message=message):
                    path.write_text(body, encoding="utf-8")
                    with self.assertRaisesRegex(ValueError, message):
                        model.load_demand(path)

    def test_source_checksum_guard_runs_before_parsing(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "source.csv"
            path.write_text("untrusted altered bytes", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "checksum"):
                model.load_demand(path, expected_sha256="0" * 64)


class CalendarTests(unittest.TestCase):
    def test_short_ordinary_and_long_days(self):
        for day, expected_length in [(date(2024, 3, 31), 46), (date(2025, 3, 30), 46),
                                     (date(2025, 11, 3), 48), (date(2024, 10, 27), 50),
                                     (date(2025, 10, 26), 50)]:
            with self.subTest(day=day):
                labels = model.settlement_labels(day)
                self.assertEqual(len(labels), expected_length)
                self.assertEqual([row["period"] for row in labels], list(range(1, expected_length + 1)))
                self.assertEqual(len({row["iso_utc"] for row in labels}), expected_length)
                self.assertEqual(labels[0]["local_time"], "00:00")
                self.assertEqual(labels[-1]["local_time"], "23:30")

    def test_spring_hour_absent(self):
        clocks = [row["local_time"] for row in model.settlement_labels(date(2025, 3, 30))]
        self.assertNotIn("01:00", clocks)
        self.assertNotIn("01:30", clocks)

    def test_autumn_hour_has_distinct_settlements_and_offsets(self):
        labels = model.settlement_labels(date(2025, 10, 26))
        for clock in ["01:00", "01:30"]:
            repeated = [row for row in labels if row["local_time"] == clock]
            self.assertEqual(len(repeated), 2)
            self.assertEqual({row["fold"] for row in repeated}, {0, 1})
            self.assertEqual({row["utc_offset"] for row in repeated}, {"+00:00", "+01:00"})

    def test_utc_intervals_are_always_half_hours_including_dst(self):
        from datetime import datetime
        for day in [date(2025, 3, 30), date(2025, 10, 26)]:
            timestamps = [datetime.fromisoformat(row["iso_utc"]) for row in model.settlement_labels(day)]
            self.assertTrue(all(b - a == timedelta(minutes=30) for a, b in zip(timestamps, timestamps[1:])))


class ForecastTests(unittest.TestCase):
    def test_fit_predict_known_clock_values_and_repeated_hour(self):
        # A single ordinary October Sunday supplies every clock bin. Prediction
        # on the long October Sunday must repeat bins while retaining 50 values.
        profile = model.fit_forecast({date(2024, 10, 6): np.arange(48, dtype=float) + 100})
        day = date(2025, 10, 26)
        prediction = model.predict_forecast(day, profile)
        expected = [100 + int(row["local_time"][:2]) * 2 + int(row["local_time"][3:]) / 30
                    for row in model.settlement_labels(day)]
        np.testing.assert_array_equal(prediction, expected)

    def test_fit_uses_month_daytype_clock_mean_without_cross_group_blending(self):
        training = {date(2024, 5, 6): np.full(48, 10.), date(2024, 5, 7): np.full(48, 30.),
                    date(2024, 5, 5): np.full(48, 80.), date(2024, 6, 3): np.full(48, 90.)}
        profile = model.fit_forecast(training)
        np.testing.assert_array_equal(model.predict_forecast(date(2025, 5, 1), profile), np.full(48, 20.))
        np.testing.assert_array_equal(model.predict_forecast(date(2025, 5, 4), profile), np.full(48, 80.))
        np.testing.assert_array_equal(model.predict_forecast(date(2025, 6, 2), profile), np.full(48, 90.))

    def test_training_rejects_test_year(self):
        with self.assertRaises(ValueError):
            model.fit_forecast({date(2024, 5, 6): np.full(48, 10.), date(2025, 5, 5): np.full(48, 900.)})

    def test_missing_forecast_group_is_rejected_not_silently_imputed(self):
        profile = model.fit_forecast({date(2024, 5, 6): np.full(48, 10.)})
        with self.assertRaises((ValueError, KeyError)):
            model.predict_forecast(date(2025, 6, 2), profile)


if __name__ == "__main__":
    unittest.main()
