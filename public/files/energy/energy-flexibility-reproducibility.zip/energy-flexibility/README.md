# How much peak relief can flexibility provide?

An independent Decision Science and Analytics study by Abdulaziz Aldoseri. It explores how hypothetical ideal storage power and energy limits affect Great Britain's daily National Demand (ND) peaks, and how forecast error changes the value of an optimized schedule.

The numerical reference model and chronological evaluation are implemented locally. Historic annual data can be revised; this is not a backtest certified against a full history of data available at each decision time. It is a retrospective, precomputed demonstration, not commissioned work for NESO, a deployed controller, an equipment recommendation or a financial investment case.

**Interpretation boundary:** the displayed forecast LP is one frozen solver-selected schedule among solutions that can share the same best forecast peak and minimum throughput. Its observed 532.10 MW mean relief and 15 worsened days at 1,000 MW/two hours are specific to that selection. A later adversarial diagnostic found materially different outturn results for another forecast-only selection among tied solutions. The original results remain unchanged; the explicitly post-hoc sensitivity analysis is documented in `RESULTS.md` and `diagnostics/`. It is not a newly validated replacement policy.

## Reproduce

Use Python 3.12 and the pinned dependencies. No credentials or paid service are needed.

```sh
python -m venv .venv
# Activate your virtual environment using the command for your shell.
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest discover -s tests -v
```

The supplied `data/` files are the unchanged, openly licensed source snapshots. The pipeline verifies their SHA-256 values before fitting or evaluating. An optional local `.deps/` folder was used on the author's development machine and is ignored by version control; it is not part of the distributable project. No paths outside this project are needed by the code.

`reference_study.ipynb` is a technical companion containing readable formulation notes and code to inspect results and independently rerun a selected forecast schedule. For local Jupyter, run it from this project folder after installing the requirements; its optional Colab setup cell skips itself locally.

For Google Colab, choose File → Upload notebook, select the `.ipynb`, run its first setup cell and upload the complete reproduction ZIP when prompted. That cell checks the package manifest, safely extracts the files into `/content/energy-flexibility`, installs the pinned requirements and selects the project folder. Use a fresh CPU runtime; no Drive connection is needed. The code cells passed sequential local execution. The Colab branch passed a mocked upload/install test with real extraction and analysis of the extracted project. Actual hosted Colab and notebook-kernel execution were not performed, and no public hosted notebook URL is claimed.

## What is evaluated

- **No action:** no additional flexibility.
- **Forecast-window rule:** fixed two-hour charge and discharge windows chosen from the forecast.
- **Forecast LP:** minimize forecast adjusted ND peak, then minimize absolute energy movement while retaining that peak within 0.00001 MW. The frozen SciPy/HiGHS solution resolves any remaining ties numerically; those ties can affect realized outcomes.
- **Hindsight LP:** the same ideal model supplied with the day's actual ND. This is a perfect-information reference bound, not an information-equivalent competitor.

The forecast is an intentionally simple 2024 mean by month, weekday/weekend and London local half-hour. Before the final fit, each month's first 21 days are used to estimate its remaining 2024 days. The primary reference parameters and policy choices were frozen before 2025 policy evaluation and remain unchanged. The held-out horizon is every day from 1 May through 31 December 2025. The later tie-selection diagnostic uses that already-inspected horizon and is therefore exploratory, not a fresh held-out policy validation.

The capacity grid is 0, 500, 1,000 and 2,000 MW, each with 1, 2 and 4 hours of duration. Energy capacity is power multiplied by duration. All 12 combinations are retained, including three identical zero-power controls, to keep the interactive selector consistent. These are hypothetical engineering constraints, not a dataset of real GB assets.

See [METHODS.md](METHODS.md), [RESULTS.md](RESULTS.md) and [data/README.md](data/README.md) for interpretation and limitations.

## Files

| File | Purpose |
| --- | --- |
| `energy_model.py` | Calendar mapping, strict data reader, frozen forecast, rule and LP |
| `pipeline.py` | Development checks, held-out evaluation, source checks and exports |
| `outputs/protocol.json` | Frozen choices and hashes of the code used to run them |
| `outputs/daily_results.csv` | Full-precision results for every test day, scenario and policy |
| `outputs/development_daily_results.csv` | Corresponding 2024 development evaluation |
| `outputs/summary.json` | All-day aggregate curves and distribution summaries |
| `outputs/monthly_summary.json`, `weekday_summary.json` | Segmented outcomes |
| `outputs/forecast_errors.csv` | Daily MAE, bias and peak estimates |
| `outputs/frozen_forecast_profile.json` | Final fitted forecast values |
| `outputs/public_results.json` | Complete browser data, including every daily trajectory |
| `outputs/public_index.json`, `outputs/days/` | Small initial index and individual daily browser payloads |
| `outputs/verification.json` | Runtime, dependency versions, residuals and checks |
| `diagnostics/tie_sensitivity.py`, `.json`, `_daily.csv` | Separate post-hoc exploration of tied forecast-LP schedules; primary results unchanged |
| `tests/` | Independent verification supplied with the project |

The browser dataset is explicitly precomputed. It does not execute an optimization server or accept arbitrary unvalidated parameter values. Positive flow means charging; negative flow means discharging. Energy arrays contain T+1 state boundaries for T actual settlements. The 50-interval October day retains both occurrences of the repeated hour.

## Attribution and rights

**Supported by National Energy SO Open Data.** Historic Demand Data 2024/2025, retrieved 14 September 2026; processing and model by Abdulaziz Aldoseri.

[Source](https://www.neso.energy/data-portal/historic-demand-data) · [National Energy SO Open Data Licence v1.0](https://www.neso.energy/data-portal/neso-open-licence)

Data reuse is governed by the provider's licence and does not imply NESO endorsement. Original code licensing is a separate release decision; the data licence does not grant rights to this project's original code or provider logos. Recheck source licence terms before a public release.
