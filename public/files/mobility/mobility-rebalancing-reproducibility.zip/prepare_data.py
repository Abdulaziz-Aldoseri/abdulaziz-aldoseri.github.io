"""Reproduce aggregate historical morning flows from six unchanged TfL CSVs.

No forecasting, fitting, inventory imputation or optimization occurs here. The
default source directory is private. Supply --source-dir to reproduce elsewhere.
Only station-level aggregates and source metadata are public export candidates.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path

SCHEMA = ['Number', 'Start date', 'Start station number', 'Start station',
          'End date', 'End station number', 'End station', 'Bike number',
          'Bike model', 'Total duration', 'Total duration (ms)']
SOURCES = [
 ('435JourneyDataExtract01Jan2026-15Jan2026.csv', '474ffe3d116f8a9fac7927dc7a93c614878ab7d3a6ba917724fe655f5fa04db4'),
 ('436JourneyDataExtract16Jan2026-31Jan2026.csv', '2cbe54b6fe1f9f27ab51444fec668f1cbe24b7e4a2392d58a20c27a364721519'),
 ('437JourneyDataExtract01Feb2026-14Feb2026.csv', 'eb624940bb031c1911f17564182f902fa9e39cfe53eeefc2f1ebcdc453f03628'),
 ('438JourneyDataExtract15Feb2026-28Feb2026.csv', '5a9f13cc3db14812a34caf883a4abee3bf661a123af65a85474a9e53e47056cc'),
 ('439JourneyDataExtract01Mar2026-15Mar2026.csv', 'efe13af56384899a09bdd27036eaeebe071412faa24c3f6847a2778689b5d9f7'),
 ('440JourneyDataExtract15Mar2026-31Mar2026.csv', 'a5d49bcf06c295f6a5ae0a7db8fa976e1423c10bf5231801b8bb2ee8ef462005'),
]
VARIANTS = {'primary_24h': 86400000, 'duration_12h': 43200000,
            'duration_48h': 172800000, 'duration_unrestricted': None}
AGGREGATE_CSV_FILES = tuple(sorted([f'{variant}.csv' for variant in VARIANTS] +
                                  ['station_register.csv', 'excluded_station_register.csv', 'daily_coverage.csv']))
PUBLIC_OUTPUT_FILES = set(AGGREGATE_CSV_FILES) | {'preparation_summary.json', 'SOURCE_MANIFEST.json'}
FIRST = dt.date(2026, 1, 1)
LAST = dt.date(2026, 3, 22)
TRAIN_FIRST = dt.date(2026, 1, 5)
TRAIN_LAST = dt.date(2026, 2, 15)
ADMISSION_CUTOFF = dt.datetime(2026, 2, 16)
VAL_LAST = dt.date(2026, 3, 1)
CREDITS = ['Powered by TfL Open Data',
           'Contains OS data © Crown copyright and database rights 2016',
           'Geomni UK Map data © and database rights [2019]']


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def split(day):
    if day < TRAIN_FIRST:
        return 'warmup'
    if day <= TRAIN_LAST:
        return 'training'
    if day <= VAL_LAST:
        return 'validation'
    return 'test'


def in_window(timestamp):
    return dt.time(6) <= timestamp.time() < dt.time(10)


def excluded_name(name):
    name = name.casefold()
    return 'workshop' in name or '_old' in name


def parse_row(row):
    """Accept positive reported duration and nondecreasing naive event times."""
    if set(row) != set(SCHEMA) or any(row[k] is None or not row[k].strip() for k in SCHEMA):
        raise ValueError('missing field or schema mismatch')
    start = dt.datetime.fromisoformat(row['Start date'])
    end = dt.datetime.fromisoformat(row['End date'])
    duration = int(row['Total duration (ms)'])
    if start.tzinfo is not None or end.tzinfo is not None:
        raise ValueError('unexpected timezone offset: review clock rule')
    if end < start or duration <= 0:
        raise ValueError('nonpositive duration or reversed event times')
    return start, end, duration


class Preparation:
    def __init__(self):
        self.seen = {}
        self.counts = collections.Counter()
        self.file_counts = collections.defaultdict(collections.Counter)
        self.exceptions = []
        self.names = collections.defaultdict(set)
        self.training_names = collections.defaultdict(set)
        self.first_names = {}
        self.excluded = collections.defaultdict(lambda: {'names': set(), 'journeys': 0})
        self.raw_start_dates = collections.Counter()
        self.events = {v: collections.Counter() for v in VARIANTS}
        self.raw_event_totals = {v: collections.Counter() for v in VARIANTS}
        self.stations = set()
        self.training_active = collections.defaultdict(set)
        self.training_all_day = collections.defaultdict(set)
        self.variant_stages = {v: collections.Counter() for v in VARIANTS}
        self.boundaries = {v: collections.Counter() for v in VARIANTS}
        self.duration_clock_difference = collections.Counter()

    def consume(self, row, source='fixture', line=0):
        self.counts['raw_rows'] += 1
        fc = self.file_counts[source]
        fc['raw_rows'] += 1
        if set(row) != set(SCHEMA) or row.get('Number') is None or not row['Number'].strip():
            self.counts['invalid_rows'] += 1
            self.exceptions.append({'source': source, 'line': line, 'journey_id': row.get('Number', ''), 'kind': 'invalid schema or empty ID'})
            return
        jid = row['Number']
        # SHA-256 of an unambiguous ordered JSON record; randomized Python hash
        # and ambiguous string concatenation cannot identify exact duplicates.
        digest = hashlib.sha256(json.dumps([row[k] for k in SCHEMA], ensure_ascii=False, separators=(',', ':')).encode()).digest()
        if jid in self.seen:
            kind = 'exact_duplicate_rows' if self.seen[jid] == digest else 'conflicting_duplicate_rows'
            self.counts[kind] += 1
            fc[kind] += 1
            self.exceptions.append({'source': source, 'line': line, 'journey_id': jid, 'kind': kind})
            return
        self.seen[jid] = digest
        self.counts['unique_journey_ids'] += 1
        try:
            start, end, duration = parse_row(row)
        except (ValueError, TypeError, OverflowError) as exc:
            self.counts['invalid_rows'] += 1
            self.exceptions.append({'source': source, 'line': line, 'journey_id': jid, 'kind': str(exc)})
            return
        self.counts['valid_unique_journeys'] += 1
        self.raw_start_dates[start.date().isoformat()] += 1
        clock_difference = duration - int((end - start).total_seconds() * 1000)
        self.duration_clock_difference['within_one_minute'] += abs(clock_difference) < 60000
        self.duration_clock_difference['one_minute_or_more'] += abs(clock_difference) >= 60000
        if FIRST <= start.date() <= LAST and end.date() <= LAST:
            self.duration_clock_difference['panel_period_rows'] += 1
            self.duration_clock_difference['panel_period_one_minute_or_more'] += abs(clock_difference) >= 60000
            self.duration_clock_difference['panel_period_max_absolute_difference_ms'] = max(self.duration_clock_difference['panel_period_max_absolute_difference_ms'], abs(clock_difference))
        self.counts['cross_calendar_date'] += start.date() != end.date()
        self.counts['same_station_journeys'] += row['Start station number'] == row['End station number']
        flagged = set()
        for side in ('Start', 'End'):
            sid, name = row[f'{side} station number'], row[f'{side} station']
            self.names[sid].add(name)
            if excluded_name(name):
                flagged.add(sid)
                self.excluded[sid]['names'].add(name)
        for sid in flagged:
            self.excluded[sid]['journeys'] += 1
        if row['Bike model'] != 'CLASSIC':
            self.counts['non_classic_excluded'] += 1
            return
        self.counts['classic_valid_journeys'] += 1
        for variant, limit in VARIANTS.items():
            stage = self.variant_stages[variant]
            stage['classic_before_duration'] += 1
            if limit is not None and duration > limit:
                stage['duration_excluded'] += 1
                continue
            stage['after_duration'] += 1
            if flagged:
                stage['whole_journey_endpoint_excluded'] += 1
                continue
            stage['eligible_journeys_all_source_dates'] += 1
            if variant == 'primary_24h' and end >= ADMISSION_CUTOFF and any(TRAIN_FIRST <= t.date() <= TRAIN_LAST for t in (start, end)):
                stage['journeys_with_training_event_but_not_completed_before_admission_cutoff'] += 1
            bounds = self.boundaries[variant]
            # Count events independently: a trip may cross dates or either
            # window boundary. Its departure and arrival need not both appear.
            for side, timestamp, coordinate in [('Start', start, 0), ('End', end, 1)]:
                sid, name = row[f'{side} station number'], row[f'{side} station']
                day = timestamp.date()
                if variant == 'primary_24h' and FIRST <= day <= LAST:
                    self.stations.add(sid)
                    first = self.first_names.get(sid)
                    if first is None or (timestamp, name) < first:
                        self.first_names[sid] = (timestamp, name)
                    if TRAIN_FIRST <= day <= TRAIN_LAST and end < ADMISSION_CUTOFF:
                        self.training_names[sid].add(name)
                        self.training_all_day[sid].add(day)
                if timestamp.time() == dt.time(6):
                    bounds['events_exactly_0600_all_source_dates'] += 1
                if timestamp.time() == dt.time(10):
                    bounds['events_exactly_1000_all_source_dates'] += 1
                if not in_window(timestamp):
                    continue
                if side == 'End' and start.date() < day:
                    bounds['morning_arrivals_prior_date_starts_all_source_dates'] += 1
                if not FIRST <= day <= LAST:
                    bounds['morning_events_outside_panel'] += 1
                    continue
                self.stations.add(sid)
                key = (day.isoformat(), sid, coordinate)
                self.events[variant][key] += 1
                self.raw_event_totals[variant][(day.isoformat(), coordinate)] += 1
                if side == 'End' and start.date() < day:
                    bounds['morning_arrivals_prior_date_starts_in_panel'] += 1
                    if day >= TRAIN_FIRST:
                        bounds['morning_arrivals_prior_date_starts_in_evaluation'] += 1
                if side == 'End' and start.date() < TRAIN_FIRST and day >= TRAIN_FIRST:
                    bounds['evaluation_morning_arrivals_from_warmup_starts'] += 1
                if variant == 'primary_24h' and TRAIN_FIRST <= day <= TRAIN_LAST and end < ADMISSION_CUTOFF:
                    self.training_active[sid].add(day)

    def assert_publishable(self):
        if self.counts['conflicting_duplicate_rows'] or self.counts['invalid_rows']:
            raise ValueError('Conflicting journey IDs or invalid rows require review; no aggregate export authorized')


def write_csv(path, fields, records):
    with Path(path).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(records)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def validate_public_output(output):
    """A public reproduction directory cannot inherit unrelated/private files."""
    if output.exists():
        unexpected = [p.name for p in output.iterdir()
                      if p.name not in PUBLIC_OUTPUT_FILES or not p.is_file() or p.is_symlink()]
        if unexpected:
            raise ValueError('Public output contains unexpected paths: '+', '.join(sorted(unexpected)))


def days():
    return [FIRST + dt.timedelta(days=i) for i in range((LAST-FIRST).days+1)]


def register(prepared, min_active_days, min_active_weeks):
    rows = []
    for sid in sorted(prepared.stations):
        names = sorted(prepared.training_names[sid])
        active = sorted(prepared.training_active[sid])
        weeks = len({(day-TRAIN_FIRST).days//7 for day in active})
        admitted = len(names) == 1 and len(active) >= min_active_days and weeks >= min_active_weeks
        status = ('admitted' if admitted else 'no_training_name' if not names else
                  'ambiguous_training_name' if len(names) != 1 else 'insufficient_training_coverage')
        first = prepared.first_names.get(sid)
        rows.append({'station_id': sid, 'name': names[0] if len(names) == 1 else first[1] if first else f'Station {sid}',
                     'name_provenance': 'training_primary_24h_completed_before_cutoff' if len(names) == 1 else 'first_observed_primary_source_label_not_training' if first else 'neutral_identifier_label',
                     'training_names': ' | '.join(names),
                     'first_observed_name': first[1] if first else '',
                     'first_observed_at': first[0].isoformat(sep=' ') if first else '',
                     'first_eligible_event_date': first[0].date().isoformat() if first else '',
                     'training_active_morning_days': len(active), 'training_active_morning_weeks': weeks,
                     'training_observed_all_day_days': len(prepared.training_all_day[sid]),
                     'first_training_morning_date': active[0].isoformat() if active else '',
                     'last_training_morning_date': active[-1].isoformat() if active else '',
                     'intervention_eligible': int(admitted), 'eligibility_status': status})
    return rows


def export(prepared, output, resources, min_active_days, min_active_weeks):
    prepared.assert_publishable()
    if any(not prepared.raw_start_dates[d.isoformat()] for d in days()):
        raise ValueError('Missing network start-date source coverage; no aggregate export authorized')
    output.mkdir(parents=True, exist_ok=True)
    dates = days()
    registers = register(prepared, min_active_days, min_active_weeks)
    write_csv(output/'station_register.csv', list(registers[0]), registers)
    excluded_rows = [{'station_id': sid, 'source_names': ' | '.join(sorted(v['names'])),
                      'raw_journeys_with_endpoint': v['journeys'], 'rule': 'workshop_or_old_label'}
                     for sid, v in sorted(prepared.excluded.items())]
    write_csv(output/'excluded_station_register.csv', ['station_id', 'source_names', 'raw_journeys_with_endpoint', 'rule'], excluded_rows)
    stations = sorted(prepared.stations)
    admitted = {r['station_id'] for r in registers if r['intervention_eligible']}
    fields = ['date', 'split', 'station_id', 'departures', 'arrivals', 'net_outflow', 'history_available']
    verification = {}
    split_totals = {}
    daily_coverage = []
    for variant in VARIANTS:
        records = []
        totals = collections.Counter()
        split_count = collections.defaultdict(collections.Counter)
        zero_cells = 0
        for day in dates:
            iso = day.isoformat()
            coverage = collections.Counter()
            if not prepared.raw_start_dates[iso]:
                raise ValueError(f'No raw starts for {iso}; cannot record-impute a populated-network panel')
            for sid in stations:
                departures = prepared.events[variant][(iso, sid, 0)]
                arrivals = prepared.events[variant][(iso, sid, 1)]
                first = prepared.first_names.get(sid)
                known = first is not None and first[0].date() <= day
                coverage['stations_with_primary_history'] += known
                coverage['stations_with_recorded_morning_events'] += departures + arrivals > 0
                coverage['admitted_stations_with_recorded_morning_events'] += sid in admitted and departures + arrivals > 0
                if sid not in admitted:
                    coverage['outside_cohort_departures'] += departures
                    coverage['outside_cohort_arrivals'] += arrivals
                records.append(dict(zip(fields, [iso, split(day), sid, departures, arrivals, departures-arrivals, int(known)])))
                totals[(iso, 0)] += departures
                totals[(iso, 1)] += arrivals
                zero_cells += departures == 0 and arrivals == 0
                split_count[split(day)]['departures'] += departures
                split_count[split(day)]['arrivals'] += arrivals
            daily_coverage.append({'variant': variant, 'date': iso, 'split': split(day),
                                   'raw_source_start_rows': prepared.raw_start_dates[iso],
                                   'network_departures': totals[(iso, 0)], 'network_arrivals': totals[(iso, 1)],
                                   'network_net_outflow': totals[(iso, 0)]-totals[(iso, 1)],
                                   **{key: coverage[key] for key in ['stations_with_primary_history', 'stations_with_recorded_morning_events', 'admitted_stations_with_recorded_morning_events', 'outside_cohort_departures', 'outside_cohort_arrivals']}})
        expected = prepared.raw_event_totals[variant]
        assert all(totals[(d.isoformat(), side)] == expected[(d.isoformat(), side)] for d in dates for side in (0, 1))
        write_csv(output/f'{variant}.csv', fields, records)
        split_totals[variant] = {s: {**dict(c), 'net_outflow': c['departures']-c['arrivals']} for s, c in split_count.items()}
        verification[variant] = {'rows': len(records), 'stations': len(stations), 'days': len(dates),
                                 'aggregate_totals_match_counted_events': True, 'zero_activity_station_days': zero_cells}
    write_csv(output/'daily_coverage.csv', list(daily_coverage[0]), daily_coverage)
    summary = {
        'status': 'PASS', 'raw_counts': dict(prepared.counts),
        'files': {k: dict(v) for k, v in prepared.file_counts.items()},
        'variant_stages': {v: dict(c) for v, c in prepared.variant_stages.items()},
        'boundary_events': {v: dict(c) for v, c in prepared.boundaries.items()},
        'duration_vs_minute_timestamps': dict(prepared.duration_clock_difference),
        'all_raw_station_ids': len(prepared.names), 'all_raw_name_conflicts': {s: sorted(n) for s, n in prepared.names.items() if len(n)>1},
        'panel_stations': len(stations), 'register_status_counts': dict(collections.Counter(r['eligibility_status'] for r in registers)),
        'intervention_eligibility': {'minimum_training_active_morning_days': min_active_days,
                                   'minimum_training_active_morning_weeks': min_active_weeks,
                                   'one_unambiguous_training_name_required': True,
                                   'journey_completion_strictly_before': ADMISSION_CUTOFF.isoformat(sep=' '),
                                   'frozen_training_period': ['2026-01-05', '2026-02-15']},
        'chronological_split_days': dict(collections.Counter(split(d) for d in dates)),
        'panel_verification': verification, 'split_totals': split_totals,
        'raw_start_date_counts': dict(sorted(prepared.raw_start_dates.items())),
        'excluded_stations': excluded_rows,
        'clock_assumption': 'Recorded naive times interpreted as Europe/London local clock. No provider offset confirmed. In this Jan1-Mar22 winter interval GMT equals UTC; there is no DST transition. No timestamps shifted.',
        'zero_interpretation': 'Zero means no qualifying recorded event in the available files at that station/date; never evidence of open status, no attempted demand, available bicycles or operational availability. Station operational availability is unknown for every date. history_available is false before the first primary eligible recorded event date: these earlier zero cells must not be used as forecast-history observations. This fixed primary history mask applies to all duration variants.',
        'left_boundary': 'No pre-Jan1 start records. Jan1-4 are warm-up only. Jan5 onward has complete source-start lookback for <=12h, <=24h and <=48h screens. Unrestricted-duration arrivals can originate before Jan1 and remain unobserved throughout; sensitivity is source-limited, not a complete full-duration flow benchmark.',
        'publication_lag': 'Six Jan-Mar files have provider June2026 modification dates. Retrospective event-time experiment, not proof of historical public-feed availability.',
        'model_fitted': False,
    }
    write_json(output/'preparation_summary.json', summary)
    manifest = {'provider': 'Transport for London', 'dataset': 'Santander Cycles journey data',
                'landing_url': 'https://cycling.data.tfl.gov.uk/',
                'documentation_url': 'https://tfl.gov.uk/info-for/open-data-users/our-open-data',
                'terms_url': 'https://tfl.gov.uk/corporate/terms-and-conditions/transport-data-service',
                'terms': 'TfL Transport Data Service terms, with TfL-specific amendments based on OGL v2.0',
                'required_credits': CREDITS, 'retrieval_date_utc': '2026-09-14',
                'raw_files': resources, 'transformations': 'Verified source hashes; exact parsed-record deduplication by journey ID; conflicting IDs and invalid rows fail closed; CLASSIC bikes, four reported-duration screens; whole-journey workshop/_OLD exclusion; independent actual start/end morning events; frozen training admission; aggregate-only exports.',
                'clock_assumption': summary['clock_assumption'], 'zero_interpretation': summary['zero_interpretation'],
                'left_boundary': summary['left_boundary'], 'source_data_licence_separate_from_code': True,
                'raw_journey_or_bike_identifiers_exported': False,
                'preparation_script_sha256': sha256(Path(__file__)),
                'aggregate_files': []}
    for filename in AGGREGATE_CSV_FILES:
        path = output/filename
        manifest['aggregate_files'].append({'path': path.name, 'bytes': path.stat().st_size, 'sha256': sha256(path)})
    write_json(output/'SOURCE_MANIFEST.json', manifest)
    return summary, manifest


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, default=here.parents[1]/'website/design/project_planning/mobility')
    parser.add_argument('--output-dir', type=Path, default=here/'data')
    parser.add_argument('--min-active-days', type=int, required=True)
    parser.add_argument('--min-active-weeks', type=int, required=True)
    parser.add_argument('--public-only', action='store_true', help='Do not write private journey-ID exception records; invalid data still fails closed')
    args = parser.parse_args()
    if not 1 <= args.min_active_days <= 42 or not 1 <= args.min_active_weeks <= 6:
        parser.error('Admission requires 1..42 active days and 1..6 active weeks')
    if args.public_only:
        try:
            validate_public_output(args.output_dir)
        except ValueError as exc:
            parser.error(str(exc))
    sources = []
    for filename, expected in SOURCES:
        path = args.source_dir/filename
        actual = sha256(path)
        if actual != expected:
            raise ValueError(f'Source checksum mismatch: {filename}')
        sources.append({'filename': filename, 'url': 'https://cycling.data.tfl.gov.uk/usage-stats/'+filename,
                        'sha256': actual, 'bytes': path.stat().st_size,
                        'provider_last_modified_utc': '2026-06-09T13:50:19.000Z' if filename.startswith(('439', '440')) else '2026-06-09T13:46:23.000Z'})
    prepared = Preparation()
    for resource in sources:
        path = args.source_dir/resource['filename']
        with path.open(encoding='utf-8-sig', newline='') as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames != SCHEMA:
                raise ValueError(f'Unexpected schema: {path.name}')
            for line, row in enumerate(reader, start=2):
                prepared.consume(row, path.name, line)
        print(json.dumps({'file': path.name, 'rows': prepared.file_counts[path.name]['raw_rows']}), flush=True)
    if not args.public_only:
        audit = args.output_dir/'private_audit'
        audit.mkdir(parents=True, exist_ok=True)
        write_csv(audit/'journey_id_exceptions.csv', ['source', 'line', 'journey_id', 'kind'], prepared.exceptions)
    summary, manifest = export(prepared, args.output_dir, sources, args.min_active_days, args.min_active_weeks)
    if args.output_dir.resolve() == (here/'data').resolve():
        project_manifest = dict(manifest)
        project_manifest['aggregate_files'] = [{**item, 'path': 'data/'+item['path']} for item in manifest['aggregate_files']]
        write_json(here/'source_manifest.json', project_manifest)
    print(json.dumps({'status': summary['status'], 'counts': summary['raw_counts'], 'register': summary['register_status_counts'], 'splits': summary['split_totals']}), flush=True)


if __name__ == '__main__':
    main()
