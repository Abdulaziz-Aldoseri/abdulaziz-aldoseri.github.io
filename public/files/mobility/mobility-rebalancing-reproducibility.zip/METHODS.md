# Where should rebalancing effort go?

Independent demonstration using London Santander Cycles historical journeys. The decision is how to distribute a limited amount of pre-morning rebalancing effort among stations. The evaluation concerns recorded flow balance, not actual inventory or rider service.

## Decision and information

For each station, morning net outflow is departures minus arrivals in the half-open 06:00–10:00 window. Count each event at its own recorded time, including arrivals from earlier starts. Positive net outflow means more bikes leave than arrive; a positive model transfer adds bikes. Negative values reverse those directions. Report departures and arrivals separately because the same net value can conceal different activity volumes.

The user supplies a bike-move budget B and a station-touch cap K. The model chooses integer net transfers r. All transfers sum to zero; one removal and one addition count as one bike moved, so half the sum of absolute transfers is at most B. At most K stations have nonzero transfers. K=0 or 1 necessarily permits no movement. Optional protection prevents intervention at one station without inventing a closure.

The objective minimizes the sum of absolute forecast net outflow minus transfer. Equal scores prefer fewer moved bikes, then fewer touched stations, then a deterministic procedural tie rule. Every policy receives the same budgets, cohort and protection. The observed-flow oracle uses perfect information under this same feasible set and is explicitly unavailable when planning.

## Chronology and station scope

The exact frozen rules are in PROTOCOL.json. Training is 5 January–15 February 2026; validation is 16 February–1 March; the complete test is 2–22 March. The cohort requires morning activity in at least four of six training weeks, using only eligible journeys completed before 16 February 00:00. New or sparse ordinary stations remain in the observed network score with zero transfers; they do not receive made-up forecasts. Labels and membership use training records; first-observed labels for excluded stations retain their provenance.

CLASSIC bikes only; a journey is excluded in full when either terminal label contains workshop or _OLD. IDs are preserved and never merged. The primary duration limit is 24 hours inclusive. Alternate 12/48-hour screens are reported with the fixed cohort and availability mask. An unrestricted-duration diagnostic is conditional on the January-1 start cohort, with left-censoring and later-completion exposure; it is not a full-population as-issued evaluation. Duration screening is an analytical choice, not a claim that longer journeys are errors.

A day before a station's first eligible primary event is unavailable history. Thereafter a day with no records is zero recorded activity, not proof of operating status or spare stock. Same-weekday forecasts average previous 1, 2, 4 or 6 calendar lags, omitting unavailable lags without extending the calendar horizon. Each mean remains an exact rational using common scale 60. Select one global window by minimum admitted-station validation MAE, with shorter-window ties. Earlier test weekdays can update that fixed rolling rule. The unrestricted diagnostic retains its stronger information limitation.

## Exact allocation and transparent comparison

For magnitude a of a scaled forecast with scale L=60, each full unit toward zero has gain L. A final fractional unit, when a mod L is nonzero, has gain 2(a mod L)−L. Transfers after that cannot improve an optimum with the fewest-moves tie rule. A donor and recipient are paired only when their combined gain is strictly positive; one individual gain can be negative. For example, forecasts (0.4,−0.9) benefit from moving one bike, while (0.1,−0.9) tie zero action and therefore use no moves.

Within each sign, larger forecast magnitude dominates smaller magnitude for every integer correction amount. Thus an optimum exists in a prefix of the magnitude-sorted station pool. Enumerate positive and negative prefixes under K, combine their ordered marginal gains under B, and compare exact objective, moves and actual support. Whole-unit ties concentrate transfers at larger stations; fractional ties use magnitude then stable ASCII ID. The last deterministic tie is the first enumerated prefix candidate, not a claim of globally lexicographically minimal station IDs. Independent exhaustive cases and a three-stage MILP reference verify the primary and secondary objectives.

The greedy rule makes the best immediate feasible donor/recipient move, with exact fractional gains and transparent ties, without planning the station-support choice globally. It may tie the optimum; that is a useful result. No-action and a perfect-information oracle complete the comparison. The same-weekday-last-week forecast remains a separate forecasting reference.

## Outcome and uncertainty

Apply the planned transfers to the later observed net-flow vector. Score the sum of absolute residual flows across the complete ordinary network. It is a static hypothetical balance score: no behavior response or within-morning inventory path is modelled. The network sum may be nonzero because journeys cross time-window boundaries. Conserved transfers cannot reduce total absolute residual below the absolute network sum; never force the raw flows to balance.

Report all test days and fixed budget/touch settings, including adverse outcomes, moves and station counts, mean/median residual, worst station residual, forecast MAE and coverage. A default scenario is fixed by calendar before evaluation. The later selected adverse example is labelled as such. Seven-day moving-block resampling of the short 21-day paired sequence is only a descriptive sensitivity; it does not establish seasonal, city-wide or commercial generalization.

No historical inventories, dock availability, truck routes, operating costs or unmet requests are observed. An abstract allocation satisfying B/K is not an executable dispatch. Stock and dock snapshots, within-morning demand/availability paths and operational constraints would be needed before using such a plan in service.

## Attribution

Powered by TfL Open Data. Contains OS data © Crown copyright and database rights 2016. Geomni UK Map data © and database rights [2019]. Original data: https://cycling.data.tfl.gov.uk/ · documentation: https://tfl.gov.uk/info-for/open-data-users/our-open-data · terms: https://tfl.gov.uk/corporate/terms-and-conditions/transport-data-service. Source and processing details accompany the aggregates. No affiliation or endorsement is implied.
