"""Independent exhaustive, direct-greedy and MILP checks for the transfer model."""
import itertools
import json
from pathlib import Path
import random
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mobility_model import all_policies, evaluate, greedy, optimize


def brute(v, allowed, budget, k, protected=None, scale=60):
    best = None
    for r in itertools.product(range(-budget, budget + 1), repeat=len(v)):
        if sum(r) or sum(abs(x) for x in r) > 2 * budget or sum(x != 0 for x in r) > k:
            continue
        if any(x and (not allowed[i] or i == protected) for i, x in enumerate(r)):
            continue
        key = (sum(abs(x - scale * y) for x, y, yes in zip(v, r, allowed) if yes),
               sum(abs(x) for x in r) // 2, sum(x != 0 for x in r))
        if best is None or key < best:
            best = key
    return best


def direct_greedy(ids, v, allowed, budget, k, protected=None, scale=60):
    r = [0] * len(v)
    for _ in range(budget):
        touched = sum(x != 0 for x in r)
        candidates = []
        for p, dp in enumerate(v):
            for n, dn in enumerate(v):
                if dp <= 0 or dn >= 0 or not allowed[p] or not allowed[n] or protected in (p, n):
                    continue
                new = int(r[p] == 0) + int(r[n] == 0)
                if touched + new > k:
                    continue
                before = abs(dp - scale * r[p]) + abs(dn - scale * r[n])
                after = abs(dp - scale * (r[p] + 1)) + abs(dn - scale * (r[n] - 1))
                gain = before - after
                if gain <= 0:
                    continue
                remaining = max(0, abs(dp) - scale * abs(r[p])) + max(0, abs(dn) - scale * abs(r[n]))
                candidates.append(((-gain, new, -remaining, ids[p], ids[n]), p, n))
        if not candidates:
            return r
        _, p, n = min(candidates)
        r[p] += 1
        r[n] -= 1
    return r


def milp_key(v, allowed, budget, k, protected=None, scale=60):
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    n = len(v)
    # r (integer), t (continuous), z (continuous), y (binary).
    lb = np.r_[np.full(n, -budget), np.zeros(3 * n)]
    ub = np.r_[np.full(n, budget), np.full(n, budget), np.full(n, np.inf), np.ones(n)]
    for i in range(n):
        if not allowed[i] or i == protected:
            lb[i] = ub[i] = 0
    integrality = np.r_[np.ones(n), np.zeros(2 * n), np.ones(n)]
    rows, lows, highs = [], [], []

    def row(items, lo=-np.inf, hi=np.inf):
        x = np.zeros(4 * n)
        for i, value in items:
            x[i] = value
        rows.append(x); lows.append(lo); highs.append(hi)

    row([(i, 1) for i in range(n)], 0, 0)
    row([(n + i, 1) for i in range(n)], hi=2 * budget)
    row([(3 * n + i, 1) for i in range(n)], hi=k)
    for i, d in enumerate(v):
        row([(i, 1), (n + i, -1)], hi=0)
        row([(i, -1), (n + i, -1)], hi=0)
        row([(i, 1), (3 * n + i, -budget)], hi=0)
        row([(i, -1), (3 * n + i, -budget)], hi=0)
        row([(i, scale), (2 * n + i, 1)], lo=d)
        row([(i, -scale), (2 * n + i, 1)], lo=-d)
    values = []
    for stage in (2, 1, 3):
        c = np.zeros(4 * n)
        if stage == 2:
            for i, yes in enumerate(allowed):
                c[2 * n + i] = int(yes)
        else:
            c[stage * n:(stage + 1) * n] = 1
        result = milp(c, integrality=integrality, bounds=Bounds(lb, ub),
                      constraints=LinearConstraint(np.array(rows), np.array(lows), np.array(highs)),
                      options={"time_limit": 30, "mip_rel_gap": 0})
        if not result.success or result.mip_gap > 1e-8:
            raise AssertionError(f"MILP not optimal: {result.message}; gap={getattr(result, 'mip_gap', None)}")
        value = int(round(result.fun))
        if abs(result.fun - value) > 1e-6:
            raise AssertionError("noninteger reference objective")
        values.append(value)
        rows.append(c); lows.append(value); highs.append(value)
    return (values[0], values[1] // 2, values[2])


class ModelTests(unittest.TestCase):
    def test_hand_fractional_and_support(self):
        examples = [([24, -54], 1, 2, [1, -1]), ([6, -54], 5, 2, [0, 0]),
                    ([72, 66, -120], 2, 3, [1, 1, -2]), ([180, 120, -300], 2, 3, [2, 0, -2])]
        for v, budget, k, want in examples:
            self.assertEqual(optimize([str(i) for i in range(len(v))], v, [True] * len(v), budget, k), want)

    def test_empty_zero_and_one_sided(self):
        self.assertEqual(optimize([], [], [], 100, 100), [])
        for v in ([0, 0], [60, 120], [-60, -120]):
            self.assertEqual(optimize(["a", "b"], v, [True, True], 100, 2), [0, 0])
        for budget, k in ((0, 4), (20, 0), (20, 1)):
            self.assertEqual(optimize(["a", "b"], [60, -60], [True, True], budget, k), [0, 0])

    def test_exhaustive(self):
        rng = random.Random(947)
        for case in range(200):
            n = rng.randint(2, 5); budget = rng.randint(0, 3); k = rng.randint(0, n)
            scale = rng.choice((1, 2, 4, 6, 60))
            v = [rng.randint(-3 * scale, 3 * scale) for _ in range(n)]
            allowed = [rng.random() > .15 for _ in range(n)]
            protected = rng.choice([None] + list(range(n)))
            ids = [f"s{i}" for i in range(n)]
            r = optimize(ids, v, allowed, budget, k, protected, scale)
            got = evaluate(r, [0] * n, v, allowed, budget, k, protected, scale)
            self.assertTrue(got["feasible"])
            self.assertEqual((got["forecast_residual_num"], got["moves"], got["touched"]),
                             brute(v, allowed, budget, k, protected, scale), (case, v, budget, k))

    def test_greedy_heap_matches_pair_enumeration(self):
        rng = random.Random(192)
        for _ in range(200):
            n = rng.randint(2, 12); v = [rng.randint(-600, 600) for _ in range(n)]
            ids = [f"s{i:02}" for i in range(n)]
            allowed = [rng.random() > .1 for _ in range(n)]
            budget = rng.randint(0, 15); k = rng.randint(0, n); protected = rng.choice([None] + list(range(n)))
            self.assertEqual(greedy(ids, v, allowed, budget, k, protected),
                             direct_greedy(ids, v, allowed, budget, k, protected))

    def test_milp_three_objectives(self):
        try:
            import scipy
        except ImportError:
            self.skipTest("SciPy required for independent MILP reference")
        rng = random.Random(641)
        for case in range(64):
            n = rng.randint(2, 10); budget = rng.randint(0, 15); k = rng.randint(0, n)
            v = [rng.randint(-700, 700) for _ in range(n)]
            allowed = [rng.random() > .15 for _ in range(n)]
            protected = rng.choice([None] + list(range(n)))
            r = optimize([f"s{i}" for i in range(n)], v, allowed, budget, k, protected)
            got = evaluate(r, [0] * n, v, allowed, budget, k, protected)
            self.assertEqual((got["forecast_residual_num"], got["moves"], got["touched"]),
                             milp_key(v, allowed, budget, k, protected), case)

    def test_feasibility_and_oracle_bound(self):
        rng = random.Random(21)
        for _ in range(100):
            n = rng.randint(2, 20); actual = [rng.randint(-20, 20) for _ in range(n)]
            v = [rng.randint(-800, 800) for _ in range(n)]; allowed = [rng.random() > .1 for _ in range(n)]
            budget = rng.randint(0, 40); k = rng.randint(0, n); protected = rng.choice([None] + list(range(n)))
            results = all_policies([f"s{i:02}" for i in range(n)], v, actual, allowed, budget, k, protected)
            for name, result in results.items():
                self.assertTrue(result["feasible"], name)
                self.assertGreaterEqual(result["residual"], abs(sum(actual)))
                self.assertGreaterEqual(result["residual"], results["oracle"]["residual"])
            self.assertLessEqual(results["optimized"]["forecast_residual_num"], results["greedy"]["forecast_residual_num"])

    def test_stable_ids_and_rejected_inputs(self):
        ids = ["b", "a", "z"]
        self.assertEqual(optimize(ids, [60, 60, -120], [True] * 3, 1, 2), [0, 1, -1])
        for args in ((["a", "a"], [1, -1], [True, True], 1, 2),
                     (["a"], [1], [True], -1, 2), (["a"], [1], [True], 1.5, 2),
                     (["a"], [float("nan")], [True], 1, 2), (["a"], [1], [1], 1, 2)):
            with self.assertRaises(ValueError):
                optimize(*args)
        with self.assertRaises(ValueError):
            optimize(["a"], [1], [True], 1, 2, protected=1)


if __name__ == "__main__":
    started = time.perf_counter()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ModelTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {"status": "PASS" if result.wasSuccessful() and not result.skipped else "FAIL_OR_SKIPPED",
              "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
              "skipped": len(result.skipped), "exhaustive_cases": 200, "greedy_pair_checks": 200,
              "milp_cases": 64, "milp_solves": 192, "feasibility_cases": 100,
              "elapsed_seconds": round(time.perf_counter() - started, 3)}
    (ROOT / "outputs").mkdir(exist_ok=True)
    (ROOT / "outputs/tests_verification.json").write_text(json.dumps(report, indent=2) + "\n")
    sys.exit(0 if report["status"] == "PASS" else 1)
