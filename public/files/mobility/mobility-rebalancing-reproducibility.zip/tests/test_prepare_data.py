"""Small independent invariants for source-only mobility preparation."""
import csv
import datetime as dt
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('prepare_data', ROOT/'prepare_data.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


def row(jid='1', start='2026-01-05 06:00', end='2026-01-05 06:10', sid='001', eid='002', sname='One', ename='Two', ms='600000', model='CLASSIC'):
    return dict(zip(p.SCHEMA, [jid, start, sid, sname, end, eid, ename, 'private-bike', model, '10m', ms]))


class PreparationTests(unittest.TestCase):
    def test_actual_event_boundaries_and_prior_day(self):
        data = p.Preparation()
        data.consume(row('1', '2026-01-04 23:00', '2026-01-05 06:00', ms='25200000'))
        data.consume(row('2', '2026-01-05 09:59', '2026-01-05 10:00', ms='60000'))
        data.consume(row('3', '2026-01-05 10:00', '2026-01-05 10:10'))
        e = data.events['primary_24h']
        self.assertEqual(e[('2026-01-05', '001', 0)], 1)
        self.assertEqual(e[('2026-01-05', '002', 1)], 1)
        self.assertEqual(data.boundaries['primary_24h']['evaluation_morning_arrivals_from_warmup_starts'], 1)

    def test_same_station_counts_both_events(self):
        data = p.Preparation()
        data.consume(row(eid='001', ename='One'))
        self.assertEqual(data.events['primary_24h'][('2026-01-05', '001', 0)], 1)
        self.assertEqual(data.events['primary_24h'][('2026-01-05', '001', 1)], 1)

    def test_exact_duplicates_deduplicate_across_files(self):
        data = p.Preparation()
        data.consume(row(), 'a.csv')
        data.consume(row(), 'b.csv')
        self.assertEqual(data.counts['exact_duplicate_rows'], 1)
        self.assertEqual(data.counts['unique_journey_ids'], 1)
        self.assertEqual(data.events['primary_24h'][('2026-01-05', '001', 0)], 1)
        data.assert_publishable()

    def test_conflicting_id_fails_closed(self):
        data = p.Preparation()
        data.consume(row())
        data.consume(row(ms='600001'))
        self.assertEqual(data.counts['conflicting_duplicate_rows'], 1)
        with self.assertRaises(ValueError):
            data.assert_publishable()

    def test_duration_thresholds_inclusive_and_unrestricted(self):
        data = p.Preparation()
        for jid, milliseconds in enumerate([43200000, 43200001, 86400000, 86400001, 172800000, 172800001]):
            end = dt.datetime(2026, 1, 5, 6) + dt.timedelta(milliseconds=milliseconds)
            data.consume(row(str(jid), end=end.isoformat(sep=' '), ms=str(milliseconds)))
        self.assertEqual([data.variant_stages[v]['eligible_journeys_all_source_dates'] for v in ['duration_12h', 'primary_24h', 'duration_48h', 'duration_unrestricted']], [1, 3, 5, 6])

    def test_whole_journey_exclusion_and_electric(self):
        data = p.Preparation()
        data.consume(row('1', ename='Two_OLD'))
        data.consume(row('2', sname='Mechanical Workshop'))
        data.consume(row('3', model='PBSC_EBIKE'))
        self.assertEqual(sum(data.events['primary_24h'].values()), 0)
        self.assertEqual(data.variant_stages['primary_24h']['whole_journey_endpoint_excluded'], 2)
        self.assertEqual(data.counts['non_classic_excluded'], 1)
        self.assertEqual(set(data.excluded), {'001', '002'})

    def test_invalid_times_and_duration_fail_closed(self):
        for bad in [row(ms='0'), row(end='2026-01-05 05:00'), row(start='2026-01-05 06:00+00:00'), row(ms='NaN')]:
            data = p.Preparation()
            data.consume(bad)
            with self.assertRaises(ValueError):
                data.assert_publishable()

    def test_train_coverage_uses_four_calendar_weeks_and_no_future_name(self):
        data = p.Preparation()
        for n, day in enumerate(['2026-01-05', '2026-01-12', '2026-01-19', '2026-01-26']):
            data.consume(row(str(n), day+' 06:00', day+' 06:10'))
        data.consume(row('future', '2026-03-02 06:00', '2026-03-02 06:10', sname='Renamed later'))
        regs = {x['station_id']: x for x in p.register(data, 1, 4)}
        self.assertEqual(regs['001']['training_active_morning_weeks'], 4)
        self.assertEqual(regs['001']['intervention_eligible'], 1)
        self.assertEqual(regs['001']['name'], 'One')
        self.assertEqual(regs['001']['first_eligible_event_date'], '2026-01-05')

    def test_admission_requires_completed_journey_before_cutoff(self):
        data = p.Preparation()
        data.consume(row('1', '2026-02-15 06:00', '2026-02-16 00:00', ms='64800000'))
        self.assertEqual(data.events['primary_24h'][('2026-02-15', '001', 0)], 1)
        self.assertEqual(len(data.training_active['001']), 0)
        self.assertEqual(len(data.training_names['001']), 0)
        self.assertEqual(data.variant_stages['primary_24h']['journeys_with_training_event_but_not_completed_before_admission_cutoff'], 1)

    def test_station_id_leading_zeros_and_training_name_conflict(self):
        data = p.Preparation()
        data.consume(row('1', sid='0001114444', sname='Original'))
        data.consume(row('2', sid='0001114444', sname='Different'))
        reg = {x['station_id']: x for x in p.register(data, 1, 1)}['0001114444']
        self.assertEqual(reg['intervention_eligible'], 0)
        self.assertEqual(reg['eligibility_status'], 'ambiguous_training_name')

    def test_public_panel_history_mask_and_reconciliation(self):
        data = p.Preparation()
        for n, day in enumerate(p.days()):
            text = day.isoformat()
            data.consume(row(str(n), text+' 06:00', text+' 06:10'))
        data.consume(row('new', '2026-03-02 06:00', '2026-03-02 06:10', sid='new', sname='New station'))
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp)/'unrelated.csv').write_text('must not be certified')
            summary, manifest = p.export(data, Path(temp), [], 1, 4)
            self.assertEqual({r['path'] for r in manifest['aggregate_files']}, set(p.AGGREGATE_CSV_FILES))
            self.assertTrue(summary['panel_verification']['primary_24h']['aggregate_totals_match_counted_events'])
            with (Path(temp)/'primary_24h.csv').open() as f:
                rows = list(csv.DictReader(f))
            new = {r['date']: r for r in rows if r['station_id'] == 'new'}
            self.assertEqual(new['2026-03-01']['history_available'], '0')
            self.assertEqual(new['2026-03-02']['history_available'], '1')
            self.assertEqual(new['2026-03-03']['history_available'], '1')
            self.assertEqual(new['2026-03-03']['departures'], '0')
            self.assertNotIn('journey_id', (Path(temp)/'primary_24h.csv').read_text())
            self.assertNotIn('private-bike', json.dumps(manifest))
            self.assertEqual(len(rows), 81*3)

    def test_public_directory_rejects_unrelated_and_private_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            p.validate_public_output(output)
            (output/'SOURCE_MANIFEST.json').write_text('{}')
            p.validate_public_output(output)
            (output/'unrelated.csv').write_text('private')
            with self.assertRaises(ValueError):
                p.validate_public_output(output)
            (output/'unrelated.csv').unlink()
            (output/'private_audit').mkdir()
            with self.assertRaises(ValueError):
                p.validate_public_output(output)

    def test_missing_network_date_blocks_export_before_writing(self):
        data = p.Preparation()
        data.consume(row())
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                p.export(data, Path(temp), [], 1, 4)
            self.assertEqual(list(Path(temp).iterdir()), [])


if __name__ == '__main__':
    unittest.main()
