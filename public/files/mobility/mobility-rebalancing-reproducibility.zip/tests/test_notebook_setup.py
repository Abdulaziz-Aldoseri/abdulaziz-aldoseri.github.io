"""Safe ZIP setup tests; no network, pip, browser or hosted notebook required."""
from hashlib import sha256
from io import BytesIO
import importlib.util
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

spec = importlib.util.spec_from_file_location("notebook_setup", Path(__file__).resolve().parents[1] / "notebook_setup.py")
setup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup)


def archive(files=None, additional=None, transform_manifest=None):
    files = files or {"mobility_model.py": b"# harmless fixture\n", "data/station_register.csv": b"station_id,name\n001,Station\n"}
    manifest = {"files": [{"path": name, "bytes": len(content), "sha256": sha256(content).hexdigest()} for name, content in files.items()]}
    if transform_manifest:
        transform_manifest(manifest)
    output = BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("package_manifest.json", json.dumps(manifest).encode())
        for name, contents in files.items():
            z.writestr(name, contents)
        for name, contents in additional or []:
            z.writestr(name, contents)
    return output.getvalue()


class SetupTests(unittest.TestCase):
    def test_roundtrip_and_tamper_detection(self):
        with tempfile.TemporaryDirectory() as temp:
            output = setup.safe_extract_package(archive(), Path(temp) / "out")
            self.assertEqual(len(setup.verify_package(output)), 2)
            (output / "mobility_model.py").write_bytes(b"tampered")
            with self.assertRaises(ValueError):
                setup.verify_package(output)

    def test_working_notebook_edits_allowed_but_code_remains_verified(self):
        with tempfile.TemporaryDirectory() as temp:
            output = setup.safe_extract_package(archive(files={"mobility_model.py": b"# original code", "mobility_rebalancing.ipynb": b"{}"}), Path(temp) / "out")
            (output / "mobility_rebalancing.ipynb").write_bytes(b'{"cells": [], "edited": true}')
            with self.assertRaises(ValueError):
                setup.verify_package(output)
            self.assertEqual(len(setup.verify_package(output, allow_notebook_edits=True)), 2)
            (output / "mobility_model.py").write_bytes(b"# modified code")
            with self.assertRaises(ValueError):
                setup.verify_package(output, allow_notebook_edits=True)

    def test_traversal_windows_absolute_and_private_are_rejected(self):
        for name in ["../bad", "/bad", "C:/bad", "data\\bad", "data/./bad", "data//bad", "data/private/customer.csv", "raw.xlsx", "data/private_audit/ids.csv", "435JourneyDataExtract01Jan2026-15Jan2026.csv"]:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp:
                output = Path(temp) / "out"
                with self.assertRaises(ValueError):
                    setup.safe_extract_package(archive(additional=[(name, b"bad")]), output)
                self.assertFalse(output.exists())

    def test_unmanifested_and_duplicate_files_rejected(self):
        for extra in [[("extra.py", b"bad")], [("mobility_model.py", b"bad")], [("MOBILITY_MODEL.PY", b"bad")]]:
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as temp:
                with self.assertRaises(ValueError):
                    setup.safe_extract_package(archive(additional=extra), Path(temp) / "out")

    def test_checksum_and_declared_size_failure_writes_nothing(self):
        for field, bad in [("sha256", "0" * 64), ("bytes", 12345)]:
            with tempfile.TemporaryDirectory() as temp:
                output = Path(temp) / "out"
                with self.assertRaises(ValueError):
                    setup.safe_extract_package(archive(transform_manifest=lambda m: m["files"][0].update({field: bad})), output)
                self.assertFalse(output.exists())

    def test_symlink_entry_rejected(self):
        link = zipfile.ZipInfo("link")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                setup.safe_extract_package(archive(additional=[(link, b"target")]), Path(temp) / "out")

    def test_nonempty_destination_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "out"
            output.mkdir()
            (output / "keep.txt").write_text("keep", encoding="utf-8")
            with self.assertRaises(ValueError):
                setup.safe_extract_package(archive(), output)
            self.assertEqual((output / "keep.txt").read_text(encoding="utf-8"), "keep")

    def test_file_directory_conflicts_rejected_before_writes(self):
        for files in [{"a": b"file", "a/b": b"child"}, {"Data/a": b"one", "data/b": b"two"}]:
            with self.subTest(files=files), tempfile.TemporaryDirectory() as temp:
                output = Path(temp) / "out"
                with self.assertRaises(ValueError):
                    setup.safe_extract_package(archive(files=files), output)
                self.assertFalse(output.exists())

    def test_bounded_compressed_and_expanded_sizes(self):
        data = archive()
        with tempfile.TemporaryDirectory() as temp:
            for constant in ["MAX_ARCHIVE_BYTES", "MAX_TOTAL_BYTES", "MAX_FILE_BYTES", "MAX_FILES"]:
                with self.subTest(constant=constant), patch.object(setup, constant, 1):
                    with self.assertRaises(ValueError):
                        setup.safe_extract_package(data, Path(temp) / constant)


if __name__ == "__main__":
    unittest.main()
