"""Frozen chronological forecast selection and held-out transfer evaluation.

Run validation and evaluation as separate explicit phases. This pipeline uses
prepared aggregate station events; prepare_data.py owns source interpretation.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import random
import statistics
import time

from mobility_model import POLICIES, all_policies

ROOT = Path(__file__).resolve().parent
VARIANTS = ("primary_24h", "duration_12h", "duration_48h", "duration_unrestricted")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")


def input_hashes():
    names = ["PROTOCOL.json", "mobility_model.py", "pipeline.py", "data/station_register.csv"]
    names += [f"data/{variant}.csv" for variant in VARIANTS]
    return {name: digest(ROOT / name) for name in names}


def read_protocol():
    protocol = json.loads((ROOT / "PROTOCOL.json").read_text(encoding="utf-8-sig"))
    expected = {"windows": [1, 2, 4, 6], "forecast_scale": 60,
                "bike_budgets": [0, 50, 100, 200, 400], "touch_limits": [0, 1, 2, 5, 10, 20, 40],
                "validation": ["2026-02-16", "2026-03-01"], "test": ["2026-03-02", "2026-03-22"],
                "default_date": "2026-03-02", "default_budget": 200, "default_touch_limit": 20}
    for key, value in expected.items():
        if protocol.get(key) != value:
            raise ValueError(f"Unexpected protocol {key}; review code before changing the protocol")
    return protocol


def stations():
    with (ROOT / "data/station_register.csv").open(encoding="utf-8-sig", newline="") as source:
        rows = list(csv.DictReader(source))
    ids = [x["station_id"] for x in rows]
    if ids != sorted(set(ids)):
        raise ValueError("Station register must be unique ASCII-ID order")
    for x in rows:
        if x["intervention_eligible"] not in ("0", "1"):
            raise ValueError("Invalid admission indicator")
    return [{"id": x["station_id"], "name": x["name"], "eligible": x["intervention_eligible"] == "1"}
            for x in rows]


def load_panel(variant, register, through=None):
    ids = [x["id"] for x in register]
    index = {key: i for i, key in enumerate(ids)}
    panel, seen = {}, set()
    with (ROOT / f"data/{variant}.csv").open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            day = row["date"]
            if through is not None and day > through:
                continue  # No test outcome fields are parsed in the validation phase.
            i = index[row["station_id"]]
            if (day, i) in seen:
                raise ValueError("Duplicate station-day")
            seen.add((day, i))
            if day not in panel:
                panel[day] = {"date": day, "split": row["split"], "departures": [0] * len(ids),
                              "arrivals": [0] * len(ids), "actual": [0] * len(ids), "available": [False] * len(ids)}
            d, a, flow = int(row["departures"]), int(row["arrivals"]), int(row["net_outflow"])
            if min(d, a) < 0 or d - a != flow or row["history_available"] not in ("0", "1"):
                raise ValueError("Invalid event count or availability")
            target = panel[day]
            target["departures"][i], target["arrivals"][i], target["actual"][i] = d, a, flow
            target["available"][i] = row["history_available"] == "1"
    if len(seen) != len(panel) * len(ids):
        raise ValueError("Incomplete station-day panel")
    return panel


def dates_between(bounds):
    start, stop = map(date.fromisoformat, bounds)
    return [(start + timedelta(days=i)).isoformat() for i in range((stop - start).days + 1)]


def forecast(panel, day, window, eligible, scale=60):
    when = date.fromisoformat(day)
    lags = [(when - timedelta(days=7 * lag)).isoformat() for lag in range(1, window + 1)]
    values, counts = [], []
    for i, allowed in enumerate(eligible):
        if not allowed:
            values.append(0); counts.append(0)
            continue
        observations = [panel[lag]["actual"][i] for lag in lags if lag in panel and panel[lag]["available"][i]]
        count = len(observations)
        if not count:
            raise ValueError(f"Admitted station has no forecast history at {day}: index {i}")
        if scale % count:
            raise ValueError("Forecast scale cannot represent the exact mean")
        values.append(sum(observations) * (scale // count))
        counts.append(count)
    return values, counts


def forecast_score(panel, day, window, eligible, scale):
    values, counts = forecast(panel, day, window, eligible, scale)
    errors = [abs(v - scale * d) for v, d, yes in zip(values, panel[day]["actual"], eligible) if yes]
    available_counts = [x for x, yes in zip(counts, eligible) if yes]
    return {"date": day, "window": window, "station_count": len(errors), "error_num": sum(errors),
            "mae": sum(errors) / (scale * len(errors)), "min_history": min(available_counts),
            "max_history": max(available_counts), "mean_history": statistics.mean(available_counts)}


def validate(output):
    protocol = read_protocol()
    frozen_path = output / "validation_frozen.json"
    if frozen_path.exists():
        raise FileExistsError("Validation is already frozen; reproduce into a new --output-dir")
    hashes = input_hashes()
    register = stations(); eligible = [x["eligible"] for x in register]
    panel = load_panel("primary_24h", register, through=protocol["validation"][1])
    days = dates_between(protocol["validation"])
    cases = [forecast_score(panel, day, window, eligible, protocol["forecast_scale"])
             for window in protocol["windows"] for day in days]
    summaries = []
    for window in protocol["windows"]:
        rows = [x for x in cases if x["window"] == window]
        count = sum(x["station_count"] for x in rows)
        errors = sum(x["error_num"] for x in rows)
        summaries.append({"window": window, "error_num": errors, "station_days": count,
                          "mae": errors / (protocol["forecast_scale"] * count)})
    # The admitted station count and all 14 dates are identical across candidates.
    if len({x["station_days"] for x in summaries}) != 1:
        raise ValueError("Forecast candidates have different validation denominators")
    chosen = min(summaries, key=lambda x: (x["error_num"], x["window"]))["window"]
    if hashes != input_hashes():
        raise RuntimeError("Inputs changed during validation")
    freeze = {"frozen_utc": datetime.now(timezone.utc).isoformat(), "selected_history": chosen,
              "scale": protocol["forecast_scale"], "input_hashes": hashes,
              "validation": summaries, "validation_dates": days,
              "station_count": len(register), "admitted_stations": sum(eligible),
              "test_outcomes_parsed": False}
    write_json(output / "validation_cases.json", cases)
    write_json(frozen_path, freeze)
    (output / "validation_frozen.sha256").write_text(digest(frozen_path) + "\n")
    return freeze


def guarded_freeze(output):
    path = output / "validation_frozen.json"
    if digest(path) != (output / "validation_frozen.sha256").read_text().strip():
        raise ValueError("Frozen validation file hash mismatch")
    frozen = json.loads(path.read_text(encoding="utf-8"))
    if frozen["input_hashes"] != input_hashes():
        raise ValueError("Protocol, data, model or pipeline changed after validation freeze")
    return frozen


def summary(rows):
    return {"days": len(rows), "mean_residual": statistics.mean(x["residual"] for x in rows),
            "median_residual": statistics.median(x["residual"] for x in rows),
            "mean_worst_station_residual": statistics.mean(x["worst_station_residual"] for x in rows),
            "mean_moves": statistics.mean(x["moves"] for x in rows),
            "mean_touched": statistics.mean(x["touched"] for x in rows),
            "mean_unused_budget": statistics.mean(x["unused_budget"] for x in rows)}


def percentile(sorted_values, fraction):
    position = (len(sorted_values) - 1) * fraction
    left = int(position); right = min(left + 1, len(sorted_values) - 1)
    return sorted_values[left] + (position - left) * (sorted_values[right] - sorted_values[left])


def block_interval(differences):
    rng = random.Random(20260914)
    estimates = []
    for _ in range(2000):
        sample = []
        while len(sample) < len(differences):
            start = rng.randrange(len(differences) - 7 + 1)
            sample.extend(differences[start:start + 7])
        estimates.append(statistics.mean(sample[:len(differences)]))
    estimates.sort()
    return [percentile(estimates, .025), percentile(estimates, .975)]


def compare(rows, baseline, budget, touch_limit, interval=False):
    by = {(x["date"], x["policy"]): x for x in rows}
    dates = sorted({x["date"] for x in rows})
    diffs = [by[(day, "optimized")]["residual"] - by[(day, baseline)]["residual"] for day in dates]
    return {"budget": budget, "touch_limit": touch_limit, "baseline": baseline,
            "mean_difference": statistics.mean(diffs), "median_difference": statistics.median(diffs),
            "better": sum(x < 0 for x in diffs), "tied": sum(x == 0 for x in diffs),
            "worse": sum(x > 0 for x in diffs), "interval": block_interval(diffs) if interval else None}


def evaluate_phase(output):
    protocol = read_protocol(); frozen = guarded_freeze(output)
    if (output / "evaluation_verification.json").exists():
        raise FileExistsError("Evaluation already exists; reproduce into a new --output-dir")
    started_utc = datetime.now(timezone.utc).isoformat(); started = time.perf_counter()
    register = stations(); ids = [x["id"] for x in register]; eligible = [x["eligible"] for x in register]
    scale = frozen["scale"]; window = frozen["selected_history"]; days = dates_between(protocol["test"])
    primary = load_panel("primary_24h", register)
    primary_cases, sensitivity_cases, all_summaries, all_comparisons, weekday_results = [], [], [], [], []
    forecast_diagnostics, public_days, coverage = [], [], []
    optimality_checks = feasibility_checks = 0
    for variant in VARIANTS:
        panel = primary if variant == "primary_24h" else load_panel(variant, register)
        if set(panel) != set(primary) or any(panel[d]["available"] != primary[d]["available"] for d in primary):
            raise ValueError("Sensitivity date grid or primary availability mask changed")
        variant_cases = []
        for day in days:
            observed = panel[day]
            values, counts = forecast(panel, day, window, eligible, scale)
            for n in sorted({1, window}):
                forecast_diagnostics.append({"variant": variant, **forecast_score(panel, day, n, eligible, scale)})
            if variant == "primary_24h":
                public_days.append({"date": day, "weekday": date.fromisoformat(day).strftime("%A"),
                                    "departures": observed["departures"], "arrivals": observed["arrivals"],
                                    "actual": observed["actual"],
                                    "forecast_num": [x if yes else None for x, yes in zip(values, eligible)],
                                    "history_count": counts})
                coverage.append({"date": day, "network_departures": sum(observed["departures"]),
                                 "network_arrivals": sum(observed["arrivals"]),
                                 "admitted_departures": sum(x for x, yes in zip(observed["departures"], eligible) if yes),
                                 "admitted_arrivals": sum(x for x, yes in zip(observed["arrivals"], eligible) if yes),
                                 "outside_cohort_residual": sum(abs(x) for x, yes in zip(observed["actual"], eligible) if not yes),
                                 "net_outflow": sum(observed["actual"]), "net_flow_bound": abs(sum(observed["actual"]))})
            for budget in protocol["bike_budgets"]:
                for touch_limit in protocol["touch_limits"]:
                    policies = all_policies(ids, values, observed["actual"], eligible, budget, touch_limit, scale=scale)
                    opt = policies["optimized"]
                    if (opt["forecast_residual_num"], opt["moves"], opt["touched"]) > (
                        policies["greedy"]["forecast_residual_num"], policies["greedy"]["moves"], policies["greedy"]["touched"]):
                        raise AssertionError("Optimized forecast objective worse than a feasible greedy allocation")
                    optimality_checks += 1
                    for policy, result in policies.items():
                        if not result["feasible"] or result["residual"] < policies["oracle"]["residual"]:
                            raise AssertionError("Feasibility or oracle lower bound failed")
                        if result["residual"] < result["net_flow_bound"]:
                            raise AssertionError("Conserved network-flow bound failed")
                        feasibility_checks += 1
                        row = {"variant": variant, "date": day, "budget": budget, "touch_limit": touch_limit,
                               "policy": policy, **result}
                        variant_cases.append(row)
        for budget in protocol["bike_budgets"]:
            for touch_limit in protocol["touch_limits"]:
                selection = [x for x in variant_cases if x["budget"] == budget and x["touch_limit"] == touch_limit]
                for policy in POLICIES:
                    rows = [x for x in selection if x["policy"] == policy]
                    all_summaries.append({"variant": variant, "budget": budget, "touch_limit": touch_limit,
                                          "policy": policy, **summary(rows)})
                    for group in list(range(7)) + ["weekday", "weekend"]:
                        segment = [x for x in rows if (date.fromisoformat(x["date"]).weekday() == group
                                   if isinstance(group, int) else (date.fromisoformat(x["date"]).weekday() < 5) == (group == "weekday"))]
                        weekday_results.append({"variant": variant, "budget": budget, "touch_limit": touch_limit,
                                                "policy": policy, "group": group, **summary(segment)})
                for baseline in ("no_action", "greedy", "oracle"):
                    all_comparisons.append({"variant": variant, **compare(selection, baseline, budget, touch_limit,
                        budget == protocol["default_budget"] and touch_limit == protocol["default_touch_limit"])})
        if variant == "primary_24h":
            primary_cases = variant_cases
        else:
            sensitivity_cases.extend(variant_cases)
    primary_summaries = [{k: v for k, v in x.items() if k != "variant"} for x in all_summaries if x["variant"] == "primary_24h"]
    primary_comparisons = [{k: v for k, v in x.items() if k != "variant"} for x in all_comparisons if x["variant"] == "primary_24h"]
    defaults = [x for x in primary_cases if x["budget"] == protocol["default_budget"] and x["touch_limit"] == protocol["default_touch_limit"]]
    by = {(x["date"], x["policy"]): x for x in defaults}
    adverse = max(days, key=lambda d: (by[(d, "optimized")]["residual"] - by[(d, "no_action")]["residual"], -days.index(d)))
    index = {"meta": {"scale": scale, "selected_history": window, "default_date": protocol["default_date"],
                       "default_budget": protocol["default_budget"], "default_touch_limit": protocol["default_touch_limit"],
                       "budget_grid": protocol["bike_budgets"], "touch_grid": protocol["touch_limits"],
                       "station_count": len(register), "admitted_stations": sum(eligible),
                       "adverse_date": adverse, "adverse_selected_after_evaluation": True},
             "stations": register, "days": public_days, "validation": frozen["validation"],
             "summaries": primary_summaries, "comparisons": primary_comparisons,
             "sensitivity_summaries": [x for x in all_summaries if x["variant"] != "primary_24h"],
             "sensitivity_comparisons": [x for x in all_comparisons if x["variant"] != "primary_24h"],
             "forecast_diagnostics": forecast_diagnostics, "coverage": coverage,
             "weekday_results": [x for x in weekday_results if x["variant"] == "primary_24h"]}
    write_json(output / "public_index.json", index)
    write_json(output / "evaluated_cases.json", primary_cases)
    write_json(output / "sensitivity_cases.json", sensitivity_cases)
    write_json(output / "weekday_results.json", weekday_results)
    write_json(output / "forecast_diagnostics.json", forecast_diagnostics)
    write_json(output / "coverage.json", coverage)
    csv_fields = ["variant", "date", "budget", "touch_limit", "policy", "residual", "forecast_residual_num",
                  "forecast_residual", "worst_station_residual", "moves", "touched", "unused_budget", "net_flow_bound", "feasible"]
    with (output / "daily_results.csv").open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=csv_fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(primary_cases + sensitivity_cases)
    fixtures = []
    for day in public_days:
        values = [x or 0 for x in day["forecast_num"]]
        protected_choices = [max(range(len(ids)), key=lambda i: abs(values[i])),
                             next(i for i, yes in enumerate(eligible) if not yes)]
        for protected in protected_choices:
            fixtures.append({"kind": "day", "date": day["date"], "budget": 200, "touch_limit": 20,
                             "protected": protected,
                             "policies": all_policies(ids, values, day["actual"], eligible, 200, 20, protected, scale)})
    rng = random.Random(991)
    for _ in range(50):
        count = rng.randint(2, 10); fids = [f"s{i:02}" for i in range(count)]
        values = [rng.randint(-400, 400) for i in range(count)]; actual = [rng.randint(-10, 10) for i in range(count)]
        allowed = [rng.random() > .2 for i in range(count)]; budget = rng.randint(0, 20); k = rng.randint(0, count)
        protected = rng.choice([None] + list(range(count)))
        fixtures.append({"kind": "synthetic", "ids": fids, "forecast_num": values, "actual": actual,
                         "eligible": allowed, "budget": budget, "touch_limit": k, "protected": protected,
                         "policies": all_policies(fids, values, actual, allowed, budget, k, protected, scale)})
    write_json(output / "parity_fixtures.json", fixtures)
    guarded_freeze(output)
    report = {"status": "PASS", "evaluation_started_utc": started_utc,
              "finished_utc": datetime.now(timezone.utc).isoformat(), "elapsed_seconds": round(time.perf_counter() - started, 3),
              "selected_history": window, "validation_hash": digest(output / "validation_frozen.json"),
              "input_hashes": frozen["input_hashes"], "test_days": len(days), "controls": 35, "variants": 4,
              "primary_policy_allocations": len(primary_cases), "sensitivity_policy_allocations": len(sensitivity_cases),
              "feasibility_checks": feasibility_checks, "forecast_optimality_comparisons": optimality_checks,
              "protected_and_synthetic_parity_fixtures": len(fixtures)}
    write_json(output / "evaluation_verification.json", report)
    default_comp = [x for x in primary_comparisons if x["budget"] == 200 and x["touch_limit"] == 20]
    lines = ["# Mobility allocation results", "", "Independent retrospective flow-balance demonstration; not operational dispatch.", "",
             f"Selected weekday history: {window}. Evaluated 21 test dates, 35 budget/touch settings, four policies and four duration variants.", "",
             "Default: 2 March 2026, 200-bike limit, 20 touched stations; reference summaries below cover all 21 test dates at those limits.", "",
             "| Reference | Optimized minus reference mean residual | Better / tied / worse dates | Descriptive 7-day block interval |",
             "| --- | ---: | --- | --- |"]
    for row in default_comp:
        lines.append(f"| {row['baseline']} | {row['mean_difference']:.2f} | {row['better']} / {row['tied']} / {row['worse']} | {row['interval']} |")
    lines += ["", f"Adverse reference date selected after evaluation: {adverse}; greatest optimized-minus-no-action residual, earliest date on ties.", "",
              "Lower residual is a better score under the stated hypothetical allocation. It does not measure inventory, unmet trips, rider service, costs, dispatch feasibility or a causal effect.", "",
              "Unrestricted-duration results are a left-censored January-start-cohort diagnostic. All variants retain the primary admission cohort and availability mask.", "",
              "Machine-readable full daily results, forecast errors, weekday/weekend summaries, parity fixtures and hash guards accompany this record."]
    (ROOT / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("validate", "evaluate"), required=True)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result = validate(args.output_dir) if args.phase == "validate" else evaluate_phase(args.output_dir)
    print(json.dumps(result, indent=2))
