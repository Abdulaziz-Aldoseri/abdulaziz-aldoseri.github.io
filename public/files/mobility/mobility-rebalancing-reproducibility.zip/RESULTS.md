# Mobility allocation results

Independent retrospective flow-balance demonstration; not operational dispatch.

Selected weekday history: 6. Evaluated 21 test dates, 35 budget/touch settings, four policies and four duration variants.

Default: 2 March 2026, 200-bike limit, 20 touched stations; reference summaries below cover all 21 test dates at those limits.

| Reference | Optimized minus reference mean residual | Better / tied / worse dates | Descriptive 7-day block interval |
| --- | ---: | --- | --- |
| no_action | -283.14 | 21 / 0 / 0 | [-288.85714285714283, -277.23809523809524] |
| greedy | -0.48 | 3 / 18 / 0 | [-0.47619047619047616, -0.2857142857142857] |
| oracle | 47.90 | 0 / 4 / 17 | [43.714285714285715, 52.19047619047619] |

Adverse reference date selected after evaluation: 2026-03-08; greatest optimized-minus-no-action residual, earliest date on ties.

Lower residual is a better score under the stated hypothetical allocation. It does not measure inventory, unmet trips, rider service, costs, dispatch feasibility or a causal effect.

Unrestricted-duration results are a left-censored January-start-cohort diagnostic. All variants retain the primary admission cohort and availability mask.

Machine-readable full daily results, forecast errors, weekday/weekend summaries, parity fixtures and hash guards accompany this record.
