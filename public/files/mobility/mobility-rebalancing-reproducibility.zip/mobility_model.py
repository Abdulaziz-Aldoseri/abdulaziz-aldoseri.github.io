"""Exact integer allocation of conserved transfers against rational net-flow forecasts.

No inventory, dock capacity, routing or actual rider-service model is implied.
Forecasts are integer numerators over a common positive scale (normally 60).
"""
from __future__ import annotations

from bisect import bisect_left
import heapq
import math

POLICIES = ("no_action", "greedy", "optimized", "oracle")


def _integer(value, name, minimum=None):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{name} must be at least {minimum}")
    return value


def _validate(ids, forecast_num, eligible, budget, touch_limit, protected, scale):
    _integer(budget, "budget", 0)
    _integer(touch_limit, "touch_limit", 0)
    _integer(scale, "scale", 1)
    if len(ids) != len(forecast_num) or len(ids) != len(eligible):
        raise ValueError("station arrays must have equal lengths")
    if len(set(ids)) != len(ids) or any(not isinstance(x, str) or not x.isascii() for x in ids):
        raise ValueError("station IDs must be distinct ASCII strings")
    for x in forecast_num:
        _integer(x, "forecast numerator")
    if any(type(x) is not bool for x in eligible):
        raise ValueError("eligible must contain booleans")
    if protected is not None:
        _integer(protected, "protected", 0)
        if protected >= len(ids):
            raise ValueError("protected station is out of range")


def _side_prefixes(indices, ids, forecast_num, limit, scale):
    ordered = sorted(indices, key=lambda i: (-abs(forecast_num[i]), ids[i]))[:limit]
    pools = [None]
    for k in range(1, len(ordered) + 1):
        selected = ordered[:k]
        floors = [abs(forecast_num[i]) // scale for i in selected]
        cumulative, total = [], 0
        for count in floors:
            total += count
            cumulative.append(total)
        fractions = sorted(
            (i for i in selected if abs(forecast_num[i]) % scale),
            key=lambda i: (-(abs(forecast_num[i]) % scale), -abs(forecast_num[i]), ids[i]),
        )
        new_fraction_count, extra = [], 0
        for i in fractions:
            extra += abs(forecast_num[i]) < scale
            new_fraction_count.append(extra)
        chunks = ([(scale, total)] if total else []) + [
            (2 * (abs(forecast_num[i]) % scale) - scale, 1) for i in fractions
        ]
        pools.append({"indices": selected, "floors": floors, "cumulative": cumulative,
                      "full": total, "fractions": fractions, "chunks": chunks,
                      "base_touched": sum(x > 0 for x in floors), "extra_touched": new_fraction_count})
    return pools


def _pair_curve(left, right, budget):
    a = b = used_a = used_b = moves = gain = 0
    while moves < budget and a < len(left) and b < len(right):
        pair_gain = left[a][0] + right[b][0]
        if pair_gain <= 0:
            break
        amount = min(budget - moves, left[a][1] - used_a, right[b][1] - used_b)
        moves += amount
        gain += amount * pair_gain
        used_a += amount
        used_b += amount
        if used_a == left[a][1]:
            a += 1
            used_a = 0
        if used_b == right[b][1]:
            b += 1
            used_b = 0
    return moves, gain


def _touches(pool, moves):
    if not moves:
        return 0
    if moves <= pool["full"]:
        return bisect_left(pool["cumulative"], moves) + 1
    return pool["base_touched"] + pool["extra_touched"][moves - pool["full"] - 1]


def _fill(pool, moves, sign, transfer):
    remaining = moves
    for i, capacity in zip(pool["indices"], pool["floors"]):
        amount = min(remaining, capacity)
        transfer[i] += sign * amount
        remaining -= amount
        if not remaining:
            return
    for i in pool["fractions"][:remaining]:
        transfer[i] += sign


def optimize(ids, forecast_num, eligible, budget, touch_limit, protected=None, scale=60):
    """Return the exact primary/minimum-moves/minimum-support allocation.

    Equal candidates retain the first increasing positive/negative prefix pair.
    This procedural tie rule does not claim global station-vector lexicography.
    """
    _validate(ids, forecast_num, eligible, budget, touch_limit, protected, scale)
    transfer = [0] * len(ids)
    if not budget or touch_limit < 2:
        return transfer
    positive = [i for i, x in enumerate(forecast_num) if x > 0 and eligible[i] and i != protected]
    negative = [i for i, x in enumerate(forecast_num) if x < 0 and eligible[i] and i != protected]
    if not positive or not negative:
        return transfer
    limit = min(touch_limit - 1, len(ids))
    plus = _side_prefixes(positive, ids, forecast_num, limit, scale)
    minus = _side_prefixes(negative, ids, forecast_num, limit, scale)
    baseline = sum(abs(x) for x, allowed in zip(forecast_num, eligible) if allowed)
    best_key, best = (baseline, 0, 0), None
    for p in range(1, len(plus)):
        for n in range(1, min(len(minus), touch_limit - p + 1)):
            moves, gain = _pair_curve(plus[p]["chunks"], minus[n]["chunks"], budget)
            key = (baseline - gain, moves, _touches(plus[p], moves) + _touches(minus[n], moves))
            if key < best_key:
                best_key, best = key, (p, n, moves)
    if best is not None:
        p, n, moves = best
        _fill(plus[p], moves, 1, transfer)
        _fill(minus[n], moves, -1, transfer)
    return transfer


def greedy(ids, forecast_num, eligible, budget, touch_limit, protected=None, scale=60):
    """Best immediate pair gain, reuse stations, remaining magnitude, ASCII IDs.

    Two heaps per sign represent already touched and untouched stations; only
    their four possible leading pairs need comparison for each moved bike.
    """
    _validate(ids, forecast_num, eligible, budget, touch_limit, protected, scale)
    transfer = [0] * len(ids)
    if not budget or touch_limit < 2:
        return transfer
    heaps = [[[], []], [[], []]]  # sign; untouched/touched

    def entry(i):
        remaining = max(0, abs(forecast_num[i]) - scale * abs(transfer[i]))
        gain = min(scale, 2 * remaining - scale)
        return (-gain, -remaining, ids[i], i)

    for i, x in enumerate(forecast_num):
        if x and eligible[i] and i != protected:
            heapq.heappush(heaps[0 if x > 0 else 1][0], entry(i))
    touched = 0
    for _ in range(budget):
        best = None
        for p_kind in (0, 1):
            for n_kind in (0, 1):
                if not heaps[0][p_kind] or not heaps[1][n_kind]:
                    continue
                new = 2 - p_kind - n_kind
                if touched + new > touch_limit:
                    continue
                p, n = heaps[0][p_kind][0], heaps[1][n_kind][0]
                gain = -p[0] - n[0]
                if gain <= 0:
                    continue
                key = (-gain, new, p[1] + n[1], p[2], n[2])
                if best is None or key < best[0]:
                    best = (key, p_kind, n_kind)
        if best is None:
            break
        _, p_kind, n_kind = best
        p = heapq.heappop(heaps[0][p_kind])[3]
        n = heapq.heappop(heaps[1][n_kind])[3]
        transfer[p] += 1
        transfer[n] -= 1
        touched += 2 - p_kind - n_kind
        heapq.heappush(heaps[0][1], entry(p))
        heapq.heappush(heaps[1][1], entry(n))
    return transfer


def evaluate(transfer, actual, forecast_num, eligible, budget, touch_limit, protected=None, scale=60):
    if not (len(transfer) == len(actual) == len(forecast_num) == len(eligible)):
        raise ValueError("station arrays must have equal lengths")
    for value in transfer:
        _integer(value, "transfer")
    for value in actual:
        _integer(value, "actual flow")
    moved_twice = sum(abs(x) for x in transfer)
    moves = moved_twice // 2
    touched = sum(x != 0 for x in transfer)
    feasible = (sum(transfer) == 0 and moved_twice <= 2 * budget and touched <= touch_limit
                and all(not r or allowed for r, allowed in zip(transfer, eligible))
                and (protected is None or transfer[protected] == 0))
    residuals = [abs(d - r) for d, r in zip(actual, transfer)]
    forecast_residual_num = sum(abs(d - scale * r) for d, r, allowed in zip(forecast_num, transfer, eligible) if allowed)
    return {"transfer": list(transfer), "residual": sum(residuals),
            "forecast_residual_num": forecast_residual_num, "forecast_residual": forecast_residual_num / scale,
            "worst_station_residual": max(residuals, default=0), "moves": moves, "touched": touched,
            "unused_budget": budget - moves, "net_flow_bound": abs(sum(actual)), "feasible": feasible}


def all_policies(ids, forecast_num, actual, eligible, budget, touch_limit, protected=None, scale=60):
    _validate(ids, forecast_num, eligible, budget, touch_limit, protected, scale)
    if len(actual) != len(ids):
        raise ValueError("actual flows must match station IDs")
    for value in actual:
        _integer(value, "actual flow")
    transfers = {
        "no_action": [0] * len(ids),
        "greedy": greedy(ids, forecast_num, eligible, budget, touch_limit, protected, scale),
        "optimized": optimize(ids, forecast_num, eligible, budget, touch_limit, protected, scale),
        "oracle": optimize(ids, [x * scale for x in actual], eligible, budget, touch_limit, protected, scale),
    }
    return {name: evaluate(r, actual, forecast_num, eligible, budget, touch_limit, protected, scale)
            for name, r in transfers.items()}
