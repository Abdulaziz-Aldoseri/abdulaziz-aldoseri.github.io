# Mobility data preparation

14 September 2026. Source-only preparation for an independent historical allocation study. No forecast, optimizer, performance comparison or current operational recommendation is produced here.

## Source and interpretation

The inputs are six preserved January–March 2026 journey CSVs from the [TfL cycling open-data bucket](https://cycling.data.tfl.gov.uk/). The exact files, provider modification dates, local sizes and SHA-256 digests are in `data/SOURCE_MANIFEST.json`. The preparer verifies every original CSV digest before reading records. It never rewrites a source file. September station metadata is not an input.

The data are recorded completed journeys. Departures, arrivals and net outflow are bicycles in recorded activity, not attempted demand, inventory, available docks, closures, rider service or operator relocation work. Publication dates are later than the January–March event dates; the experiment assumes access to prior operator observations and does not claim the public files were available at each historical cutoff.

The timestamps carry no explicit offset. The declared convention is the recorded Europe/London local clock. The January 1–March 22 analysis interval is in winter GMT, which equals UTC; no clock shifts are applied. This is an analytical assumption, not a provider-confirmed timezone field. Source rows outside that interval are parsed and audited but do not add later event dates to the model panel.

## Record handling

1. Require the exact eleven-field source schema and preserve station and journey identifiers as strings, including leading zeros and unusual-length terminal identifiers.
2. Compare the entire ordered parsed source record for each journey ID using an unambiguous JSON representation and SHA-256 fingerprint. Keep one exact record for repeated IDs. Any conflicting duplicate ID or invalid row blocks aggregate export and creates a private exception record. There is no arbitrary first-row resolution of conflicts.
3. Require populated source fields, parsed naive start/end timestamps, a positive integer reported duration and an end time no earlier than the start time. Minute-precision start/end values need not equal the millisecond duration exactly.
4. Retain CLASSIC bicycles. Prepare four explicitly labelled views using the reported duration: primary <=24 hours, <=12 hours, <=48 hours and unrestricted positive valid duration. These are scope screens, not a declaration that longer records are erroneous.
5. Exclude the entire journey if either endpoint description contains `workshop` or `_OLD`, case-insensitively. Preserve all such station IDs and source descriptions in `excluded_station_register.csv`; never relabel or merge them into another station. The same row-level rule applies on every date and in every duration view.

## Event extraction and boundaries

Count departures using their actual start date/time and arrivals using their actual end date/time. Both use the half-open morning interval 06:00 inclusive to 10:00 exclusive. A journey may contribute only an arrival, only a departure, both, or neither. A same-station journey contributes separately to both components when both events are in the window. Net outflow is departures minus arrivals; it is not artificially balanced across the network.

Panels cover January 1–March 22, with January 1–4 reserved for history warm-up. Training is January 5–February 15 (42 days), validation February 16–March 1 (14), and test March 2–22 (21). January 1 starts supply sufficient preceding source coverage for all evaluation events under the 12/24/48-hour screens. January 1–4 are not evaluation dates. The unrestricted view remains conditional on the January-start corpus: arrivals from unobserved pre-January starts are unavailable, and very long journeys are known only after completion. It is a source-limited sensitivity, not a complete unrestricted historical flow population.

## Station eligibility and missing availability

The fixed intervention cohort requires an ordinary screened station to have at least one primary-view morning event in at least four of the six training calendar weeks. Training names and coverage are derived only from primary journeys completed strictly before February 16 00:00. Journeys with a training-period event but later completion still contribute to the actual event panel; they do not contribute to admission statistics. A single unambiguous training name is required. The name and admission rule are never determined from validation/test activity or future descriptions.

The full panel retains other ordinary stations and their observed outcomes. Outside-cohort stations must receive no learned intervention or forecast, while their actual residuals remain in network evaluation. New station display names may use the first observed primary source description, explicitly identified as a non-training label. The register retains name provenance, first eligible primary event date/time, training activity counts and admission status.

The first primary eligible event date sets a fixed recorded-history availability mask. Before that date, a zero cell is **unavailable history**, not an observed zero for forecast fitting. From that date onward, a zero means no qualifying recorded morning events in the supplied files. The same primary mask is used in all duration sensitivities so changing a duration screen does not silently change admission or forecast coverage. Actual operational availability remains unknown on every date; neither the mask nor a zero establishes that a station was open or had bicycles.

## Outputs and reproduction

Public export candidates are the four aggregate variant CSVs, `station_register.csv`, `excluded_station_register.csv`, `daily_coverage.csv`, `preparation_summary.json` and `SOURCE_MANIFEST.json`. Raw rows, journey IDs and bicycle numbers are excluded. `data/private_audit/` is private and must not enter a website or download package. The manifest certifies only the explicit seven-CSV allowlist. `--public-only` rejects unrelated files, directories and symlinks in its output directory. The daily coverage table separates full-network events, outside-cohort events, stations with recorded morning activity and stations with primary recorded history. The project-root manifest uses `data/`-relative output paths; the copy inside `data/` uses filenames relative to that directory.

Run with Python 3 standard library, the six official downloaded CSVs in a local source directory, and a separate output directory:

```sh
python prepare_data.py --source-dir /path/to/source-csvs --output-dir /path/to/new-aggregates --min-active-days 1 --min-active-weeks 4 --public-only
python -m unittest discover -s tests -p test_prepare_data.py -v
```

Without explicit directories the script uses the preserved private snapshots and local project data folder. Reproduction does not retrieve current files automatically: changed upstream bytes should trigger a deliberate new source review, not silently replace the frozen corpus.

Every station-day count is reconciled to separately counted event totals by date, side and duration view. The 13 preparation tests challenge exact duplicates and conflicting IDs, duration boundaries, overnight arrivals, 06:00/10:00 inclusivity, whole-journey exclusions, same-station events, source-ID preservation, training-only names, completion cutoff, cohort weeks, history availability, unrecognized output files and missing network source dates. Exact full-corpus results and source hashes are retained in the generated summary and manifest.

## Full-corpus preparation results

All six source hashes match the preserved audit. The corpus has 1,897,417 rows and distinct valid journey IDs, with no exact repeats, conflicting IDs or invalid rows. Of these, 1,532,552 are CLASSIC records. Primary <=24-hour screening retains 1,531,808; whole-journey endpoint exclusion removes a further 3,099, leaving 1,528,709 across all source start dates. The <=12-hour, <=48-hour and unrestricted views retain 1,528,094, 1,529,059 and 1,529,420 respectively after the same endpoint rule.

For all 1,682,082 source records starting January 1–March 22 and ending by March 22, the difference between reported millisecond duration and the displayed minute-precision interval is less than one minute (maximum 59,971 ms). The full six-file corpus has 138 differences of at least one minute, all outside that bounded completed-event interval. The script reports these facts without inventing an explanation or changing source timestamps.

The common panel contains 803 station IDs over 81 dates: 65,043 rows per duration view. The fixed intervention cohort has 798 stations; four lack four active training weeks and one has no training observation. All five remain in actual network counts. Thirty-one primary journeys have a training event but complete at or after February 16 00:00; they are excluded from admission metrics only.

| Primary window | Departures | Arrivals | Net outflow |
| --- | ---: | ---: | ---: |
| Training, Jan 5–Feb 15 | 171,067 | 164,460 | 6,607 |
| Validation, Feb 16–Mar 1 | 62,175 | 59,529 | 2,646 |
| Test, Mar 2–22 | 104,491 | 99,512 | 4,979 |

These figures differ from the earlier planning audit because the final customer-mobility cohort additionally excludes whole journeys involving `_OLD` terminals. The original source is unchanged. Primary evaluation includes 273 morning arrivals from prior-date starts, including one from the January 1–4 warm-up. All counts are descriptive preparation facts, not model performance.

Excluded terminal IDs and source descriptions are preserved: `0010684444` Norton Folgate, Liverpool Street_OLD; `0011884444` London Zoo Car Park, The Regent's Park_OLD; `2001454444` Gloucester Avenue, Camden Town_OLD; `010626` Mechanical Workshop Penton; and `022168` Mechanical Workshop Clapham. The register reports per-terminal raw journey incidences; these must not be summed as distinct excluded journeys because one journey can touch two excluded endpoints. Ordinary replacement IDs remain separate. In particular, ordinary Norton Folgate `001068` first appears March 5 and is outside the fixed intervention cohort.

## Attribution

Powered by TfL Open Data  
Contains OS data © Crown copyright and database rights 2016  
Geomni UK Map data © and database rights [2019]

Reuse is governed by the [TfL Transport Data Service terms](https://tfl.gov.uk/corporate/terms-and-conditions/transport-data-service), with TfL-specific amendments based on OGL v2.0. Data rights are separate from any code licence. This independent analysis is not endorsed by or affiliated with TfL.
