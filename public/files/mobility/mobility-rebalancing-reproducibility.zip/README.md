# Where should rebalancing effort go?

Independent historical decision study by Abdulaziz Aldoseri. Choose a limited number of pre-morning bicycle transfers across London cycle-hire stations, then compare a transparent greedy rule and an exact integer allocation with no action and a perfect-information reference. The complete ordinary network remains in the score, including stations outside the fixed intervention cohort.

The result is **residual recorded flow imbalance under a hypothetical allocation**. It is not observed inventory, unmet demand, rider service, stockout reduction, cost savings or a feasible truck dispatch. Budgets and optional station protection are explicit scenario assumptions; historical bike/dock availability, vehicle routes and operational constraints are not supplied by the journey data.

## Open and use the notebook

Open `mobility_rebalancing.ipynb` from the extracted project folder. The notebook introduces the decision and information before its code, then lets you select a test date, bike-move budget, station-touch limit and optional protected station. It runs all four policies, shows station transfers and separately recomputes every test day at the selected budgets without protection. The latter is reconciled to the saved full-period results. It also shows the after-evaluation least-beneficial date, coverage, weekday/weekend results and duration sensitivities. That date may still improve on no action; its label does not imply that worsening occurred.

Local setup does not install software or access the network. Use a Python notebook kernel with `numpy==2.3.5`, `pandas==3.0.1` and `scipy==1.16.3`. A notebook environment supplies its usual display/kernel packages. The model, pipeline and data preparation use the Python standard library; pandas supports notebook tables, and NumPy/SciPy support the independent reference-solver tests.

For optional Google Colab use, upload the notebook, run setup and select the reproduction ZIP. An embedded helper validates paths, file sizes and every archive hash before extracting project code; only then are pinned dependencies installed. It does not mount Google Drive or download the source corpus automatically. It rejects traversal, symlinks, case/path collisions, raw journey CSVs, unmanifested members, oversized content and nonempty extraction destinations. Original notebook bytes are verified at extraction; subsequent local checks allow changed notebook parameters/outputs while still checking code, data and requirements. A manifest checks integrity, not publisher identity; use the study's own download and its published archive checksum when available. **Hosted Colab execution has not been verified.**

## Files and chronology

- `PROTOCOL.json` freezes chronology, information rules, forecasts, budgets, tie rules and metrics before validation/test scoring. `METHODS.md` explains the formulation and proof boundary; `RESULTS.md` reports evaluated comparisons and limits.
- `mobility_model.py` implements integer conserved transfers and all four policies. `pipeline.py` selects a global prior-weekday history length on validation, freezes input hashes, and evaluates the complete held-out grid.
- `data/station_register.csv` preserves string terminal IDs, names/provenance, first-observation date, training coverage and the fixed intervention flag. Four aggregate duration CSVs contain `date,split,station_id,departures,arrivals,net_outflow,history_available`. Read station IDs as strings.
- `data/daily_coverage.csv`, `excluded_station_register.csv`, `preparation_summary.json` and `SOURCE_MANIFEST.json` document event coverage, exclusions, source hashes and interpretation. `DATA_PREPARATION.md` explains the exact extraction rules.
- `outputs/public_index.json` supplies the same saved observations, forecasts and evidence used by the interactive page. Full allocation vectors, daily scores, sensitivities, forecast diagnostics, weekday segments and integrity checks accompany it.

January 1–4 supplies warm-up starts; training is January 5–February 15 (42 days), validation February 16–March 1 (14), and test March 2–22, 2026 (21). Training admission requires morning activity in at least four training calendar weeks, from eligible journeys completed strictly before February 16 00:00. New/sparse ordinary terminals remain in outcome scores with zero transfers and no forecast. Before first eligible observation a zero panel cell is unavailable history; thereafter zero means no qualifying recorded event, not proof of operational availability.

The forecast uses prior same-weekday calendar lags. Validation chooses one global length from 1, 2, 4 or 6; unavailable earlier station dates are skipped without extending the horizon. Each later plan uses the fixed rolling rule. Bounded-duration observations are mature at the minimum seven-day forecast lag. The public January–March files were modified in June: this retrospective event-time design assumes access to the operator's earlier completed observations, not historical availability of the public release.

## Reproduce from the aggregates

Use a new output directory to retain the provided frozen evidence:

```sh
python pipeline.py --phase validate --output-dir outputs/reproduced
python pipeline.py --phase evaluate --output-dir outputs/reproduced
python -m unittest discover -s tests -v
```

The pipeline refuses to replace a validation freeze or completed evaluation in the same result directory. Input hashes guard the protocol, primary/sensitivity panels, station cohort and exact model/pipeline code. Comparing newly reproduced numerical outputs with the supplied evidence is appropriate; execution timestamps need not be identical. The notebook itself does not automatically rerun the complete pipeline.

## Reproduce from the official journey files

The public archive contains station-level aggregates, not journey or bicycle identifiers, original trip CSVs, current station metadata, private audit files or local paths. The original six files total 315,650,255 bytes. Exact download URLs, lengths and SHA-256 hashes are in `data/SOURCE_MANIFEST.json`.

Obtain the six unchanged official CSVs in a separate local directory and run:

```sh
python prepare_data.py --source-dir /path/to/source-csvs --output-dir /path/to/new-aggregates --min-active-days 1 --min-active-weeks 4 --public-only
```

The notebook includes an optional source-download cell, disabled by default and requiring an explicit `REBUILD_FROM_RAW=True`. It does not overwrite existing raw files, verifies frozen bytes and runs preparation in a new directory. Changed provider files require a new source review. Raw snapshots stay outside public packaging.

Preparation verifies source hashes, deduplicates exact journey IDs, fails on conflicting IDs/invalid records, retains CLASSIC bikes, and excludes entire journeys with workshop or `_OLD` endpoint names. Original terminal IDs remain separate. Each start and end event contributes independently to its own 06:00–10:00 morning window. The primary screen uses reported duration <=24 hours. Sensitivities use <=12 hours, <=48 hours and unrestricted valid duration with fixed cohort/history masks. The unrestricted view is left-censored by the January-start corpus and later completion; it is a conditional diagnostic, not a full-population or as-issued backtest.

## Attribution and scope

Powered by TfL Open Data  
Contains OS data © Crown copyright and database rights 2016  
Geomni UK Map data © and database rights [2019]

[Official cycling data](https://cycling.data.tfl.gov.uk/) · [Open-data documentation](https://tfl.gov.uk/info-for/open-data-users/our-open-data) · [TfL Transport Data Service terms](https://tfl.gov.uk/corporate/terms-and-conditions/transport-data-service).

The TfL terms contain specific amendments based on OGL v2.0; source rights are separate from any code licence. No affiliation or endorsement is implied. Naive source times are interpreted as London local winter time, a documented assumption without an explicit provider offset. This eleven-week winter corpus and three-week test do not establish all-season performance, a causal intervention effect or applicability to other cities. Preserve adverse days and ties when presenting the study.
