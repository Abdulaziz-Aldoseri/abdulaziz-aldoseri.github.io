# Which aircraft mix covers the service plan?

An independent airline capacity-planning study by Abdulaziz Aldoseri. Choose service targets and an aircraft-hour envelope, then compare a minimum-fleet composition with a historical-share allocation across eight Denver regional routes and all twelve months of 2025.

The study uses openly released U.S. DOT/BTS T-100 Domestic Segment data. It is a retrospective aggregate planning envelope. It does not represent an airline assignment, procurement recommendation, actual fleet count, achieved savings or timetable-feasible operation.

## Reproduce locally

Use Python 3.12 and install the pinned dependencies in `requirements.txt`. Open `airline_fleet.ipynb` inside this extracted directory, or run:

```sh
python -m unittest discover -s tests -v
python prepare_data.py
python pipeline.py
```

The data and code are verified against `MODEL_FREEZE.json` before evaluation. Preparation independently rebuilds the eight-route inputs from the included original-value BTS carrier/hub subset and rejects altered source bytes. It does not download data. The complete 455,857-row original export is preserved separately; its hash and public export controls are recorded in `source_manifest.json`.

The notebook includes optional Google Colab setup: upload the notebook, then the study reproduction ZIP when prompted. The helper verifies paths, sizes and checksums before importing code, and installs the pinned requirements in Colab. No Google Drive mount is required. Hosted Colab execution has not been verified; local notebook execution is the release check.

## Read the evidence

- `METHODS.md`: practical decision, variables, assumptions, constraints and comparison.
- `DATA_PREPARATION.md`: source coverage, exclusions and coefficients.
- `PROTOCOL.json`: frozen scenario/evaluation specification.
- `RESULTS.md`: evaluated findings and limits.
- `outputs/scenario_summary.csv`: all 27 cases.
- `outputs/assignments.csv`: both policies' route/type/month round trips.
- `outputs/airline-index.json`: the complete browser payload and solver certificates.

Source: U.S. Department of Transportation, Bureau of Transportation Statistics, [T-100 Domestic Segment (U.S. Carriers)](https://www.transtats.bts.gov/DL_SelectFields.aspx?QO_fu146_anzr=Nv4+Pn44vr45&gnoyr_VQ=FIM), 2025; accessed 14 September 2026. Independent analysis; no airline or government endorsement. Source-data reuse is documented separately from the MIT licence covering original study code.
