"""Integer pooled aircraft sizing, with exact input and feasibility arithmetic."""
from __future__ import annotations
import itertools, math, time
from fractions import Fraction
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix, vstack

def ceil_fraction(value: Fraction) -> int: return -(-value.numerator // value.denominator)

def targets(data, parameters, protocol):
    p=Fraction(str(parameters['passenger_multiplier']))
    f=Fraction(str(parameters['frequency_fraction']))
    h=Fraction(str(parameters['daily_operating_hours']))
    reserve=Fraction(str(protocol['scenarios']['reserve_fraction']))
    if p<0 or not 0<=f<=1 or h<=0 or not 0<=reserve<1: raise ValueError('Invalid scenario values')
    available={str(m):math.floor(Fraction(data['days_by_month'][str(m)])*h*60*(1-reserve)) for m in data['months']}
    if any(v<=0 for v in available.values()): raise ValueError('No available aircraft minutes')
    result=[]
    for route in data['routes']:
        if not route['coefficients']: raise ValueError('Route has no feasible aircraft type')
        for observation in route['observations']:
            result.append({'route_id':route['id'],'month':observation['month'],'target_passengers':ceil_fraction(p*max(observation['out_passengers'],observation['in_passengers'])),'target_roundtrips':ceil_fraction(f*max(observation['out_departures'],observation['in_departures']))})
    return result,available

def apportion(q, coefficients):
    if not isinstance(q,int) or q<0: raise ValueError('q must be a nonnegative integer')
    shares={t:Fraction(c['share_numerator'],c['share_denominator']) for t,c in coefficients.items()}
    if sum(shares.values())!=1 or any(s<0 for s in shares.values()): raise ValueError('Invalid historical shares')
    raw={t:q*s for t,s in shares.items()}
    allocation={t:math.floor(v) for t,v in raw.items()}
    remaining=q-sum(allocation.values())
    order=sorted(shares,key=lambda t:(-(raw[t]-allocation[t]),int(t)))
    for t in order[:remaining]: allocation[t]+=1
    assert sum(allocation.values())==q
    return allocation

def evaluate(data, parameters, protocol, fleet, assignments, policy):
    needed,available=targets(data,parameters,protocol)
    types=[t['id'] for t in data['types']]
    routes={r['id']:r for r in data['routes']}
    if set(fleet)!=set(types) or any(not isinstance(v,int) or v<0 for v in fleet.values()): raise ValueError('Invalid integer fleet')
    plan={}; used={(t,m):0 for t in types for m in data['months']}
    turn=protocol['scenarios']['turnaround_minutes_per_leg']
    for a in assignments:
        key=(a['route_id'],a['month'],a['type_id'])
        if key in plan: raise ValueError('Duplicate assignment')
        r,m,t=key; q=a['roundtrips']
        if r not in routes or m not in data['months'] or t not in routes[r]['coefficients']: raise ValueError('Invalid route, month or aircraft pair')
        if not isinstance(q,int) or q<0: raise ValueError('Noninteger/negative round trips')
        plan[key]=q
        used[(t,m)]+=q*(routes[r]['coefficients'][t]['block_minutes']+2*turn)
    outcomes=[]
    for target in needed:
        r=target['route_id']; m=target['month']; coeff=routes[r]['coefficients']
        q=sum(plan.get((r,m,t),0) for t in coeff)
        seats=sum(plan.get((r,m,t),0)*c['seats'] for t,c in coeff.items())
        if q<target['target_roundtrips'] or seats<target['target_passengers']: raise ValueError('Service constraint violated')
        outcomes.append({**target,'seats':seats,'roundtrips':q,'seat_surplus':seats-target['target_passengers'],'roundtrip_surplus':q-target['target_roundtrips']})
    utilization=[]
    for t in types:
        for m in data['months']:
            cap=fleet[t]*available[str(m)]
            if used[(t,m)]>cap: raise ValueError('Aircraft-minute constraint violated')
            utilization.append({'type_id':t,'month':m,'used_minutes':used[(t,m)],'available_minutes':cap,'unused_minutes':cap-used[(t,m)],'utilization_fraction':used[(t,m)]/cap if cap else 0})
    return {'policy':policy,'fleet_by_type':fleet,'total_fleet':sum(fleet.values()),'total_roundtrips':sum(a['roundtrips'] for a in assignments),'total_minutes':sum(used.values()),'assignments':assignments,'utilization':utilization,'route_outcomes':outcomes,'feasibility':{'integer':True,'service_constraints':True,'aircraft_minute_constraints':True}}

def baseline(data, parameters, protocol):
    needed,available=targets(data,parameters,protocol)
    routes={r['id']:r for r in data['routes']}
    types=[t['id'] for t in data['types']]
    used={(t,m):0 for t in types for m in data['months']}
    assignments=[]
    turn=protocol['scenarios']['turnaround_minutes_per_leg']
    for target in needed:
        r=target['route_id'];m=target['month'];coeff=routes[r]['coefficients']
        minimum_seats=min(c['seats'] for c in coeff.values())
        if minimum_seats<=0: raise ValueError('No usable seats')
        upper=max(target['target_roundtrips'],ceil_fraction(Fraction(target['target_passengers'],minimum_seats)))
        for q in range(target['target_roundtrips'],upper+1):
            allocation=apportion(q,coeff)
            if sum(allocation[t]*c['seats'] for t,c in coeff.items())>=target['target_passengers']: break
        else: raise AssertionError('Guaranteed baseline bound failed')
        for t,roundtrips in allocation.items():
            assignments.append({'route_id':r,'month':m,'type_id':t,'roundtrips':roundtrips})
            used[(t,m)]+=roundtrips*(coeff[t]['block_minutes']+2*turn)
    fleet={t:max(ceil_fraction(Fraction(used[(t,m)],available[str(m)])) for m in data['months']) for t in types}
    return evaluate(data,parameters,protocol,fleet,assignments,'historical_shares')

def optimize(data, parameters, protocol):
    reference=baseline(data,parameters,protocol)
    needed,available=targets(data,parameters,protocol)
    types=[t['id'] for t in data['types']]
    routes={r['id']:r for r in data['routes']}
    variables=[('fleet',t) for t in types]+[(a['route_id'],a['month'],t) for a in needed for t in routes[a['route_id']]['coefficients']]
    indices={k:i for i,k in enumerate(variables)}
    n=len(variables); rows=[]; low=[]; high=[]
    upper=np.full(n,float('inf'))
    for t in types: upper[indices[('fleet',t)]]=reference['total_fleet']
    for target in needed:
        r=target['route_id'];m=target['month'];coeff=routes[r]['coefficients']
        seats=np.zeros(n);frequency=np.zeros(n)
        q_bound=max(target['target_roundtrips'],ceil_fraction(Fraction(target['target_passengers'],min(c['seats'] for c in coeff.values()))))
        for t,c in coeff.items():
            i=indices[(r,m,t)];seats[i]=c['seats'];frequency[i]=1;upper[i]=q_bound
        rows.extend([seats,frequency]);low.extend([target['target_passengers'],target['target_roundtrips']]);high.extend([np.inf,np.inf])
    turn=protocol['scenarios']['turnaround_minutes_per_leg']
    for t in types:
        for m in data['months']:
            row=np.zeros(n);row[indices[('fleet',t)]]=-available[str(m)]
            for r,route in routes.items():
                if t in route['coefficients']: row[indices[(r,m,t)]]=route['coefficients'][t]['block_minutes']+2*turn
            rows.append(row);low.append(-np.inf);high.append(0)
    matrix=csr_matrix(np.asarray(rows));lower=np.array(low);higher=np.array(high)
    fleet_obj=np.zeros(n);flights_obj=np.zeros(n);minutes_obj=np.zeros(n)
    for key,i in indices.items():
        if key[0]=='fleet':fleet_obj[i]=1
        else:
            r,m,t=key;flights_obj[i]=1;minutes_obj[i]=routes[r]['coefficients'][t]['block_minutes']+2*turn
    certificates=[]; solution=None
    for name,objective in [('aircraft',fleet_obj),('roundtrips',flights_obj),('minutes',minutes_obj)]:
        start=time.perf_counter()
        result=milp(objective,integrality=np.ones(n),bounds=Bounds(np.zeros(n),upper),constraints=LinearConstraint(matrix,lower,higher),options={'mip_rel_gap':0.0,'time_limit':protocol['solver']['time_limit_seconds_per_stage']})
        elapsed=time.perf_counter()-start
        if result.status!=0 or result.x is None or result.mip_gap!=0.0: raise RuntimeError(f'No certified optimum for {name}: {result.message}')
        solution=np.rint(result.x).astype(int)
        if np.max(np.abs(solution-result.x))>1e-6: raise RuntimeError('Noninteger solver result')
        objective_value=int(np.dot(objective,solution))
        if abs(result.fun-objective_value)>1e-5: raise RuntimeError('Objective does not match integer solution')
        product=matrix@solution
        if np.any(product<lower-1e-7) or np.any(product>higher+1e-7): raise RuntimeError('Rounded solution violates constraints')
        certificates.append({'stage':name,'status':int(result.status),'objective':objective_value,'dual_bound':float(result.mip_dual_bound),'relative_gap':float(result.mip_gap),'nodes':int(result.mip_node_count),'wall_seconds':elapsed,'message':result.message})
        matrix=vstack([matrix,csr_matrix(objective.reshape(1,-1))],format='csr')
        lower=np.append(lower,objective_value);higher=np.append(higher,objective_value)
    fleet={t:int(solution[indices[('fleet',t)]]) for t in types}
    assignments=[{'route_id':key[0],'month':key[1],'type_id':key[2],'roundtrips':int(solution[i])} for key,i in indices.items() if key[0]!='fleet']
    evaluated=evaluate(data,parameters,protocol,fleet,assignments,'minimum_fleet')
    if evaluated['total_fleet']>reference['total_fleet']: raise RuntimeError('Optimized count exceeds feasible baseline')
    evaluated['solver']=certificates
    return evaluated,reference

def cap_feasibility(result, cap):
    if cap is not None and (not isinstance(cap,int) or isinstance(cap,bool) or cap<0): raise ValueError('Fleet cap must be a nonnegative integer or None')
    return cap is None or result['total_fleet']<=cap
