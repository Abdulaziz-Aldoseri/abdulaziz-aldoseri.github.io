# Evaluated findings

The predefined reference scenario covers 100% of the selected routes' recorded carried passengers, at least 75% of their recorded performed-departure frequency, and an 8-hour daily operating envelope. A 30-minute turn per leg and 10% unavailable/reserve capacity are explicit assumptions. All targets are known 2025 observations.

| Reference result | Minimum-fleet solution | Historical-share policy |
| --- | ---: | ---: |
| Aircraft required across the full year | 22 | 25 |
| BTS type 629 | 0 | 10 |
| BTS type 631 | 10 | 4 |
| BTS type 673 | 12 | 11 |
| Annual paired round trips | 13,391 | 14,311 |
| Annual modeled aircraft minutes | 3,016,702 | 3,277,709 |

At those same service targets, changing the daily envelope to 6 hours raises the minimum to 29 aircraft; 10 hours lowers it to 18. The reference case is infeasible with fewer than 22 aircraft in this model. A cap of 22 meets the optimized requirement but cannot accommodate the 25-aircraft historical-share policy.

Across all 27 predefined combinations, the minimum required fleet ranges from 14 to 37 aircraft. It is 2–6 aircraft below the feasible historical-share policy in every case; no tie or adverse fleet-count result occurred in this grid. The optimized plans also use no more paired trips or model minutes than that baseline in these cases. These findings describe this bounded envelope and comparison; they do not establish future or general superiority over airline practice.

All 81 lexicographic stages completed with solver status 0 and exactly zero reported relative gap. Rounded integer solutions passed every service and aircraft-minute constraint. Increasing available hours did not increase the minimum fleet. The largest-remainder baseline was fixed before optimization after independent review; there was no result-based parameter or route retuning.

The source contains 455,857 monthly 2025 records. The eight selected routes represent 1,720,796 carried passengers, about 23.26% of the retained SkyWest/Denver traffic across all types. Aircraft counts are hypothetical pooled requirements for this subset, not the actual SkyWest fleet. The favorable comparison partly reflects the freedom to change type shares and pool aircraft hours without within-day aircraft rotations, crew, maintenance, contracts, airport constraints or costs. It is not evidence that aircraft could be removed from real service or that financial savings would follow.

One optimal composition is shown. Other compositions may share the same primary or secondary objective values. The 0-aircraft allocation to type 629 in the reference result is not a recommendation to retire that aircraft type.

The complete assignments, service surpluses, utilization and solver certificates are in `outputs/airline-index.json`. CSV tables contain all scenarios and both policies. Following implementation review, output-overwrite protection and final freeze checks were strengthened and zero-gap acceptance made exact. The unchanged protocol was rerun; all 27 fleet mixes, assignments and objective totals matched the preserved earlier candidate.
