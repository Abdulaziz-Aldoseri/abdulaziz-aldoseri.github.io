import copy, itertools, json, pathlib, tempfile, unittest
import sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from fleet_model import apportion,baseline,optimize,evaluate,cap_feasibility,targets
from prepare_data import prepare

def instance(seats=(2,3),minutes=(4,6),months=(1,),passengers=(5,),departures=(1,),days=(1,)):
    return {'types':[{'id':'1','label':'Test1'},{'id':'2','label':'Test2'}],'months':list(months),'days_by_month':dict(zip(map(str,months),days)),'routes':[{'id':'10','coefficients':{str(i+1):{'seats':s,'block_minutes':minutes[i],'share_numerator':1,'share_denominator':2} for i,s in enumerate(seats)},'observations':[{'month':m,'out_passengers':p,'in_passengers':p-1 if p else 0,'out_departures':f,'in_departures':f} for m,p,f in zip(months,passengers,departures)]}]}
def protocol():return {'scenarios':{'reserve_fraction':0,'turnaround_minutes_per_leg':0},'solver':{'time_limit_seconds_per_stage':20}}
def params(hours=.2):return {'passenger_multiplier':1,'frequency_fraction':1,'daily_operating_hours':hours}

class FleetTests(unittest.TestCase):
    def test_exact_total_largest_remainders(self):
        c={'1':{'share_numerator':1,'share_denominator':3},'2':{'share_numerator':2,'share_denominator':3}}
        self.assertEqual(apportion(1,c),{'1':0,'2':1})
        for q in range(100):self.assertEqual(sum(apportion(q,c).values()),q)
    def test_exhaustive_primary_and_both_secondary_objectives(self):
        for seats,minutes,pax,freq in [((2,3),(4,6),5,1),((2,3),(7,3),5,2),((3,3),(4,4),8,1),((1,4),(2,9),7,2)]:
            d=instance(seats,minutes,passengers=(pax,),departures=(freq,));par=params(.2);pro=protocol()
            solved,_=optimize(d,par,pro)
            candidates=[]
            for a,b in itertools.product(range(9),repeat=2):
                if a+b<freq or a*seats[0]+b*seats[1]<pax:continue
                n1=-(-(a*minutes[0])//12);n2=-(-(b*minutes[1])//12)
                candidates.append((n1+n2,a+b,a*minutes[0]+b*minutes[1]))
            self.assertEqual((solved['total_fleet'],solved['total_roundtrips'],solved['total_minutes']),min(candidates))
    def test_shared_yearly_fleet_meets_each_month(self):
        d=instance(months=(1,2),passengers=(5,10),departures=(1,2),days=(1,2))
        solved,ref=optimize(d,params(),protocol())
        self.assertLessEqual(solved['total_fleet'],ref['total_fleet'])
        self.assertTrue(all(u['used_minutes']<=u['available_minutes'] for u in solved['utilization']))
    def test_zero_service(self):
        solved,ref=optimize(instance(passengers=(0,),departures=(0,)),params(),protocol())
        self.assertEqual((solved['total_fleet'],solved['total_roundtrips'],ref['total_fleet']),(0,0,0))
    def test_single_type(self):
        d=instance();del d['routes'][0]['coefficients']['2'];d['routes'][0]['coefficients']['1']['share_denominator']=1
        solved,_=optimize(d,params(),protocol());self.assertEqual(solved['fleet_by_type']['2'],0)
    def test_cap_is_separate_for_each_policy(self):
        self.assertTrue(cap_feasibility({'total_fleet':2},2));self.assertFalse(cap_feasibility({'total_fleet':3},2))
        self.assertFalse(cap_feasibility({'total_fleet':2},0));self.assertTrue(cap_feasibility({'total_fleet':2},None))
        for bad in [-1,.5,True]:
            with self.assertRaises(ValueError):cap_feasibility({'total_fleet':2},bad)
    def test_mutated_plan_violates_conservation_of_hours(self):
        d=instance();solved,_=optimize(d,params(),protocol());bad=copy.deepcopy(solved['fleet_by_type'])
        for t in bad:
            if bad[t]:bad[t]-=1;break
        with self.assertRaises(ValueError):evaluate(d,params(),protocol(),bad,solved['assignments'],'bad')
    def test_invalid_scenario_and_missing_pair(self):
        with self.assertRaises(ValueError):targets(instance(),params(0),protocol())
        d=instance();d['routes'][0]['coefficients']={}
        with self.assertRaises(ValueError):baseline(d,params(),protocol())
    def test_source_hash_rejects_changed_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=pathlib.Path(temporary)/'observed_segments.csv';path.write_text('tampered\n')
            with self.assertRaisesRegex(ValueError,'admitted source manifest'):prepare(path)

if __name__=='__main__':unittest.main()
