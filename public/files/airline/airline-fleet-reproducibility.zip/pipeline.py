"""Reproduce all predeclared scenarios after verifying the frozen inputs/model."""
from __future__ import annotations
import csv, datetime, hashlib, itertools, json, pathlib, platform, sys
import scipy,numpy
from fleet_model import optimize,targets,cap_feasibility

ROOT=pathlib.Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def verify_freeze():
    manifest=json.loads((ROOT/'MODEL_FREEZE.json').read_text(encoding='utf-8'))
    for relative,expected in manifest['sha256'].items():
        path=ROOT/relative
        if not path.is_file() or sha(path)!=expected:raise RuntimeError(f'Frozen input or model changed: {relative}')
    return manifest
def run(output_directory='reproduced_outputs'):
    frozen=verify_freeze();protocol=json.loads((ROOT/'PROTOCOL.json').read_text(encoding='utf-8'));data=json.loads((ROOT/'data/planning_inputs.json').read_text(encoding='utf-8'));source=json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8'))
    if data['protocol_sha256']!=sha(ROOT/'PROTOCOL.json'):raise RuntimeError('Preparation protocol hash mismatch')
    output=(ROOT/output_directory).resolve()
    if not output.is_relative_to(ROOT.resolve()) or output==ROOT.resolve():raise ValueError('Output must be a child directory of the study')
    if output.exists() and (not output.is_dir() or any(output.iterdir())):raise FileExistsError('Choose a new or empty output directory; completed runs are never overwritten')
    cases=[];summary=[];allocations=[]
    for p,f,h in itertools.product(protocol['scenarios']['passenger_multiplier'],protocol['scenarios']['frequency_fraction'],protocol['scenarios']['daily_operating_hours']):
        parameters={'passenger_multiplier':p,'frequency_fraction':f,'daily_operating_hours':h}
        scenario_id=f'p{round(p*100)}-f{round(f*100)}-h{h}'
        solved,reference=optimize(data,parameters,protocol)
        target,available=targets(data,parameters,protocol)
        cases.append({'id':scenario_id,'parameters':parameters,'targets':target,'available_minutes_per_aircraft':available,'optimized':solved,'baseline':reference,'fleet_cap_stress':{'zero_cap_feasible':cap_feasibility(solved,0),'below_minimum_cap':max(0,solved['total_fleet']-1),'below_minimum_feasible':cap_feasibility(solved,max(0,solved['total_fleet']-1)),'minimum_cap':solved['total_fleet'],'minimum_cap_feasible':cap_feasibility(solved,solved['total_fleet']),'baseline_feasible_at_optimized_minimum_cap':cap_feasibility(reference,solved['total_fleet'])}})
        summary.append({'scenario_id':scenario_id,**parameters,'optimized_fleet':solved['total_fleet'],'baseline_fleet':reference['total_fleet'],'fleet_difference':reference['total_fleet']-solved['total_fleet'],'optimized_roundtrips':solved['total_roundtrips'],'baseline_roundtrips':reference['total_roundtrips'],'optimized_minutes':solved['total_minutes'],'baseline_minutes':reference['total_minutes'],**{f'optimized_type_{t}':v for t,v in solved['fleet_by_type'].items()}})
        for policy,plan in [('optimized',solved),('historical_shares',reference)]:
            for a in plan['assignments']:allocations.append({'scenario_id':scenario_id,'policy':policy,**a})
        print(f"{scenario_id}: minimum {solved['total_fleet']} | historical shares {reference['total_fleet']}",flush=True)
    byid={r['id']:r for r in cases}
    for p,f in itertools.product(protocol['scenarios']['passenger_multiplier'],protocol['scenarios']['frequency_fraction']):
        values=[byid[f'p{round(p*100)}-f{round(f*100)}-h{h}']['optimized']['total_fleet'] for h in protocol['scenarios']['daily_operating_hours']]
        if any(a<b for a,b in zip(values,values[1:])):raise AssertionError('More aircraft hours increased minimum fleet')
    payload={'schema_version':'1.0.0','study_id':'airline-fleet','title':protocol['title'],'interpretation':protocol['scope']['interpretation'],'year':2025,'carrier':data['carrier_name'],'hub':'DEN','types':data['types'],'routes':data['routes'],'months':data['months'],'days_by_month':data['days_by_month'],'default_scenario_id':'p100-f75-h8','scenario_choices':{k:protocol['scenarios'][k] for k in ['passenger_multiplier','frequency_fraction','daily_operating_hours']},'fixed_assumptions':{'turnaround_minutes_per_leg':protocol['scenarios']['turnaround_minutes_per_leg'],'reserve_fraction':protocol['scenarios']['reserve_fraction']},'source':{'name':source['dataset'],'provider':source['provider'],'url':source['source_url'],'credit':source['reuse']['credit'],'source_manifest_sha256':sha(ROOT/'source_manifest.json')},'coverage':json.loads((ROOT/'data/preparation_audit.json').read_text())['selected_share_of_carrier_hub_passengers'],'protocol_sha256':sha(ROOT/'PROTOCOL.json'),'model_freeze_sha256':sha(ROOT/'MODEL_FREEZE.json'),'scenarios':cases}
    if verify_freeze()!=frozen:raise RuntimeError('The model freeze changed during evaluation')
    output.mkdir(exist_ok=True)
    if any(output.iterdir()):raise FileExistsError('Output directory changed during evaluation')
    (output/'airline-index.json').write_text(json.dumps(payload,separators=(',',':'))+'\n',encoding='utf-8')
    for filename,rows in [('scenario_summary.csv',summary),('assignments.csv',allocations)]:
        with (output/filename).open('w',newline='',encoding='utf-8') as fp:
            writer=csv.DictWriter(fp,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    record={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'scipy':scipy.__version__,'numpy':numpy.__version__,'scenario_count':len(cases),'solver_stages':sum(len(c['optimized']['solver']) for c in cases),'all_solutions_exactly_feasible':True,'all_mip_gaps_zero':all(stage['relative_gap']==0 for c in cases for stage in c['optimized']['solver']),'hours_monotonicity_pass':True,'outputs_sha256':{p.name:sha(p) for p in output.iterdir() if p.name in ['airline-index.json','scenario_summary.csv','assignments.csv']},'freeze':frozen}
    (output/'run_manifest.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    return payload
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir',default='reproduced_outputs');args=parser.parse_args()
    run(args.output_dir)
