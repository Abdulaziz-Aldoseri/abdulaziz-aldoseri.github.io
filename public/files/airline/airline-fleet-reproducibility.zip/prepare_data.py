"""Reproduce a retrospective fleet-planning input from original BTS row values."""
from __future__ import annotations
import calendar, collections, csv, hashlib, io, json, math, pathlib, zipfile
from fractions import Fraction

ROOT = pathlib.Path(__file__).resolve().parent
FIELDS = ['DEPARTURES_SCHEDULED','DEPARTURES_PERFORMED','SEATS','PASSENGERS','DISTANCE','RAMP_TO_RAMP','AIR_TIME','UNIQUE_CARRIER','AIRLINE_ID','UNIQUE_CARRIER_NAME','ORIGIN_AIRPORT_ID','ORIGIN','DEST_AIRPORT_ID','DEST','AIRCRAFT_TYPE','AIRCRAFT_CONFIG','YEAR','MONTH','CLASS']
MEASURES = FIELDS[:7]

def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def number(value):
    value = Fraction(value)
    if value.denominator != 1: raise ValueError(f'Expected integer source measure: {value}')
    return int(value)
def ceilfrac(value): return -(-value.numerator // value.denominator)

def prepare(source: pathlib.Path | None = None):
    protocol = json.loads((ROOT/'PROTOCOL.json').read_text())
    source = source or ROOT/'data'/'observed_segments.csv'
    manifest=json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8'))
    expected=next((entry for entry in manifest['files'] if entry['filename']==source.name),None)
    if expected is None or source.stat().st_size!=expected['bytes'] or sha(source)!=expected['sha256']:
        raise ValueError('Source bytes do not match the admitted source manifest')
    full = source.suffix.lower() == '.zip'
    if full:
        with zipfile.ZipFile(source) as z:
            entries = [n for n in z.namelist() if n.lower().endswith('.csv')]
            if len(entries) != 1: raise ValueError('Expected exactly one CSV source member')
            reader = csv.DictReader(io.TextIOWrapper(z.open(entries[0]),encoding='utf-8-sig'))
            if reader.fieldnames != FIELDS: raise ValueError('Source fields changed')
            rows = list(reader)
    else:
        with source.open(newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            if reader.fieldnames != FIELDS: raise ValueError('Source subset fields changed')
            rows = list(reader)
    raw_n = len(rows)
    seen=set(); duplicates=0; unique=[]
    for row in rows:
        key=tuple(row[f] for f in FIELDS)
        if key in seen: duplicates+=1; continue
        seen.add(key); unique.append(row)
    missing=sum(v=='' for r in unique for v in r.values())
    if missing: raise ValueError(f'Source contains {missing} missing cells')
    years=sorted({number(r['YEAR']) for r in unique})
    months=sorted({number(r['MONTH']) for r in unique})
    if years != [2025] or months != list(range(1,13)): raise ValueError('Expected full 2025 coverage')
    focus=[r for r in unique if r['UNIQUE_CARRIER']=='OO' and (r['ORIGIN']=='DEN' or r['DEST']=='DEN') and r['CLASS']=='F' and r['AIRCRAFT_CONFIG']=='1']
    if not focus: raise ValueError('No selected carrier/hub records')
    all_types=collections.Counter(r['AIRCRAFT_TYPE'] for r in focus)
    selected_types=set(protocol['scope']['types'])
    screening=collections.Counter(); valid=[]
    for row in focus:
        if row['AIRCRAFT_TYPE'] not in selected_types: screening['other_type']+=1; continue
        vals={k:number(row[k]) for k in MEASURES}
        if any(v<0 for v in vals.values()): screening['negative_measure']+=1; continue
        if vals['PASSENGERS']>vals['SEATS']: screening['passengers_gt_seats']+=1; continue
        if any(vals[k]<=0 for k in ['DEPARTURES_PERFORMED','SEATS','RAMP_TO_RAMP']): screening['nonpositive_coefficient_measure']+=1; continue
        if row['ORIGIN_AIRPORT_ID']==row['DEST_AIRPORT_ID']: screening['self_route']+=1; continue
        valid.append(row)
    ids={r['AIRLINE_ID'] for r in valid}
    hub_ids={r['ORIGIN_AIRPORT_ID'] if r['ORIGIN']=='DEN' else r['DEST_AIRPORT_ID'] for r in valid}
    if len(ids)!=1 or len(hub_ids)!=1: raise ValueError('Ambiguous carrier or hub identity')
    # These are additive source fields, never row means.
    annual=collections.defaultdict(lambda:collections.Counter())
    monthly=collections.defaultdict(lambda:collections.Counter())
    names={}
    for r in valid:
        direction='out' if r['ORIGIN']=='DEN' else 'in'
        destination=r['DEST_AIRPORT_ID'] if direction=='out' else r['ORIGIN_AIRPORT_ID']
        code=r['DEST'] if direction=='out' else r['ORIGIN']
        if destination in names and names[destination]!=code: raise ValueError('Airport code changed within selected year')
        names[destination]=code
        vals={k:number(r[k]) for k in MEASURES}
        annual[(destination,r['AIRCRAFT_TYPE'],direction)].update(vals)
        monthly[(destination,number(r['MONTH']),direction)].update(vals)
    routes=[]; exclusions={}
    for destination in sorted(names,key=int):
        eligible=[t for t in protocol['scope']['types'] if all(annual[(destination,t,d)]['DEPARTURES_PERFORMED']>=12 for d in ['out','in'])]
        coverage=all(monthly[(destination,m,d)]['PASSENGERS']>0 and monthly[(destination,m,d)]['DEPARTURES_PERFORMED']>0 for m in range(1,13) for d in ['out','in'])
        if len(eligible)<2 or not coverage:
            exclusions[destination]={'destination':names[destination],'eligible_types':eligible,'all_12_months_positive_both_directions':coverage};continue
        total_dep=sum(annual[(destination,t,d)]['DEPARTURES_PERFORMED'] for t in eligible for d in ['out','in'])
        coeffs={}
        for t in eligible:
            seats=min(Fraction(annual[(destination,t,d)]['SEATS'],annual[(destination,t,d)]['DEPARTURES_PERFORMED']) for d in ['out','in'])
            block=sum(ceilfrac(Fraction(annual[(destination,t,d)]['RAMP_TO_RAMP'],annual[(destination,t,d)]['DEPARTURES_PERFORMED'])) for d in ['out','in'])
            share=Fraction(sum(annual[(destination,t,d)]['DEPARTURES_PERFORMED'] for d in ['out','in']),total_dep)
            coeffs[t]={'seats':math.floor(seats),'block_minutes':block,'share_numerator':share.numerator,'share_denominator':share.denominator}
        observations=[{'month':m,'out_passengers':monthly[(destination,m,'out')]['PASSENGERS'],'in_passengers':monthly[(destination,m,'in')]['PASSENGERS'],'out_departures':monthly[(destination,m,'out')]['DEPARTURES_PERFORMED'],'in_departures':monthly[(destination,m,'in')]['DEPARTURES_PERFORMED']} for m in range(1,13)]
        passengers=sum(o['out_passengers']+o['in_passengers'] for o in observations)
        routes.append({'id':destination,'destination':names[destination],'destination_id':destination,'annual_scoped_passengers':passengers,'coefficients':coeffs,'observations':observations})
    routes.sort(key=lambda r:(-r['annual_scoped_passengers'],int(r['id'])))
    chosen=routes[:protocol['scope']['route_count']]
    if len(chosen)!=protocol['scope']['route_count']: raise ValueError(f'Only {len(chosen)} eligible routes; protocol requires eight')
    data={'schema_version':'1.0.0','year':2025,'carrier_code':'OO','carrier_id':next(iter(ids)),'carrier_name':next(r['UNIQUE_CARRIER_NAME'] for r in valid),'hub':'DEN','hub_id':next(iter(hub_ids)),'types':[{'id':t,'label':protocol['scope']['type_labels'][t]} for t in protocol['scope']['types']],'months':list(range(1,13)),'days_by_month':{str(m):calendar.monthrange(2025,m)[1] for m in range(1,13)},'routes':chosen,'protocol_sha256':sha(ROOT/'PROTOCOL.json')}
    data_dir=ROOT/'data'; data_dir.mkdir(exist_ok=True)
    # Retain all original row values for the carrier/hub, including excluded rows, so
    # the reproducibility package can independently re-run scope and quality rules.
    if full:
        with (data_dir/'observed_segments.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=FIELDS,lineterminator='\n');writer.writeheader();writer.writerows(focus)
    data['observed_segments_sha256']=sha(data_dir/'observed_segments.csv')
    selected_pax=sum(r['annual_scoped_passengers'] for r in chosen)
    scoped_pax=sum(number(r['PASSENGERS']) for r in valid)
    focus_pax=sum(number(r['PASSENGERS']) for r in focus)
    audit={'profile_scope':'Full original BTS export' if full else 'Retained original-value carrier/hub source subset','input_rows':raw_n,'exact_duplicate_rows':duplicates,'missing_cells':missing,'year_months':{'years':years,'months':months},'carrier_hub_scheduled_passenger_rows':len(focus),'carrier_hub_aircraft_type_row_counts':dict(all_types),'screening_counts':dict(screening),'retained_positive_fixed_type_rows':len(valid),'source_focus_passengers_all_types':focus_pax,'valid_fixed_type_passengers':scoped_pax,'selected_route_passengers':selected_pax,'selected_share_of_fixed_type_passengers':selected_pax/scoped_pax,'selected_share_of_carrier_hub_passengers':selected_pax/focus_pax,'eligible_routes_count':len(routes),'selected_routes':[{'id':r['id'],'destination':r['destination'],'annual_scoped_passengers':r['annual_scoped_passengers'],'eligible_types':list(r['coefficients'])} for r in chosen],'excluded_routes':exclusions,'data_input_sha256':sha(source)}
    (data_dir/'planning_inputs.json').write_bytes((json.dumps(data,indent=2)+'\n').encode('utf-8'))
    audit_name='source_full_audit.json' if full else 'preparation_audit.json'
    (data_dir/audit_name).write_bytes((json.dumps(audit,indent=2)+'\n').encode('utf-8'))
    return data,audit

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=pathlib.Path);args=parser.parse_args()
    data,audit=prepare(args.source)
    print(json.dumps({k:audit[k] for k in ['profile_scope','input_rows','carrier_hub_scheduled_passenger_rows','retained_positive_fixed_type_rows','selected_routes','selected_share_of_carrier_hub_passengers']},indent=2))
