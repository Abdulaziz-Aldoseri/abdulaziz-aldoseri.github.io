# A minimum fleet for an aggregate service envelope

The decision is how many aircraft of each of three regional types would be required to cover a defined collection of Denver routes over twelve historical months. Integer fleet counts stay fixed across the year. Integer paired round trips can change by route, aircraft type and month.

This is an independent, retrospective 2025 capacity study using BTS records for a subset of SkyWest operations. The full year supplies both service targets and descriptive seat/block-time coefficients. It is not a forecast, acquisition decision, actual fleet inventory, optimization of the airline's complete network, or an executable timetable.

## What is decided and what is assumed

| Item | Class | Meaning |
| --- | --- | --- |
| Monthly carried passengers, performed departures, seats and ramp minutes | Observed | BTS segment aggregates, within the documented subset |
| Route/type seat and paired block-minute coefficients | Derived | Conservative rounding of directional annual weighted averages |
| Passenger multiplier | Scenario | 80%, 100% or 120% of recorded carried traffic; not latent demand |
| Minimum frequency fraction | Scenario | 50%, 75% or 100% of recorded performed departures in the busier direction |
| Daily operating envelope | Scenario | 6, 8 or 10 hours per aircraft, including the model's flying and turnaround time |
| Turnaround and unavailable capacity | Scenario | 30 minutes per leg; 10% of the envelope reserved/unavailable |
| Aircraft counts and monthly round trips | Model output | One feasible minimum-fleet allocation under these assumptions |

Let `n[t]` be integer aircraft counts fixed across months, and `x[r,t,m]` integer paired round trips. The model minimizes, in order: `sum n[t]`; annual paired round trips; annual modeled aircraft minutes. It fixes each attained objective before solving the next. Remaining ties can yield more than one fleet composition; the interface displays one solution, without claiming uniqueness.

For each route/month, allocated seats cover the larger directional passenger target and allocated round trips cover the larger directional frequency target. Only route/type pairs observed sufficiently often in both directions are allowed. For each type/month, total assigned minutes are no greater than:

`n[t] × floor(calendar days × daily operating hours × 60 × (1 − reserve fraction))`.

Each round trip consumes the sum of rounded outbound and inbound block minutes plus two turnaround allowances. Two turns are a complete-cycle accounting convention; neither turnaround times nor the 10% reserve represent observed airline values. This is a monthly pooled envelope. It does not enforce tail circulation, within-day peaks, crew rules, maintenance, runway/range certification, gate/slot feasibility, aircraft availability, leases or airline contracts.

## A credible simple comparison

The historical-share policy preserves annual eligible type shares on each route. For each route/month, it allocates an exact integer total using largest remainders: floor every `q × share`, then award remaining trips to the largest fractional remainders, with numeric type-ID ties. It searches upward from the minimum frequency until the passenger target is met. The search terminates by `max(minimum frequency, ceil(passenger target / smallest seat coefficient))`. Each type's fleet then covers its largest monthly requirement. This is a feasible heuristic with the same service targets and aircraft-minute envelopes, not the airline's actual fleet.

An optional total-fleet cap is tested separately for both policies. The optimized plan is infeasible below its proven minimum count. The historical-share policy can exceed a cap at which the optimized plan is feasible. The interface uses the evaluated scenario's exact threshold; it does not solve a new problem or interpolate between scenarios.

## Evaluation and reproducibility

The frozen 27-case grid crosses all three passenger multipliers, frequency fractions and daily-hour assumptions. Every case covers every selected route in every month; the initial view is the predefined 100% traffic, 75% frequency and 8-hour case. Month selection changes the displayed operational detail while the fleet counts still serve the full year.

SciPy/HiGHS must certify each lexicographic stage with successful termination and zero reported relative gap. All rounded integer variables and service/resource constraints are recomputed. The implementation also checks that additional hours do not increase the minimum fleet and compares small models against exhaustive enumeration. Zero-service, one-type, invalid-input, altered-source, insufficient-cap and removed-aircraft cases are checked.

Report fleet counts, total paired trips, aircraft minutes, per-month utilization, and route-level seat/frequency surplus for both policies. A smaller modeled fleet requirement is conditional on the planning envelope; it is not cost savings or proof that the actual airline could remove aircraft. Holding one year's observations fixed supports a scenario comparison, not future performance or causal impact.

`PROTOCOL.json` was frozen before optimization and revised once before fitting following independent review of baseline rounding. `MODEL_FREEZE.json` binds the final protocol, source, prepared input and model code. The notebook verifies that freeze, rebuilds preparation, reruns the full grid, and shows assignment and service diagnostics. The browser displays precomputed evaluated cases from that same output.
