"""Chronological evaluation. Run --phase validate before --phase evaluate.

Consumes only the published product/week aggregate panel and training cohort.
No customer, invoice, raw-row ledger or private career source is read.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import random
import statistics
import time
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import numpy as np

from retail_model import (POLICIES, all_policies, budget_from_history,
                          empirical_quantile, evaluate, expected_score_numerator,
                          scenario_allocate, score20)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
VARIANTS = ("primary_units", "deduplicated_units", "same_week_reversal_units", "training_p99_capped_units")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(name, value):
    OUT.mkdir(exist_ok=True)
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + "\n", encoding="utf-8")


def utc():
    return datetime.now(timezone.utc).isoformat()


def inputs():
    return {str(p.relative_to(ROOT)).replace("\\", "/"): sha(p) for p in [ROOT / "PROTOCOL.json", ROOT / "data/cohort.csv", ROOT / "data/weekly_quantities.csv"]}


def load(through=None):
    protocol = json.loads((ROOT / "PROTOCOL.json").read_text(encoding="utf-8"))
    with (ROOT / "data/cohort.csv").open(encoding="utf-8", newline="") as handle:
        cohort = sorted(csv.DictReader(handle), key=lambda r: r["StockCode"])
    products = [{"code": r["StockCode"], "name": r["description"], "segment": r["training_volume_segment"]} for r in cohort]
    codes = [r["code"] for r in products]
    if len(codes) != protocol["products"] or len(set(codes)) != len(codes):
        raise ValueError("cohort dimension or uniqueness failure")
    panel = defaultdict(dict)
    splits = {}
    with (ROOT / "data/weekly_quantities.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            week, code = row["week_start"], row["StockCode"]
            if through and week > through:
                continue
            if code in panel[week] or code not in codes:
                raise ValueError("duplicate or unexpected product/week key")
            values = [int(row[v]) for v in VARIANTS]
            if any(v < 0 for v in values):
                raise ValueError("negative weekly activity")
            panel[week][code] = values
            splits[week] = row["split"]
    weeks = sorted(panel)
    for j, week in enumerate(weeks):
        stamp = date.fromisoformat(week)
        if stamp.weekday() != 0 or (j and stamp - date.fromisoformat(weeks[j-1]) != timedelta(days=7)):
            raise ValueError("weekly panel must be contiguous complete Monday-start weeks")
        if set(panel[week]) != set(codes):
            raise ValueError("incomplete cohort panel")
        expected = next((key for key in ("train", "validation", "test") if protocol[key][0] <= week <= protocol[key][1]), None)
        if expected != splits[week]:
            raise ValueError("split disagrees with frozen protocol")
    arrays = {variant: [[panel[week][code][k] for code in codes] for week in weeks] for k, variant in enumerate(VARIANTS)}
    return protocol, products, weeks, arrays


def validate():
    protocol = json.loads((ROOT / "PROTOCOL.json").read_text(encoding="utf-8"))
    protocol, products, weeks, arrays = load(through=protocol["validation"][1])
    codes, panel = [p["code"] for p in products], arrays["primary_units"]
    validation = [j for j, week in enumerate(weeks) if protocol["validation"][0] <= week <= protocol["validation"][1]]
    if len(weeks) != 81 or len(validation) != 26:
        raise ValueError("validation requires exactly 55 train plus 26 validation weeks")
    totals, cases = {}, []
    start = time.perf_counter()
    for window in protocol["windows"]:
        total = 0
        for j in validation:
            history, actual = panel[j-window:j], panel[j]
            for factor in protocol["budget_factors"]:
                budget = budget_from_history(panel[j-8:j], factor)
                for priority in protocol["priorities"]:
                    allocation = scenario_allocate(codes, history, budget, priority)
                    score = score20(allocation, actual, priority)[0]
                    total += score
                    cases.append({"window": window, "week": weeks[j], "factor": factor, "priority": priority, "budget": budget, "score20": score})
        totals[window] = total
    selected = min(protocol["windows"], key=lambda w: (totals[w], protocol["window_tie_order"].index(w)))
    rows = [{"window": w, "mean_loss": totals[w] / (26 * 12 * 20), "sum_score20": totals[w], "settings": 312} for w in protocol["windows"]]
    frozen = {"frozen_utc": utc(), "selected_window": selected, "validation": rows, "inputs": inputs(),
              "selection": protocol["window_selection"], "test_scoring_performed": False,
              "latest_record_consumed": weeks[-1], "runtime_seconds": time.perf_counter()-start,
              "model_sha256": sha(ROOT / "retail_model.py"), "pipeline_sha256": sha(ROOT / "pipeline.py")}
    path = OUT / "validation_frozen.json"
    if path.exists():
        previous = json.loads(path.read_text(encoding="utf-8"))
        if (previous["selected_window"] != selected or previous["validation"] != rows or previous["inputs"] != inputs()
                or previous["model_sha256"] != sha(ROOT / "retail_model.py")
                or previous["pipeline_sha256"] != sha(ROOT / "pipeline.py")):
            raise ValueError("existing frozen validation differs; do not retune from test results")
        print("Existing validation freeze reproduced exactly; original timestamp retained.")
    else:
        write_json("validation_frozen.json", frozen)
    write_json("validation_cases.json", cases)
    print(json.dumps({"selected_window": selected, "validation": rows, "test_scoring_performed": False}))


def summarize(cases, observed_totals):
    grouped = defaultdict(list)
    for row in cases:
        grouped[(row["factor"], row["priority"], row["policy"])].append(row)
    summaries = []
    for (factor, priority, policy), rows in sorted(grouped.items()):
        observed = sum(observed_totals[r["week"]] for r in rows)
        summaries.append({"factor": factor, "priority": priority, "policy": policy,
                          **{"mean_" + key: statistics.mean(r[key] for r in rows) for key in ("loss", "shortfall", "leftover", "unused")},
                          "coverage": (observed-sum(r["shortfall"] for r in rows))/observed if observed else None})
    return summaries


def comparisons(cases):
    grouped = defaultdict(dict)
    for row in cases:
        grouped[(row["factor"], row["priority"], row["week"])][row["policy"]] = row
    settings = sorted(set((f, p) for f, p, _ in grouped))
    n, block, draws = 23, 4, 2000
    rng = np.random.default_rng(20260914)
    # Identical resampled week indices across comparisons improve comparability.
    starts = rng.integers(0, n-block+1, size=(draws, (n+block-1)//block))
    indices = (starts[:, :, None] + np.arange(block)).reshape(draws, -1)[:, :n]
    result = []
    for factor, priority in settings:
        keys = sorted(k for k in grouped if k[:2] == (factor, priority))
        for baseline in ("mean", "seasonal", "equal"):
            # Convert back to exact twentieth scores for paired win/tie/loss.
            diff20 = [round(20 * grouped[k]["scenario"]["loss"]) - round(20 * grouped[k][baseline]["loss"]) for k in keys]
            differences = np.array(diff20, dtype=float) / 20
            interval = np.quantile(differences[indices].mean(axis=1), [0.025, 0.975]).tolist()
            result.append({"factor": factor, "priority": priority, "baseline": baseline,
                           "mean_difference": statistics.mean(diff20)/20,
                           "median_difference": statistics.median(diff20)/20,
                           "better": sum(d < 0 for d in diff20), "tied": sum(d == 0 for d in diff20), "worse": sum(d > 0 for d in diff20),
                           "interval": interval})
    return result


def diagnostics(products, weeks, panel, test_indices, window, priorities, cases):
    forecasts, quantiles = [], []
    groups = {"all": list(range(len(products)))}
    for segment in sorted(set(p["segment"] for p in products)):
        groups[segment] = [i for i,p in enumerate(products) if p["segment"] == segment]
    for label, indices in groups.items():
        for method in ("mean", "seasonal"):
            errors, observed = [], []
            for j in test_indices:
                prediction = [sum(row[i] for row in panel[j-8:j])/8 for i in range(len(products))] if method == "mean" else panel[j-52]
                for i in indices:
                    errors.append(abs(prediction[i]-panel[j][i]))
                    observed.append(panel[j][i])
            denominator = sum(observed)
            forecasts.append({"segment": label, "method": method, "mae": statistics.mean(errors), "wape": sum(errors)/denominator if denominator else None,
                              "absolute_error_sum": sum(errors), "observed_unit_denominator": denominator, "product_weeks": len(errors), "zero_observation_cells": sum(d == 0 for d in observed)})
        for priority in priorities:
            loss, covered, cells, observed = 0, 0, 0, 0
            for j in test_indices:
                quantile = empirical_quantile(panel[j-window:j], priority)
                for i in indices:
                    loss += score20([quantile[i]], [panel[j][i]], priority)[0]
                    covered += panel[j][i] <= quantile[i]
                    cells += 1
                    observed += panel[j][i]
            quantiles.append({"segment": label, "priority": priority, "mean_pinball_loss": loss/(20*cells), "empirical_nonexceedance": covered/cells,
                              "product_weeks": cells, "observed_units": observed})
    product_rows, segment_rows = [], []
    by_week = {weeks[j]: panel[j] for j in test_indices}
    for row in cases:
        actual = by_week[row["week"]]
        for i, p in enumerate(products):
            loss20, shortfall, leftover = score20([row["allocation"][i]], [actual[i]], row["priority"])
            product_rows.append({"code": p["code"], "segment": p["segment"], "week": row["week"], "factor": row["factor"], "priority": row["priority"], "policy": row["policy"],
                                 "actual": actual[i], "allocated": row["allocation"][i], "loss": loss20/20, "shortfall": shortfall, "leftover": leftover})
    grouped = defaultdict(list)
    for row in product_rows:
        grouped[(row["segment"], row["factor"], row["priority"], row["policy"])].append(row)
    for (segment, factor, priority, policy), rows in sorted(grouped.items()):
        observed = sum(r["actual"] for r in rows)
        segment_rows.append({"segment": segment, "factor": factor, "priority": priority, "policy": policy,
                             "mean_weekly_loss": sum(r["loss"] for r in rows)/len(test_indices),
                             "mean_weekly_shortfall": sum(r["shortfall"] for r in rows)/len(test_indices),
                             "mean_weekly_leftover": sum(r["leftover"] for r in rows)/len(test_indices),
                             "coverage": (observed-sum(r["shortfall"] for r in rows))/observed if observed else None,
                             "observed_units": observed})
    product_summaries = []
    grouped = defaultdict(list)
    for row in product_rows:
        grouped[(row["code"], row["factor"], row["priority"], row["policy"])].append(row)
    for (code, factor, priority, policy), rows in sorted(grouped.items()):
        observed = sum(r["actual"] for r in rows)
        product_summaries.append({"code": code, "segment": rows[0]["segment"], "factor": factor, "priority": priority, "policy": policy,
                                  "mean_loss": statistics.mean(r["loss"] for r in rows), "mean_shortfall": statistics.mean(r["shortfall"] for r in rows),
                                  "mean_leftover": statistics.mean(r["leftover"] for r in rows), "observed_units": observed,
                                  "zero_record_weeks": sum(r["actual"] == 0 for r in rows),
                                  "coverage": (observed-sum(r["shortfall"] for r in rows))/observed if observed else None})
    return {"point_forecasts": forecasts, "unconstrained_quantiles": quantiles,
            "segments": segment_rows, "products": product_summaries,
            "definition": "MAE includes all product-week zeros; WAPE pools absolute error over positive-invoice units. Unrounded mean forecasts are evaluated. Quantile coverage is actual <= unconstrained historical quantile, not activity coverage of budget-constrained allocation."}


def fixtures():
    rng = random.Random(20260914)
    result = []
    for number in range(70):
        n = rng.randint(1, 7)
        codes = [f"P{i:02d}" for i in range(n)]
        rng.shuffle(codes)
        history = [[rng.randrange(0, 70) if rng.random() > .2 else 0 for _ in codes] for _ in range(26)]
        if number == 0:
            history = [[0] * n for _ in range(26)]
        factor = [0, .5, .75, 1, 1.25, 4][number % 6]
        budget = budget_from_history(history, factor)
        minima = [0] * n
        if budget and number % 3:
            for _ in range(min(budget, rng.randrange(budget+1))):
                minima[rng.randrange(n)] += 1
        actual = [rng.randrange(80) for _ in codes]
        seasonal = [rng.randrange(80) for _ in codes]
        priority = [.5, .8, .95][number % 3]
        window = [8, 13, 26][number % 3]
        policies = all_policies(codes, history, seasonal, actual, budget, priority, window, minima)
        result.append({"id": number, "mode": "evaluateWeek" if factor in (.5,.75,1,1.25) else "direct", "codes": codes, "history": history, "seasonal": seasonal, "actual": actual,
                       "factor": factor, "priority": priority, "window": window, "minima": minima, "budget": budget,
                       "policies": {key: {"allocation": q, **evaluate(q, actual, priority, budget, history[-window:])} for key, q in policies.items()}})
    write_json("parity_fixtures.json", {"seed": 20260914, "valid": result, "invalid": [
        {"reason": "minimum exceeds budget", "budget": 1, "minima": [2]},
        {"reason": "negative budget", "budget": -1, "minima": [0]},
        {"reason": "noninteger minimum", "budget": 1, "minima": [.5]},
        {"reason": "priority endpoint", "budget": 1, "priority": 1, "minima": [0]},
        {"reason": "priority endpoint", "budget": 1, "priority": 0, "minima": [0]},
    ]})


def run_evaluation():
    freeze_path = OUT / "validation_frozen.json"
    if not freeze_path.exists():
        raise ValueError("run --phase validate and freeze its result before test scoring")
    frozen = json.loads(freeze_path.read_text(encoding="utf-8"))
    if frozen["inputs"] != inputs():
        raise ValueError("input hashes changed after validation freeze")
    if frozen["model_sha256"] != sha(ROOT / "retail_model.py") or frozen["pipeline_sha256"] != sha(ROOT / "pipeline.py"):
        raise ValueError("model or pipeline code changed after validation freeze")
    protocol, products, weeks, arrays = load()
    if len(weeks) != 104:
        raise ValueError("expected all 104 complete weeks")
    window = frozen["selected_window"]
    codes = [p["code"] for p in products]
    test_indices = [j for j,w in enumerate(weeks) if protocol["test"][0] <= w <= protocol["test"][1]]
    if len(test_indices) != 23:
        raise ValueError("expected all 23 predeclared test weeks")
    start = time.perf_counter()
    started_utc = utc()
    all_cases, all_summaries = {}, {}
    feasibility_count, bound_checks, expected_checks = 0, 0, 0
    for variant, panel in arrays.items():
        cases = []
        for j in test_indices:
            history, seasonal, actual = panel[j-26:j], panel[j-52], panel[j]
            for factor in protocol["budget_factors"]:
                budget = budget_from_history(history, factor)
                for priority in protocol["priorities"]:
                    allocations = all_policies(codes, history, seasonal, actual, budget, priority, window)
                    bound = score20(allocations["hindsight"], actual, priority)[0]
                    expectation = expected_score_numerator(allocations["scenario"], history[-window:], priority)
                    for policy, allocation in allocations.items():
                        if len(allocation) != 30 or any(type(q) is not int or q < 0 for q in allocation) or sum(allocation) > budget:
                            raise AssertionError("integrality/nonnegativity/budget violation")
                        feasibility_count += 1
                        actual_score = score20(allocation, actual, priority)[0]
                        if actual_score < bound:
                            raise AssertionError("realized score improves on unattainable optimum")
                        bound_checks += 1
                        if expected_score_numerator(allocation, history[-window:], priority) < expectation:
                            raise AssertionError("forecast objective improves on exact scenario optimum")
                        expected_checks += 1
                        cases.append({"week": weeks[j], "factor": factor, "priority": priority, "budget": budget, "policy": policy,
                                      "allocation": allocation, **evaluate(allocation, actual, priority, budget, history[-window:])})
        all_cases[variant] = cases
        all_summaries[variant] = summarize(cases, {weeks[j]: sum(panel[j]) for j in test_indices})
    primary = all_cases["primary_units"]
    pairings = comparisons(primary)
    sensitivities = []
    for variant in VARIANTS[1:]:
        for row in all_summaries[variant]:
            sensitivities.append({"variant": variant, **{k:v for k,v in row.items() if k != "mean_unused"}})
    panel = arrays["primary_units"]
    public = {"meta": {"selected_window": window, "default_week": protocol["default_week"], "default_factor": protocol["default_factor"],
                       "default_priority": protocol["default_priority"], "budget_factors": protocol["budget_factors"], "priorities": protocol["priorities"],
                       "test_weeks": 23, "test_actual_units": sum(sum(panel[j]) for j in test_indices),
                       "bootstrap": {"seed": 20260914, "block_weeks": 4, "draws": 2000, "method": "noncircular moving blocks, sampled uniformly with replacement; concatenate and truncate to 23; shared resampling indices for all comparisons", "interval": "2.5th and 97.5th percentiles of paired mean differences; descriptive"},
                       "expected_loss": "All policies scored on the same selected past-week distribution, including the hindsight allocation.",
                       "sensitivity": "Each variant changes historical and evaluation targets together, recomputes its own past-only budget and baselines, retains the primary cohort and selected window; no test retuning."},
              "products": products, "weeks": [{"week": weeks[j], "actual": panel[j], "history": panel[j-26:j], "seasonal": panel[j-52]} for j in test_indices],
              "validation": [{"window": r["window"], "mean_loss": r["mean_loss"]} for r in frozen["validation"]],
              "summaries": all_summaries["primary_units"], "comparisons": pairings, "sensitivities": sensitivities}
    write_json("public_index.json", public)
    write_json("evaluated_cases.json", primary)
    write_json("sensitivity_cases.json", [{"variant": variant, **row} for variant in VARIANTS[1:] for row in all_cases[variant]])
    write_json("diagnostics.json", diagnostics(products, weeks, panel, test_indices, window, protocol["priorities"], primary))
    fixtures()
    verification = {"status": "PASS", "test_scoring_started_utc": started_utc, "validation_frozen_utc": frozen["frozen_utc"],
                    "validation_frozen_sha256": sha(freeze_path), "selected_window": window,
                    "variants": len(VARIANTS), "weeks_per_variant": 23, "settings_per_week": 12, "policies": list(POLICIES),
                    "evaluated_allocations": feasibility_count, "integrality_nonnegativity_budget_checks": feasibility_count,
                    "unattainable_bound_checks": bound_checks, "exact_expected_optimum_checks": expected_checks,
                    "primary_cases": len(primary), "sensitivity_cases": sum(len(all_cases[v]) for v in VARIANTS[1:]),
                    "test_products_never_observed": [products[i]["code"] for i in range(30) if all(panel[j][i] == 0 for j in test_indices)],
                    "runtime_seconds": time.perf_counter()-start,
                    "inputs": inputs(), "model_sha256": sha(ROOT / "retail_model.py"), "pipeline_sha256": sha(ROOT / "pipeline.py"),
                    "runtime": {"python": platform.python_version(), "numpy": np.__version__},
                    "numerical_solver": "Exact integer CDF-segment algorithm; no floating solver gap. Independent SciPy MILP verification is recorded separately by tests."}
    write_json("evaluation_verification.json", verification)
    write_results(public, verification)
    print(json.dumps({"selected_window": window, "evaluated_allocations": feasibility_count, "default_setting": [r for r in public["summaries"] if r["factor"] == 1 and r["priority"] == .8], "runtime_seconds": verification["runtime_seconds"]}))


def write_results(public, verification):
    default = [r for r in public["summaries"] if r["factor"] == 1 and r["priority"] == .8]
    comparisons_default = [r for r in public["comparisons"] if r["factor"] == 1 and r["priority"] == .8]
    lines = ["# Retail allocation — executed results", "", "Independent historical study; hypothetical unit budget and priorities. Results concern gross positive invoice activity from UK customers of an unnamed retailer, not latent demand, fulfilled orders, achieved service, monetary savings or deployment.", "",
             f"Validation selected **{public['meta']['selected_window']} prior weeks** by minimum equal-setting mean loss across 26 validation weeks × 12 settings. Selection was written to validation_frozen.json before any test score was computed. No test retuning was performed.", "",
             "| Window | Validation mean weighted-unit loss |", "| --- | ---: |"]
    lines += [f"| {r['window']} | {r['mean_loss']:.4f} |" for r in public["validation"]]
    lines += ["", "## Default setting: budget factor 1.0, shortfall priority 0.8", "", "All 23 test weeks are retained. These priorities weight one unit of shortfall four times one unit left over. Compare scores only within the same setting. Coverage is pooled recorded-activity coverage across 266,056 positive units.", "",
              "| Policy | Mean loss | Mean shortfall | Mean leftover | Mean unused budget | Recorded-activity coverage |",
              "| --- | ---: | ---: | ---: | ---: | ---: |"]
    lines += [f"| {r['policy']} | {r['mean_loss']:.2f} | {r['mean_shortfall']:.2f} | {r['mean_leftover']:.2f} | {r['mean_unused']:.2f} | {100*r['coverage']:.2f}% |" for r in default]
    lines += ["", "| Scenario minus baseline | Mean difference | Median difference | Better / tied / worse weeks | Descriptive block interval |", "| --- | ---: | ---: | --- | --- |"]
    lines += [f"| {r['baseline']} | {r['mean_difference']:.2f} | {r['median_difference']:.2f} | {r['better']} / {r['tied']} / {r['worse']} | [{r['interval'][0]:.2f}, {r['interval'][1]:.2f}] |" for r in comparisons_default]
    lines += ["", "Negative differences favour the scenario allocation. Intervals use 2,000 seeded, noncircular four-week moving-block resamples from only 23 paired weeks; they are descriptive dependence sensitivity, not population guarantees. Perfect-information allocations use the actual week and are unattainable when planning.", "",
              "## Complete evidence", "", "- public_index.json contains all 60 primary policy-setting summaries, 36 paired baseline comparisons and 180 sensitivity summaries.",
              "- evaluated_cases.json contains every primary week/setting/policy allocation and score; sensitivity_cases.json retains all three modified targets.",
              "- diagnostics.json contains unrounded mean and seasonal forecast MAE/WAPE, unconstrained empirical-quantile pinball loss and nonexceedance, fixed training-volume segments and all product-level scores. Zeros remain in denominators for MAE; WAPE and activity coverage are undefined (null) if recorded units sum to zero.",
              "- parity_fixtures.json adds 70 independently seeded small/protected browser-reconciliation cases, including zero and ample budgets.", "",
              "Each sensitivity modifies both historical and evaluated activity, recomputes that variant's past-only budget and baselines, and retains the primary cohort and selected window. Duplicate/reversal changes are alternative record treatments; the training-line cap changes the target. Their levels do not share the primary outcome definition and must not be read as causal improvements.", "",
              f"All {verification['evaluated_allocations']:,} primary and sensitivity allocations passed integer, nonnegative, budget, exact empirical-objective and unattainable-bound checks. The exact algorithm has no floating optimization gap. Independent tiny-case enumeration and SciPy MILP parity are recorded in tests_verification.json.", "",
              "## Limits", "", "One historical retailer, 30 training-selected products and 23 test weeks cannot establish general retail performance. Product 84270 remains despite zero recorded test activity. Zero history can suppress a data-only allocation; observed zeros do not establish zero latent demand or a stockout. The aggregate unit resource treats all product units equally; size, margin, lead time, carry-over, inventory, capacity and availability are unobserved. Lambda is a preference, not an estimated economic cost. Historical invoice availability by week-end is assumed, not verified by data vintages. The separable expected objective uses marginal distributions; retaining weekly vectors does not establish an optimization benefit from correlations.", "",
              "Source: Chen, D. (2012), Online Retail II, UCI Machine Learning Repository, https://doi.org/10.24432/C5CG6D, CC BY 4.0. Derived product/week aggregates and model outputs by Abdulaziz Aldoseri. No endorsement implied.", ""]
    (ROOT / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("validate", "evaluate"), required=True)
    args = parser.parse_args()
    validate() if args.phase == "validate" else run_evaluation()
