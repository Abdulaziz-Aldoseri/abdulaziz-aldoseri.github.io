"""Frozen, auditable Online Retail II preparation; no forecasting or optimization.

Run with the bundled Python (pandas/openpyxl), without downloading anything.
The retained official workbook is opened read-only and never rewritten.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
from pathlib import Path
import platform

import numpy as np
import openpyxl
import pandas as pd

ROOT = Path(__file__).resolve().parent
PLANNING = ROOT.parents[1] / "website/design/project_planning/retail"
DATA = ROOT / "data"
RAW_COLUMNS = ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "Customer ID", "Country"]
TRAIN_START, TRAIN_END = pd.Timestamp("2009-12-07"), pd.Timestamp("2010-12-20")
VAL_START, VAL_END = pd.Timestamp("2010-12-27"), pd.Timestamp("2011-06-20")
TEST_START, TEST_END = pd.Timestamp("2011-06-27"), pd.Timestamp("2011-11-28")
CAP_QUANTILE = 0.99  # Frozen before evaluation: integer nearest-rank training positive-line quantile.

# Frozen reviewed source expectations; no external private audit is needed.
FROZEN_SOURCE = {'title': 'Online Retail II', 'creator': 'Daqing Chen', 'publisher': 'UCI Machine Learning Repository', 'source_company': 'Unnamed UK-based non-store giftware retailer; do not invent its identity.', 'citation': 'Chen, D. (2012). Online Retail II [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5CG6D.', 'landing_page': 'https://archive.ics.uci.edu/dataset/502/online+retail+ii', 'doi': 'https://doi.org/10.24432/C5CG6D', 'resource_url': 'https://archive.ics.uci.edu/static/public/502/online%2Bretail%2Bii.zip', 'licence': 'CC BY 4.0', 'licence_url': 'https://creativecommons.org/licenses/by/4.0/', 'credit_requirement': 'Credit creator and source; link licence; indicate transformations; do not imply endorsement.', 'citation_year': 2012, 'landing_page_donated_date': '2019-09-20', 'version': 'No release identifier supplied; exact SHA-256 snapshot below.', 'retrieved_utc': '2026-09-14T12:02:49.3291755Z', 'geographic_scope': 'UK-based retailer, customer countries worldwide; proposed analysis restricts Customer Country to United Kingdom.', 'coverage': {'Year 2009-2010': {'start': '2009-12-01T07:45:00', 'end': '2010-12-09T20:01:00', 'rows': 525461}, 'Year 2010-2011': {'start': '2010-12-01T08:26:00', 'end': '2011-12-09T12:50:00', 'rows': 541910}}, 'observation': 'Invoice line, not an order, person, inventory snapshot or unmet-demand record.', 'units': {'Quantity': 'Units per invoice line; includes negative adjustments/cancellations', 'Price': 'GBP per unit as supplied; not cost/margin', 'InvoiceDate': 'Naive local-looking date/time; time zone unspecified by source'}, 'profile_script': 'profile_retail.py', 'profile_results': 'inspection_results.json', 'files': [{'path': 'source/online_retail_ii.zip', 'bytes': 45622418, 'sha256': '572e36277c2390fbfde10664750731e0a86f55e33470d91919085f0408e67bfb'}, {'path': 'source/online_retail_II.xlsx', 'bytes': 45622278, 'sha256': 'bcbe73b35f5b7babf197fb0cb983a11f5d9ff929078d4aa53d171b1f2df2e980'}, {'path': 'source/uci_landing.html', 'bytes': 85207, 'sha256': '4a0e63a112fece5b846a778eed0d572d5f857f6aea043366b7c3e3089d98f8ac', 'snapshot_saved_utc': '2026-09-14T12:05:25.913380+00:00'}, {'path': 'source/cc_by_4_deed.html', 'bytes': 32178, 'sha256': '231a5dac65bbf135ba27145969a63cd289faadc172f1512c4810a6c60ba91036', 'snapshot_saved_utc': '2026-09-14T12:05:24.352278+00:00'}], 'inspection_scope': 'Both complete workbook sheets; candidate scope profile does not fit models.', 'missing_operational_fields': ['Inventory/on-hand', 'stockout or rejected-request observations', 'supplier lead times', 'purchase cost or margin', 'physical product dimensions', 'staff hours and service times', 'price intervention or promotion records']}
FROZEN_EXPECTED = {'sheet_profiles': {'Year 2009-2010': {'rows': 525461}, 'Year 2010-2011': {'rows': 541910}}, 'unified': {'rows': 1044848, 'duplicate_extra_rows_all_eight_fields': 11812}, 'overlap': {'first_sheet_rows': 22523, 'second_sheet_rows': 22523, 'exact_matching_rows_accounting_for_multiplicity': 22523, 'first_sheet_rows_removed_by_precedence': 22523}, 'candidate_scope': {'funnel': {'start_rows': 1044848, 'UK_customer_country': {'excluded_here': 84865, 'remaining': 959983}, 'positive_quantity': {'excluded_here': 19741, 'remaining': 940242}, 'positive_price': {'excluded_here': 2609, 'remaining': 937633}, 'not_cancellation_invoice': {'excluded_here': 1, 'remaining': 937632}, 'description_present': {'excluded_here': 0, 'remaining': 937632}, 'standard_merchandise_code_pattern': {'excluded_here': 2605, 'remaining': 935027}}, 'distinct_stock_codes': 4866, 'duplicate_extra_rows_all_eight_fields': 11584, 'eligible_training_skus_at_least_26_active_weeks': 1780, 'selected_training_stats': [{'StockCode': '85123A', 'total_quantity': 53419, 'active_weeks': 54, 'distinct_invoices': 3185}, {'StockCode': '84077', 'total_quantity': 52004, 'active_weeks': 54, 'distinct_invoices': 485}, {'StockCode': '17003', 'total_quantity': 48129, 'active_weeks': 50, 'distinct_invoices': 225}, {'StockCode': '21212', 'total_quantity': 47961, 'active_weeks': 54, 'distinct_invoices': 1621}, {'StockCode': '85099B', 'total_quantity': 44417, 'active_weeks': 54, 'distinct_invoices': 1836}, {'StockCode': '84879', 'total_quantity': 41006, 'active_weeks': 54, 'distinct_invoices': 1334}, {'StockCode': '22197', 'total_quantity': 30976, 'active_weeks': 54, 'distinct_invoices': 961}, {'StockCode': '84991', 'total_quantity': 28231, 'active_weeks': 54, 'distinct_invoices': 1212}, {'StockCode': '21977', 'total_quantity': 26348, 'active_weeks': 54, 'distinct_invoices': 1045}, {'StockCode': '21232', 'total_quantity': 24845, 'active_weeks': 54, 'distinct_invoices': 1528}, {'StockCode': '21982', 'total_quantity': 24554, 'active_weeks': 44, 'distinct_invoices': 376}, {'StockCode': '21213', 'total_quantity': 23029, 'active_weeks': 54, 'distinct_invoices': 774}, {'StockCode': '84755', 'total_quantity': 22275, 'active_weeks': 54, 'distinct_invoices': 632}, {'StockCode': '84347', 'total_quantity': 22153, 'active_weeks': 34, 'distinct_invoices': 329}, {'StockCode': '84270', 'total_quantity': 21732, 'active_weeks': 50, 'distinct_invoices': 437}, {'StockCode': '84568', 'total_quantity': 20659, 'active_weeks': 48, 'distinct_invoices': 156}, {'StockCode': '84946', 'total_quantity': 18826, 'active_weeks': 54, 'distinct_invoices': 903}, {'StockCode': '85099F', 'total_quantity': 18754, 'active_weeks': 54, 'distinct_invoices': 1003}, {'StockCode': '21980', 'total_quantity': 18700, 'active_weeks': 53, 'distinct_invoices': 343}, {'StockCode': '15036', 'total_quantity': 18542, 'active_weeks': 52, 'distinct_invoices': 470}, {'StockCode': '71459', 'total_quantity': 17980, 'active_weeks': 53, 'distinct_invoices': 551}, {'StockCode': '84992', 'total_quantity': 17847, 'active_weeks': 54, 'distinct_invoices': 803}, {'StockCode': '20725', 'total_quantity': 17549, 'active_weeks': 54, 'distinct_invoices': 1406}, {'StockCode': '16014', 'total_quantity': 17015, 'active_weeks': 30, 'distinct_invoices': 42}, {'StockCode': '21984', 'total_quantity': 16761, 'active_weeks': 51, 'distinct_invoices': 214}, {'StockCode': '22178', 'total_quantity': 16760, 'active_weeks': 54, 'distinct_invoices': 811}, {'StockCode': '85099C', 'total_quantity': 16642, 'active_weeks': 54, 'distinct_invoices': 940}, {'StockCode': '22386', 'total_quantity': 16275, 'active_weeks': 48, 'distinct_invoices': 1011}, {'StockCode': '84598', 'total_quantity': 15961, 'active_weeks': 47, 'distinct_invoices': 117}, {'StockCode': '22086', 'total_quantity': 15863, 'active_weeks': 42, 'distinct_invoices': 914}], 'selected_validation_rows': 9454, 'selected_test_rows': 10972, 'selected_zero_record_test_skus': ['84270']}}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_value(value):
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(v) for v in value]
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, np.generic):
        return value.item()
    return value


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(json_value(value), indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    # Fixed compression timestamp makes reruns byte reproducible.
    compression = {"method": "gzip", "mtime": 0} if str(path).endswith(".gz") else None
    frame.to_csv(path, index=False, encoding="utf-8", lineterminator="\n", compression=compression)


def with_week(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    frame["week_start"] = frame.InvoiceDate.dt.to_period("W-SUN").dt.start_time
    return frame


def split_label(weeks: pd.Series) -> pd.Series:
    result = pd.Series("outside_complete_weeks", index=weeks.index, dtype="str")
    for label, start, end in [("train", TRAIN_START, TRAIN_END), ("validation", VAL_START, VAL_END), ("test", TEST_START, TEST_END)]:
        result.loc[weeks.between(start, end)] = label
    return result


def overlap_precedence(first: pd.DataFrame, second: pd.DataFrame):
    """Second sheet wins its whole timestamp range; repeats inside it stay."""
    start, end = second.InvoiceDate.min(), first.InvoiceDate.max()
    a, b = first[first.InvoiceDate >= start], second[second.InvoiceDate <= end]
    ha = pd.util.hash_pandas_object(a[RAW_COLUMNS].astype(str), index=False).value_counts()
    hb = pd.util.hash_pandas_object(b[RAW_COLUMNS].astype(str), index=False).value_counts()
    matches = int(pd.concat([ha, hb], axis=1).fillna(0).min(axis=1).sum())
    first = first.copy()
    second = second.copy()
    first["source_sheet"], second["source_sheet"] = "Year 2009-2010", "Year 2010-2011"
    first["source_row"] = np.arange(len(first)) + 2
    second["source_row"] = np.arange(len(second)) + 2
    removed = first[first.InvoiceDate >= start].copy()
    unified = pd.concat([first[first.InvoiceDate < start], second], ignore_index=True)
    unified["line_id"] = np.arange(len(unified))
    return unified, removed, {
        "start": start, "end": end, "first_sheet_rows": len(a), "second_sheet_rows": len(b),
        "exact_matching_rows_accounting_for_multiplicity": matches,
        "first_sheet_rows_removed_by_precedence": len(removed),
        "rule": "Keep second sheet from its first timestamp onward; keep earlier first-sheet timestamps.",
    }


def filter_primary(unified: pd.DataFrame):
    """Ordered, disjoint first-exclusion ledger; matches the reviewed source audit."""
    code = unified.StockCode.astype(str).str.strip()
    conditions = {
        "UK_customer_country": unified.Country.eq("United Kingdom"),
        "positive_quantity": unified.Quantity.gt(0),
        "positive_price": unified.Price.gt(0),
        "not_cancellation_invoice": ~unified.Invoice.astype(str).str.upper().str.startswith("C"),
        "description_present": unified.Description.notna(),
        "standard_merchandise_code_pattern": code.str.fullmatch(r"\d{5}[A-Za-z]*"),
    }
    mask = pd.Series(True, index=unified.index)
    reason = pd.Series("retained_primary", index=unified.index, dtype="str")
    funnel = {"start_rows": len(unified)}
    for name, valid in conditions.items():
        excluded = mask & ~valid
        reason.loc[excluded] = name
        old = int(mask.sum())
        mask &= valid
        funnel[name] = {"excluded_here": old - int(mask.sum()), "remaining": int(mask.sum())}
    primary = unified.loc[mask].copy()
    primary["StockCode"] = code.loc[mask]
    primary = with_week(primary)
    ledger = unified[["line_id", "source_sheet", "source_row"]].copy()
    ledger["first_exclusion_or_retention"] = reason
    return primary, ledger, funnel


def freeze_cohort(primary: pd.DataFrame, size: int = 30, minimum_active_weeks: int = 26):
    train = primary.loc[primary.week_start.between(TRAIN_START, TRAIN_END)].copy()
    stats = train.groupby("StockCode").agg(
        total_quantity=("Quantity", "sum"), active_weeks=("week_start", "nunique"),
        distinct_invoices=("Invoice", "nunique"))
    eligible = stats.loc[stats.active_weeks.ge(minimum_active_weeks)].reset_index().sort_values(
        ["total_quantity", "distinct_invoices", "StockCode"], ascending=[False, False, True])
    cohort = eligible.head(size).copy().reset_index(drop=True)
    cohort.insert(0, "training_rank", np.arange(len(cohort)) + 1)
    descriptions, caps = {}, {}
    for code in cohort.StockCode:
        rows = train.loc[train.StockCode.eq(code)]
        counts = rows.Description.astype(str).str.strip().value_counts()
        descriptions[code] = sorted(counts.loc[counts.eq(counts.max())].index)[0]
        quantities = np.sort(rows.Quantity.to_numpy(dtype=np.int64))
        caps[code] = int(quantities[math.ceil(CAP_QUANTILE * len(quantities)) - 1])
    cohort["description"] = cohort.StockCode.map(descriptions)
    cohort["training_line_cap_p99"] = cohort.StockCode.map(caps).astype("int64")
    # Relative volume is defined among the fixed cohort, solely from training rank.
    cohort["training_volume_segment"] = np.where(cohort.training_rank.le(math.ceil(len(cohort) / 2)), "higher_volume_half", "lower_volume_half")
    return cohort, len(eligible)


def reversal_matches(unified: pd.DataFrame, primary: pd.DataFrame):
    """Conservative one-to-one edges in the same-week chronological match graph.

    Keys are normalized product, exact customer, exact supplied price and absolute
    quantity. A cancellation must be strictly later. Degree >1 on either endpoint
    is ambiguous; do not greedily allocate or retry after removing an edge.
    Missing customers cannot match. Negative non-C adjustments are only audited.
    """
    work = with_week(unified)
    work["StockCode"] = work.StockCode.astype(str).str.strip()
    is_c = work.Invoice.astype(str).str.upper().str.startswith("C")
    audit = work.loc[is_c | work.Quantity.lt(0)].copy()
    audit["status"] = "eligible_unmatched"
    checks = [
        (is_c.loc[audit.index], "negative_adjustment_without_C_prefix"),
        (audit.Quantity.lt(0), "C_prefix_nonnegative_quantity"),
        (audit.Country.eq("United Kingdom"), "outside_UK_customer_market"),
        (audit.Price.gt(0), "nonpositive_price"),
        (audit.StockCode.str.fullmatch(r"\d{5}[A-Za-z]*"), "nonmerchandise_code"),
        (audit["Customer ID"].notna(), "missing_customer_cannot_match"),
    ]
    for condition, reason in checks:
        audit.loc[audit.status.eq("eligible_unmatched") & ~condition, "status"] = reason
    candidates = audit.loc[audit.status.eq("eligible_unmatched")]
    keys = ["week_start", "StockCode", "Customer ID", "Price", "Quantity"]
    positives = defaultdict(list)
    for row in primary.loc[primary["Customer ID"].notna(), [*keys, "InvoiceDate", "line_id"]].itertuples(index=False, name=None):
        positives[row[:5]].append((row[5], int(row[6])))
    cancel_edges = {}
    positive_degree = Counter()
    for row in candidates[[*keys, "InvoiceDate", "line_id"]].itertuples(index=False, name=None):
        key = (*row[:4], -row[4])
        edges = [pid for timestamp, pid in positives.get(key, []) if timestamp < row[5]]
        cid = int(row[6])
        cancel_edges[cid] = edges
        positive_degree.update(edges)
    matches = []
    status_by_id = {}
    for cid, edges in cancel_edges.items():
        if not edges:
            status_by_id[cid] = "no_eligible_preceding_positive_in_same_week"
        elif len(edges) != 1 or positive_degree[edges[0]] != 1:
            status_by_id[cid] = "ambiguous_pairing_left_unmatched"
        else:
            status_by_id[cid] = "unique_same_week_match"
            matches.append({"positive_line_id": edges[0], "cancellation_line_id": cid})
    audit["status"] = audit.line_id.map(status_by_id).fillna(audit.status)
    pair_frame = pd.DataFrame(matches, columns=["positive_line_id", "cancellation_line_id"])
    if len(pair_frame):
        pos = primary.set_index("line_id")
        cancel = audit.set_index("line_id")
        for column in ["StockCode", "Quantity", "week_start", "InvoiceDate"]:
            pair_frame["positive_" + column] = pair_frame.positive_line_id.map(pos[column])
        pair_frame["cancellation_InvoiceDate"] = pair_frame.cancellation_line_id.map(cancel.InvoiceDate)
    return pair_frame, audit


def weekly_panel(primary: pd.DataFrame, cohort: pd.DataFrame, pairs: pd.DataFrame) -> pd.DataFrame:
    codes = sorted(cohort.StockCode)
    weeks = pd.date_range(TRAIN_START, TEST_END, freq="W-MON")
    grid = pd.MultiIndex.from_product([weeks, codes], names=["week_start", "StockCode"])
    selected = primary.loc[primary.StockCode.isin(codes)].copy()
    in_window = selected.week_start.between(TRAIN_START, TEST_END)
    selected = selected.loc[in_window]
    variants = {
        "primary_units": selected,
        "deduplicated_units": selected.drop_duplicates(RAW_COLUMNS),
        "same_week_reversal_units": selected.loc[~selected.line_id.isin(pairs.positive_line_id)],
    }
    capped = selected.copy()
    cap = capped.StockCode.map(cohort.set_index("StockCode").training_line_cap_p99)
    capped["Quantity"] = np.minimum(capped.Quantity, cap).astype("int64")
    variants["training_p99_capped_units"] = capped
    panel = pd.DataFrame(index=grid)
    for name, rows in variants.items():
        panel[name] = rows.groupby(["week_start", "StockCode"]).Quantity.sum().reindex(grid, fill_value=0).astype("int64")
    panel = panel.reset_index()
    panel.insert(1, "split", split_label(panel.week_start))
    assert len(panel) == 104 * len(cohort)
    assert panel.groupby("split").week_start.nunique().to_dict() == {"test": 23, "train": 55, "validation": 26}
    for name in variants:
        assert panel[name].ge(0).all()
        assert panel[name].le(panel.primary_units).all()
    return panel


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path, help="Official unchanged UCI XLSX; omitting uses the retained local planning source.")
    parser.add_argument("--output-dir", type=Path, default=DATA, help="Derived-output directory (default: data beside this script).")
    parser.add_argument("--public-only", action="store_true", help="Write aggregates and aggregate provenance only; no source-line/customer/invoice audit exports.")
    args = parser.parse_args(argv)
    output = args.output_dir.resolve()
    if args.public_only and (output / "private").exists():
        parser.error("Public-only output must not contain a pre-existing private audit directory; choose a separate --output-dir.")
    output.mkdir(parents=True, exist_ok=True)
    if not args.public_only:
        (output / "private").mkdir(exist_ok=True)
    original_manifest = FROZEN_SOURCE
    expected = FROZEN_EXPECTED
    workbook_path = args.workbook.resolve() if args.workbook else PLANNING / "source/online_retail_II.xlsx"
    source_entries = [item for item in original_manifest["files"] if item["path"].endswith(".xlsx")] if args.workbook else original_manifest["files"]
    source_files = []
    verified_paths = []
    for item in source_entries:
        path = workbook_path if item["path"].endswith(".xlsx") else PLANNING / item["path"]
        assert path.stat().st_size == item["bytes"], path
        assert sha(path) == item["sha256"], path
        source_files.append({**item, "path": path.name})
        verified_paths.append((path, item["sha256"]))
    print("Reading retained workbook, without modifying it", flush=True)
    frames = pd.read_excel(workbook_path, sheet_name=None, engine="openpyxl")
    assert list(frames) == ["Year 2009-2010", "Year 2010-2011"]
    for name, frame in frames.items():
        assert list(frame.columns) == RAW_COLUMNS
        assert len(frame) == expected["sheet_profiles"][name]["rows"]
        assert frame.Quantity.mod(1).eq(0).all()
    unified, overlap_removed, overlap = overlap_precedence(*frames.values())
    assert len(unified) == expected["unified"]["rows"]
    assert unified.duplicated(RAW_COLUMNS).sum() == expected["unified"]["duplicate_extra_rows_all_eight_fields"]
    for key in ["first_sheet_rows", "second_sheet_rows", "exact_matching_rows_accounting_for_multiplicity", "first_sheet_rows_removed_by_precedence"]:
        assert overlap[key] == expected["overlap"][key]
    primary, row_ledger, funnel = filter_primary(unified)
    assert funnel == expected["candidate_scope"]["funnel"]
    assert primary.StockCode.nunique() == expected["candidate_scope"]["distinct_stock_codes"]
    assert int(primary.duplicated(RAW_COLUMNS).sum()) == expected["candidate_scope"]["duplicate_extra_rows_all_eight_fields"]
    cohort, eligible_count = freeze_cohort(primary)
    assert eligible_count == expected["candidate_scope"]["eligible_training_skus_at_least_26_active_weeks"]
    assert cohort[["StockCode", "total_quantity", "active_weeks", "distinct_invoices"]].to_dict("records") == expected["candidate_scope"]["selected_training_stats"]
    selected = primary.loc[primary.StockCode.isin(cohort.StockCode)].copy()
    selected["split"] = split_label(selected.week_start)
    assert int(selected.split.eq("validation").sum()) == expected["candidate_scope"]["selected_validation_rows"]
    assert int(selected.split.eq("test").sum()) == expected["candidate_scope"]["selected_test_rows"]
    zero_test = sorted(set(cohort.StockCode) - set(selected.loc[selected.split.eq("test"), "StockCode"]))
    assert zero_test == expected["candidate_scope"]["selected_zero_record_test_skus"]
    print("Source, ordered ledger and frozen cohort match the complete-file profile", flush=True)
    pairs, cancellations = reversal_matches(unified, primary)
    panel = weekly_panel(primary, cohort, pairs)
    for variant in ["primary_units", "deduplicated_units", "same_week_reversal_units", "training_p99_capped_units"]:
        assert panel[variant].dtype == "int64"
    excluded = unified.loc[~unified.StockCode.astype(str).str.strip().str.fullmatch(r"\d{5}[A-Za-z]*")].copy()
    excluded["StockCode"] = excluded.StockCode.astype(str)  # Preserve raw spelling/whitespace for audit.
    excluded_pairs = excluded.groupby(["StockCode", "Description"], dropna=False).agg(
        source_lines=("Quantity", "size"), signed_quantity=("Quantity", "sum")).reset_index()
    write_csv(panel, output / "weekly_quantities.csv")
    write_csv(cohort, output / "cohort.csv")
    # Only these two aggregate files are eligible for later public packaging.
    if not args.public_only:
        write_csv(row_ledger, output / "private/row_filter_ledger.csv.gz")
        write_csv(overlap_removed[["source_sheet", "source_row", "InvoiceDate"]], output / "private/overlap_removed_rows.csv.gz")
        write_csv(selected, output / "private/selected_positive_lines.csv.gz")
        write_csv(cancellations, output / "private/cancellation_audit.csv.gz")
        write_csv(pairs, output / "private/same_week_reversal_pairs.csv.gz")
        write_csv(excluded_pairs, output / "private/excluded_code_description_pairs.csv")
    summary = {
        "status": "Prepared and internally checked; independent adversarial review required before model fitting.",
        "preparation_version": "retail-preparation-v1", "no_model_fitting_or_evaluation": True,
        "source_hashes_verified": True, "source_profile_counts_verified": True,
        "overlap": overlap, "ordered_filter_ledger": funnel,
        "primary_rows": len(primary), "primary_products": int(primary.StockCode.nunique()),
        "primary_exact_repeat_extra_lines": int(primary.duplicated(RAW_COLUMNS).sum()),
        "eligible_training_products": eligible_count, "selected_products": len(cohort),
        "selected_lines_by_split": selected.groupby("split").size().to_dict(),
        "weekly_rows": len(panel), "weeks_by_split": panel.groupby("split").week_start.nunique().to_dict(),
        "selected_zero_record_test_products": zero_test,
        "full_cohort_zero_record_weeks": panel.groupby("week_start").primary_units.sum().loc[lambda x: x.eq(0)].index.strftime("%Y-%m-%d").tolist(),
        "cancellation_and_negative_adjustment_lines": len(cancellations),
        "cancellation_status_counts": cancellations.status.value_counts().to_dict(),
        "unique_same_week_pairs_all_products_all_dates": len(pairs),
        "unique_same_week_pairs_cohort_complete_weeks": int(pairs.positive_line_id.isin(selected.loc[selected.split.ne("outside_complete_weeks"), "line_id"]).sum()),
        "excluded_nonmerchandise_code_description_pairs": len(excluded_pairs),
        "aggregate_units_by_split_and_variant": panel.groupby("split")[["primary_units", "deduplicated_units", "same_week_reversal_units", "training_p99_capped_units"]].sum().to_dict("index"),
        "extreme_rule": {"quantile": CAP_QUANTILE, "estimator": "nearest rank: sorted positive training-line quantities at ceil(0.99*n)-1", "scope": "each fixed product independently; training complete weeks only", "frozen_before_model_evaluation": True, "primary_changed": False},
        "description_rule": "Most frequent stripped description by training line count; lexical tie; never inspect future descriptions for selection.",
        "public_output_allowlist": ["data/weekly_quantities.csv", "data/cohort.csv"],
        "privacy": "All row-level ledgers, customer/invoice fields and uncurated description-pair audits stay under data/private and must never enter public source.",
    }
    summary["private_audits_exported"] = not args.public_only
    write_json(output / "preparation_summary.json", summary)
    for path, expected_sha in verified_paths:
        assert sha(path) == expected_sha, "Source changed during preparation"
    manifest_path = ROOT / "source_manifest.json" if output == DATA.resolve() else output / "source_manifest.json"
    outputs = []
    generated_files = [output / name for name in ["weekly_quantities.csv", "cohort.csv", "preparation_summary.json"]]
    if not args.public_only:
        generated_files += [output / "private" / name for name in ["row_filter_ledger.csv.gz", "overlap_removed_rows.csv.gz", "selected_positive_lines.csv.gz", "cancellation_audit.csv.gz", "same_week_reversal_pairs.csv.gz", "excluded_code_description_pairs.csv"]]
    for path in generated_files:
        outputs.append({"path": path.relative_to(manifest_path.parent).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path), "public_eligible": path.name in {"weekly_quantities.csv", "cohort.csv"}})
    write_json(manifest_path, {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "citation": original_manifest["citation"], "landing_page": original_manifest["landing_page"],
        "licence": original_manifest["licence"], "licence_url": original_manifest["licence_url"],
        "retrieved_utc": original_manifest["retrieved_utc"], "resource_url": original_manifest["resource_url"],
        "transformations": "Sheet-overlap precedence; ordered UK positive merchandise filters; training-only cohort/labels/caps; Monday aggregation; separately labelled duplicate/reversal/extreme sensitivities.",
        "source_files": source_files, "outputs": outputs,
        "script_sha256": sha(Path(__file__)), "runtime": {"python": platform.python_version(), "pandas": pd.__version__, "openpyxl": openpyxl.__version__, "numpy": np.__version__},
    })
    print(json.dumps(json_value(summary), indent=2), flush=True)


if __name__ == "__main__":
    main()
