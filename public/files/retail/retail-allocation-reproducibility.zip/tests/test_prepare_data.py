"""Small adversarial preparation cases; standard-library unittest."""
import importlib.util
from pathlib import Path
import unittest

import pandas as pd

spec = importlib.util.spec_from_file_location("prepare_data", Path(__file__).resolve().parents[1] / "prepare_data.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


def lines(rows):
    result = []
    for index, override in enumerate(rows):
        row = dict(zip(p.RAW_COLUMNS, [str(100 + index), "12345", "PRODUCT", 5, pd.Timestamp("2010-01-04 09:00"), 1.0, 1.0, "United Kingdom"]))
        row.update(override)
        result.append(row)
    frame = pd.DataFrame(result)
    frame["InvoiceDate"] = pd.to_datetime(frame.InvoiceDate, format="mixed")
    frame["line_id"] = range(len(frame))
    frame["source_sheet"] = "test"
    frame["source_row"] = range(2, len(frame) + 2)
    return frame


class PreparationTests(unittest.TestCase):
    def test_overlap_precedence_preserves_multiplicity(self):
        first = lines([{"InvoiceDate": "2009-12-01"}, {"InvoiceDate": "2010-12-01"}, {"InvoiceDate": "2010-12-01", "Invoice": "101"}])[p.RAW_COLUMNS]
        second = first.iloc[1:].copy()
        merged, removed, report = p.overlap_precedence(first, second)
        self.assertEqual(len(merged), 3)
        self.assertEqual(len(removed), 2)
        self.assertEqual(report["exact_matching_rows_accounting_for_multiplicity"], 2)
        self.assertEqual(merged.duplicated(p.RAW_COLUMNS).sum(), 1)

    def test_ordered_filters_missing_customer_case_and_space(self):
        frame = lines([
            {"Country": "France", "Quantity": -5},
            {"Quantity": -5, "Price": 0},
            {"Price": 0}, {"Invoice": "C123", "Quantity": 1},
            {"Description": None}, {"StockCode": "M"},
            {"StockCode": "12345a ", "Customer ID": None},
            {"StockCode": "12345A"},
        ])
        primary, ledger, funnel = p.filter_primary(frame)
        self.assertEqual(list(primary.StockCode), ["12345a", "12345A"])
        self.assertEqual(ledger.first_exclusion_or_retention.iloc[:6].tolist(), list(funnel)[1:])
        self.assertEqual(funnel["standard_merchandise_code_pattern"]["remaining"], 2)

    def test_monday_boundary_and_partial_week_exclusion(self):
        frame = p.with_week(lines([{"InvoiceDate": "2009-12-06 23:59"}, {"InvoiceDate": "2009-12-07"}, {"InvoiceDate": "2011-12-04 23:59"}, {"InvoiceDate": "2011-12-05"}]))
        self.assertEqual(p.split_label(frame.week_start).tolist(), ["outside_complete_weeks", "train", "test", "outside_complete_weeks"])
        self.assertTrue(frame.week_start.dt.weekday.eq(0).all())

    def test_cohort_descriptions_caps_and_rank_ignore_future(self):
        frame = p.with_week(lines([
            {"StockCode": "12345", "Description": "B", "Quantity": 5},
            {"StockCode": "12345", "Description": "A", "Quantity": 5},
            {"StockCode": "12346", "Quantity": 9},
            {"StockCode": "12346", "Quantity": 999999, "Description": "FUTURE", "InvoiceDate": "2011-07-04"},
            {"StockCode": "12345", "Quantity": 999999, "Description": "FUTURE", "InvoiceDate": "2011-07-04"},
        ]))
        cohort, _ = p.freeze_cohort(frame, size=2, minimum_active_weeks=1)
        earlier, _ = p.freeze_cohort(frame.loc[frame.InvoiceDate.lt("2011-01-01")], size=2, minimum_active_weeks=1)
        pd.testing.assert_frame_equal(cohort, earlier)
        self.assertEqual(cohort.StockCode.tolist(), ["12345", "12346"])
        self.assertEqual(cohort.description.iloc[0], "A")
        self.assertEqual(cohort.training_line_cap_p99.tolist(), [5, 9])

    def matches(self, rows):
        unified = lines(rows)
        primary, _, _ = p.filter_primary(unified)
        return p.reversal_matches(unified, primary)

    def test_reversal_unique_and_strictly_after(self):
        pairs, audit = self.matches([{}, {"Invoice": "C1", "Quantity": -5, "InvoiceDate": "2010-01-04 09:01"}])
        self.assertEqual(pairs.positive_line_id.tolist(), [0])
        self.assertEqual(audit.status.tolist(), ["unique_same_week_match"])
        pairs, _ = self.matches([{}, {"Invoice": "C1", "Quantity": -5}])
        self.assertEqual(len(pairs), 0)

    def test_reversal_does_not_backdate_or_match_partial_quantities(self):
        pairs, audit = self.matches([{}, {"Invoice": "C1", "Quantity": -5, "InvoiceDate": "2010-01-11"}, {"Invoice": "C2", "Quantity": -4, "InvoiceDate": "2010-01-05"}])
        self.assertEqual(len(pairs), 0)
        self.assertTrue(audit.status.eq("no_eligible_preceding_positive_in_same_week").all())

    def test_reversal_ambiguous_positive_or_cancellation_stays_unmatched(self):
        for rows in [
            [{}, {}, {"Invoice": "C1", "Quantity": -5, "InvoiceDate": "2010-01-05"}],
            [{}, {"Invoice": "C1", "Quantity": -5, "InvoiceDate": "2010-01-05"}, {"Invoice": "C2", "Quantity": -5, "InvoiceDate": "2010-01-06"}],
        ]:
            pairs, audit = self.matches(rows)
            self.assertEqual(len(pairs), 0)
            self.assertTrue(audit.status.eq("ambiguous_pairing_left_unmatched").all())

    def test_reversal_missing_customer_wrong_price_and_non_C_adjustment(self):
        pairs, audit = self.matches([
            {"Customer ID": None}, {"Invoice": "C1", "Quantity": -5, "Customer ID": None, "InvoiceDate": "2010-01-05"},
            {}, {"Invoice": "C2", "Quantity": -5, "Price": 2, "InvoiceDate": "2010-01-05"},
            {"Quantity": -5, "InvoiceDate": "2010-01-05"},
        ])
        self.assertEqual(len(pairs), 0)
        self.assertEqual(set(audit.status), {"missing_customer_cannot_match", "no_eligible_preceding_positive_in_same_week", "negative_adjustment_without_C_prefix"})

    def test_weekly_grid_retains_missing_product_zero_and_sensitivity_separation(self):
        frame = lines([{"Invoice": "100"}, {"Invoice": "100"}, {"Invoice": "C1", "Quantity": -5, "InvoiceDate": "2010-01-05"}])
        primary, _, _ = p.filter_primary(frame)
        cohort = pd.DataFrame({"StockCode": ["12345", "54321"], "training_line_cap_p99": [3, 3]})
        pairs, _ = p.reversal_matches(frame, primary)
        panel = p.weekly_panel(primary, cohort, pairs)
        self.assertEqual(len(panel), 208)
        self.assertEqual(panel.primary_units.sum(), 10)
        self.assertEqual(panel.deduplicated_units.sum(), 5)
        self.assertEqual(panel.same_week_reversal_units.sum(), 10)  # Ambiguous duplicates remain.
        self.assertEqual(panel.training_p99_capped_units.sum(), 6)
        self.assertEqual(panel.loc[panel.StockCode.eq("54321"), "primary_units"].sum(), 0)


if __name__ == "__main__":
    unittest.main()
