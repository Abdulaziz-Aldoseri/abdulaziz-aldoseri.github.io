"""Independent enumeration and SciPy MILP checks; no source-data fitting."""
import itertools
import json
import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from retail_model import (all_policies, budget_from_history, empirical_quantile,
                          equal_allocate, evaluate, expected_score_numerator,
                          half_up, mean_targets, proportional_allocate,
                          scenario_allocate, score20)


def brute(codes, history, budget, priority, minima):
    order = sorted(range(len(codes)), key=lambda i: codes[i])
    candidates = (q for q in itertools.product(*(range(m, budget+1) for m in minima)) if sum(q) <= budget)
    return list(min(candidates, key=lambda q: (expected_score_numerator(q, history, priority), sum(q), tuple(-q[i] for i in order))))


def independent_milp(history, budget, priority, minima):
    """Explicit q / scenario shortfall / scenario leftover MILP, two solves."""
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import lil_matrix, vstack, csr_matrix
    w, n = len(history), len(minima)
    size = n + 2*w*n
    c = np.zeros(size)
    c[n:n+w*n] = priority/w
    c[n+w*n:] = (1-priority)/w
    a = lil_matrix((1+2*w*n, size))
    a[0,:n] = 1
    lower = np.full(1+2*w*n, -np.inf)
    upper = np.full(1+2*w*n, np.inf)
    upper[0] = budget
    for s, row in enumerate(history):
        for i, d in enumerate(row):
            k = s*n+i
            a[1+2*k,i] = 1
            a[1+2*k,n+k] = 1
            lower[1+2*k] = d
            a[2+2*k,i] = -1
            a[2+2*k,n+w*n+k] = 1
            lower[2+2*k] = -d
    bounds = Bounds(np.array(minima+[0]*(2*w*n)), np.array([budget]*n+[np.inf]*(2*w*n)))
    integral = np.array([1]*n+[0]*(2*w*n))
    a = a.tocsr()
    result = milp(c, integrality=integral, bounds=bounds, constraints=LinearConstraint(a, lower, upper), options={"mip_rel_gap":0})
    if not result.success:
        raise AssertionError(result.message)
    allocation = np.rint(result.x[:n]).astype(int).tolist()
    second_c = np.array([1]*n+[0]*(2*w*n))
    second = milp(second_c, integrality=integral, bounds=bounds,
                  constraints=LinearConstraint(vstack([a, csr_matrix(c.reshape(1,-1))]), np.append(lower,-np.inf), np.append(upper,result.fun+1e-7)),
                  options={"mip_rel_gap":0})
    if not second.success:
        raise AssertionError(second.message)
    return allocation, round(sum(second.x[:n])), float(result.mip_gap)


class RetailModelTests(unittest.TestCase):
    def test_half_up_exact_and_shared_budget(self):
        self.assertEqual([half_up(n,2) for n in range(6)], [0,1,1,2,2,3])
        history = [[1,1]]*8
        # Aggregate unrounded means before rounding, not sum rounded scaled targets.
        self.assertEqual(budget_from_history(history,.75), 2)
        self.assertEqual(mean_targets([[0,1]]*4+[[1,2]]*4), [1,2])

    def test_ties_and_zero_marginal_unused(self):
        self.assertEqual(scenario_allocate(["B","A"], [[10,10]],3,.8), [0,3])
        self.assertEqual(scenario_allocate(["A"],[[0],[10]],10,.5),[0])
        self.assertEqual(empirical_quantile([[0],[10]],.5),[0])

    def test_minima_and_ample_budget(self):
        history = [[1,3],[2,4]]
        self.assertEqual(scenario_allocate(["A","B"],history,100,.8,[9,0]),[9,4])
        self.assertEqual(scenario_allocate(["A","B"],history,5,.8,[5,0]),[5,0])
        self.assertEqual(scenario_allocate(["A","B"],[[0,0]],0,.8),[0,0])

    def test_proportional_largest_remainder(self):
        self.assertEqual(proportional_allocate(["B","A"],[10,10],3),[1,2])
        self.assertEqual(proportional_allocate(["A","B"],[1,10],7,[5,0]),[5,2])
        self.assertEqual(proportional_allocate(["A","B"],[1,2],10,[0,0]),[1,2])

    def test_equal_waterfill_final_allocations(self):
        self.assertEqual(equal_allocate(["A","B","C"],[0,10,10],10,[8,0,0]),[8,1,1])
        self.assertEqual(equal_allocate(["C","A","B"],[10,10,10],5),[1,2,2])
        self.assertEqual(equal_allocate(["A","B"],[0,3],100),[2,1])

    def test_invalid_inputs(self):
        for budget, minima, priority in [(-1,[0],.8),(1,[2],.8),(1,[.5],.8),(1,[0],0),(1,[0],1),(1.5,[0],.8)]:
            with self.subTest(budget=budget,minima=minima,priority=priority):
                with self.assertRaises(ValueError):
                    scenario_allocate(["A"],[[1]],budget,priority,minima)
        for history in ([],[[-1]],[[.5]],[[1,2]]):
            with self.assertRaises(ValueError):
                scenario_allocate(["A"],history,1,.8)
        with self.assertRaises(ValueError):
            scenario_allocate(["A","A"],[[1,2]],2,.8)
        with self.assertRaises(ValueError):
            budget_from_history([[1]]*7,1)

    def test_scoring_zero_denominator_and_common_expectation(self):
        self.assertEqual(evaluate([0],[0],.8,10,[[1]])["coverage"],None)
        self.assertEqual(evaluate([5],[3],.8,10,[[1]])["expected_loss"],.8)
        self.assertEqual(score20([4,1],[2,5],.8),(72,4,2))

    def test_brute_force_random_full_tie_rule(self):
        rng = random.Random(90210)
        for case in range(160):
            n, w, budget = rng.randint(1,4), rng.randint(1,6), rng.randint(0,8)
            codes = [chr(65+i) for i in range(n)]
            rng.shuffle(codes)
            history = [[rng.randrange(7) for _ in range(n)] for _ in range(w)]
            minima = [0]*n
            for _ in range(rng.randrange(budget+1)):
                minima[rng.randrange(n)] += 1
            priority = rng.choice([.5,.8,.95])
            with self.subTest(case=case):
                self.assertEqual(scenario_allocate(codes,history,budget,priority,minima),brute(codes,history,budget,priority,minima))

    def test_independent_milp_random_and_edges(self):
        rng = random.Random(8881)
        for case in range(64):
            n, w = rng.randint(1,6), rng.randint(1,8)
            budget = [0,3,50,500][case%4]
            history = [[rng.randrange(40) if rng.random()>.3 else 0 for _ in range(n)] for _ in range(w)]
            if case == 0:
                history = [[0]*n for _ in range(w)]
            minima = [0]*n
            for _ in range(rng.randrange(min(40,budget)+1)):
                minima[rng.randrange(n)] += 1
            priority = [.5,.8,.95][case%3]
            q = scenario_allocate([str(i) for i in range(n)],history,budget,priority,minima)
            other, minimum_total, gap = independent_milp(history,budget,priority,minima)
            with self.subTest(case=case):
                self.assertEqual(expected_score_numerator(q,history,priority),expected_score_numerator(other,history,priority))
                self.assertEqual(sum(q),minimum_total)
                self.assertEqual(gap,0)

    def test_all_policy_feasibility_and_hindsight_bound(self):
        rng = random.Random(13)
        for case in range(80):
            codes = ["A","B","C"]
            history = [[rng.randrange(30) for _ in codes] for _ in range(26)]
            actual, seasonal = [rng.randrange(30) for _ in codes], [rng.randrange(30) for _ in codes]
            budget = rng.randrange(100)
            minima = [0,0,0]
            for _ in range(rng.randrange(budget+1)):
                minima[rng.randrange(3)] += 1
            policies = all_policies(codes,history,seasonal,actual,budget,.8,13,minima)
            bound = score20(policies["hindsight"],actual,.8)[0]
            for allocation in policies.values():
                self.assertLessEqual(sum(allocation),budget)
                self.assertTrue(all(q>=m and type(q) is int for q,m in zip(allocation,minima)))
                self.assertGreaterEqual(score20(allocation,actual,.8)[0],bound)


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RetailModelTests))
    import scipy
    record = {"status": "PASS" if result.wasSuccessful() else "FAIL", "tests": result.testsRun,
              "failures": len(result.failures), "errors": len(result.errors),
              "brute_force_cases":160,"independent_milp_cases":64,"milp_solves":128,
              "protected_all_policy_feasibility_cases":80,"scipy":scipy.__version__,
              "milp_check":"Exact expected-loss numerator equality and minimum-total equality; every MILP primary solve gap zero. Tertiary StockCode tie rule checked by exhaustive enumeration."}
    (ROOT/"outputs").mkdir(exist_ok=True)
    (ROOT/"outputs/tests_verification.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    sys.exit(not result.wasSuccessful())
