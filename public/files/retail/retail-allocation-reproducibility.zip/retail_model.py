"""Exact, dependency-free integer allocation for historical retail activity.

Quantities and budgets are nonnegative integers. A priority is a twentieth in
(0, 1); the predeclared study uses 0.5, 0.8 and 0.95. Product codes determine
ties independently of the order in which products are supplied.
"""
from __future__ import annotations

from bisect import bisect_right
from fractions import Fraction
from numbers import Integral

POLICIES = ("scenario", "mean", "seasonal", "equal", "hindsight")


def integer(value, label="quantity"):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
        raise ValueError(f"{label} must be a nonnegative integer")
    return int(value)


def priority_numerator(priority):
    value = Fraction(str(priority)) * 20
    if value.denominator != 1 or not 0 < value < 20:
        raise ValueError("priority must be an exact twentieth strictly between zero and one")
    return int(value)


def half_up(numerator, denominator=1):
    numerator = integer(numerator, "rounding numerator")
    denominator = integer(denominator, "rounding denominator")
    if denominator == 0:
        raise ValueError("rounding denominator must be positive")
    return (2 * numerator + denominator) // (2 * denominator)


def checked_inputs(codes, budget, minima=None):
    codes = list(codes)
    if not codes or any(not isinstance(c, str) or not c for c in codes) or len(set(codes)) != len(codes):
        raise ValueError("nonempty unique product codes are required")
    budget = integer(budget, "budget")
    minima = [0] * len(codes) if minima is None else list(minima)
    if len(minima) != len(codes):
        raise ValueError("minimum vector must match product dimension")
    minima = [integer(v, "minimum") for v in minima]
    if sum(minima) > budget:
        raise ValueError("infeasible protection: total minimum exceeds the budget")
    return codes, budget, minima


def checked_history(history, n):
    history = [list(row) for row in history]
    if not history or any(len(row) != n for row in history):
        raise ValueError("nonempty history must match product dimension")
    return [[integer(v) for v in row] for row in history]


def budget_from_history(history, factor=1):
    """Factor times the sum of unrounded last-eight-week means, half-up."""
    rows = list(history)
    if len(rows) < 8:
        raise ValueError("budget requires eight completed history weeks")
    rows = checked_history(rows[-8:], len(rows[-1]))
    ratio = Fraction(str(factor))
    if ratio < 0:
        raise ValueError("budget factor must be nonnegative")
    return half_up(sum(map(sum, rows)) * ratio.numerator, 8 * ratio.denominator)


def mean_targets(history):
    rows = list(history)
    if len(rows) < 8:
        raise ValueError("mean rule requires eight completed history weeks")
    rows = checked_history(rows[-8:], len(rows[-1]))
    return [half_up(sum(col), 8) for col in zip(*rows)]


def scenario_allocate(codes, history, budget, priority, minima=None):
    """Optimize expected weighted mismatch using exact positive CDF segments.

    The marginal improvement from q to q+1 is a/20 - count(d<=q)/W.
    Each product's segment benefits are nonincreasing. Sorting all segments
    therefore respects precedence and solves the separable integer problem.
    Zero benefits are not allocated, giving the minimum-total optimum.
    """
    codes, budget, allocation = checked_inputs(codes, budget, minima)
    history = checked_history(history, len(codes))
    a, w = priority_numerator(priority), len(history)
    segments = []
    for i, column in enumerate(zip(*history)):
        observed = sorted(column)
        q = allocation[i]
        for end in sorted(set(v for v in observed if v > q)):
            score = a * w - 20 * bisect_right(observed, q)
            if score <= 0:
                break
            segments.append((-score, codes[i], i, end - q))
            q = end
    remaining = budget - sum(allocation)
    for _, _, i, length in sorted(segments):
        take = min(remaining, length)
        allocation[i] += take
        remaining -= take
        if remaining == 0:
            break
    return allocation


def proportional_allocate(codes, targets, budget, minima=None):
    """Raise targets to minima, then proportionally ration unmet targets."""
    codes, budget, minima = checked_inputs(codes, budget, minima)
    if len(targets) != len(codes):
        raise ValueError("target vector must match product dimension")
    targets = [max(m, integer(t, "target")) for m, t in zip(minima, targets)]
    if sum(targets) <= budget:
        return targets
    unmet = [t - m for t, m in zip(targets, minima)]
    remaining, total = budget - sum(minima), sum(unmet)
    allocation = [m + remaining * u // total for m, u in zip(minima, unmet)]
    residual = budget - sum(allocation)
    order = sorted(range(len(codes)), key=lambda i: (-(remaining * unmet[i] % total), codes[i]))
    for i in order[:residual]:
        allocation[i] += 1
    return allocation


def equal_allocate(codes, targets, budget, minima=None):
    """Max-min water-fill final allocations, without individual target caps."""
    codes, budget, minima = checked_inputs(codes, budget, minima)
    if len(targets) != len(codes):
        raise ValueError("target vector must match product dimension")
    target_total = sum(max(m, integer(t, "target")) for m, t in zip(minima, targets))
    total = min(budget, target_total)
    low, high = 0, total + 1
    while low + 1 < high:
        level = (low + high) // 2
        if sum(max(m, level) for m in minima) <= total:
            low = level
        else:
            high = level
    allocation = [max(m, low) for m in minima]
    remaining = total - sum(allocation)
    eligible = sorted((i for i, m in enumerate(minima) if m <= low), key=lambda i: codes[i])
    for i in eligible[:remaining]:
        allocation[i] += 1
    return allocation


def all_policies(codes, history, seasonal, actual, budget, priority, window, minima=None):
    rows = list(history)
    window = integer(window, "window")
    if window == 0 or len(rows) < window:
        raise ValueError("not enough complete history for the requested window")
    checked_history([seasonal, actual], len(codes))
    targets = mean_targets(rows)
    return {
        "scenario": scenario_allocate(codes, rows[-window:], budget, priority, minima),
        "mean": proportional_allocate(codes, targets, budget, minima),
        "seasonal": proportional_allocate(codes, seasonal, budget, minima),
        "equal": equal_allocate(codes, targets, budget, minima),
        "hindsight": scenario_allocate(codes, [actual], budget, priority, minima),
    }


def score20(allocation, actual, priority):
    """Return exact weighted-loss numerator, shortfall and leftovers."""
    if not allocation or len(allocation) != len(actual):
        raise ValueError("allocation and actual vectors must have the same nonzero dimension")
    allocation, actual = checked_history([allocation, actual], len(allocation))
    shortfall = sum(max(d - q, 0) for q, d in zip(allocation, actual))
    leftover = sum(max(q - d, 0) for q, d in zip(allocation, actual))
    a = priority_numerator(priority)
    return a * shortfall + (20 - a) * leftover, shortfall, leftover


def expected_score_numerator(allocation, history, priority):
    return sum(score20(allocation, row, priority)[0] for row in history)


def evaluate(allocation, actual, priority, budget, history):
    score, shortfall, leftover = score20(allocation, actual, priority)
    if sum(allocation) > integer(budget, "budget"):
        raise ValueError("allocation exceeds budget")
    history = checked_history(history, len(allocation))
    observed = sum(actual)
    return {
        "loss": score / 20,
        "shortfall": shortfall,
        "leftover": leftover,
        "coverage": (observed - shortfall) / observed if observed else None,
        "unused": budget - sum(allocation),
        # Same forecast distribution for all policies, including hindsight.
        "expected_loss": expected_score_numerator(allocation, history, priority) / (20 * len(history)),
    }


def empirical_quantile(history, priority):
    rows = list(history)
    rows = checked_history(rows, len(rows[0]) if rows else 0)
    a, w = priority_numerator(priority), len(rows)
    rank = (a * w + 19) // 20
    return [sorted(col)[rank - 1] for col in zip(*rows)]
