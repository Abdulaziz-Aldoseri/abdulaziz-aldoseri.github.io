# Retail allocation under uncertain recorded activity

Independent historical decision study by Abdulaziz Aldoseri. Choose integer quantities for 30 products under a hypothetical weekly unit budget, then compare scenario-based allocation with mean, seasonal and equal-allocation policies. Optional product protection uses the same budget. This is a normalized experiment against **gross positive invoice activity**, not a reconstruction of inventory, fulfilled demand, lost sales or real replenishment economics.

## Open the notebook

Open `retail_allocation.ipynb` from the extracted reproduction folder. The notebook defines the problem, controls and evidence limits, runs the actual model for a selected week, and checks all 23 held-out weeks at the selected budget factor and priority against the packaged summaries. Default: week beginning 4 July 2011, factor 1.0, priority 0.8, no protection. The default was chosen before evaluation.

Local setup does not install anything or access the network. Use a Python notebook kernel with `numpy==2.3.5`, `scipy==1.16.3`, `pandas==3.0.1` and `openpyxl==3.1.5`; the dependency-free allocation engine itself only needs Python. The local reproduction environment used Python 3.12. Notebook software supplies its usual display/kernel packages.

For optional Colab use, upload the notebook and run its setup cells. Select the reproduction ZIP when prompted. An embedded standard-library helper validates member paths, sizes and manifest hashes before importing project code, then installs the four pinned requirements. It does not mount Drive. It refuses traversal, symlinks, duplicate/case-colliding paths, private/raw-workbook entries, unmanifested files and nonempty extraction destinations. Every original notebook byte is verified during extraction. Later runtime checks allow edits and saved outputs in working `.ipynb` files while continuing to hash-check modules, data and requirements. Manifest checks verify integrity, not publisher identity; use the study's download link and published archive checksum when available. **Hosted Colab execution has not been verified.** Local sequential cell checks and ZIP setup tests are the evidence available here.

## Reproduce the evidence

- Read `PROTOCOL.json` for the frozen experimental choices and `METHODS.md` for the model and interpretation.
- `retail_model.py` implements exact separable integer allocation and every comparison rule.
- `data/weekly_quantities.csv` contains 104 complete Monday weeks × 30 products, with the primary target and three independent preparation sensitivities. Read `StockCode` as a string.
- `data/cohort.csv` contains training-selected products, descriptions, volume segments and extreme-order caps.
- `outputs/public_index.json` contains the histories, actual observations, frozen window and full-period result summaries used in the notebook and study page.
- `outputs/evaluated_cases.json`, when included, records the full unprotected week/factor/priority/policy comparison matrix.
- Run `python -m unittest discover -s tests -v` for the included model/preparation/setup checks. The complete pipeline runs in two phases: `python pipeline.py --phase validate`, then `python pipeline.py --phase evaluate`. The notebook does not automatically invoke them. Preserve the supplied frozen result files; the pipeline's existing-file guards prevent replacing frozen choices silently.

The scenario window is selected from 8, 13 and 26 weeks using validation only. Training covers 55 weeks, validation 26 and test 23. Each test forecast uses only preceding completed weeks. Results retain zero-activity products, worse weeks and the unattainable perfect-information reference. Protection interactions are separate from the unprotected full-period evidence. Scores use weighted units, and coverage describes recorded activity rather than measured customer service.

## Source, licence and transformations

Chen, D. (2012). [Online Retail II](https://archive.ics.uci.edu/dataset/502/online+retail+ii) [Dataset]. UCI Machine Learning Repository. [DOI 10.24432/C5CG6D](https://doi.org/10.24432/C5CG6D). Data licensed [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/); no endorsement is implied. The data licence does not itself license project code. The underlying company is unnamed: a UK giftware retailer whose recorded customer activity spans 2009–2011.

Changes: second-sheet precedence over the exact source overlap; ordered UK-customer, positive-quantity, positive-price, non-cancellation, available-description and merchandise-code-proxy filters; training-only cohort, labels and caps; Monday aggregation. Primary quantities retain exact repeated source lines. Separately labelled sensitivities collapse repeats, remove only uniquely matchable same-week reversals, or cap lines at a training-defined 99th percentile. Missing customer IDs do not cause positive activity to be dropped. None of these rules reconstructs fulfilled demand.

The reproduction package contains aggregate data and no raw workbook, invoice/customer-level records or private audit directory. Obtain the official workbook separately from UCI if needed, then run:

```bash
python prepare_data.py --workbook /path/to/online_retail_II.xlsx --output-dir /path/to/aggregate-output --public-only
```

The script embeds the reviewed source hash and preparation expectations, so no external private audit is required. Original XLSX SHA-256: `bcbe73b35f5b7babf197fb0cb983a11f5d9ff929078d4aa53d171b1f2df2e980`. It opens the source read-only and verifies its hash before and after. A zero aggregate means no recorded positive invoice activity; it does not establish zero latent demand or explain missing records.

Only one historical company and 23 held-out weeks are studied. Inventory availability, lost demand, product dimensions, acquisition cost, margins and lead times are absent. Budgets and priorities are hypothetical; there is no claim of operational deployment, financial savings, causal sales gains or current-market advice.
