# Retail allocation — method and interpretation

Independent study by Abdulaziz Aldoseri, 2026. This historical experiment allocates a hypothetical total count of units across 30 products. Its target is gross positive invoice activity from UK customers of an unnamed retailer in 2009–2011. It does not reconstruct inventory, fulfilled demand, lost sales, replenishment economics or commercial impact.

## Source and preparation

Chen, D. (2012). Online Retail II [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5CG6D. Dataset: https://archive.ics.uci.edu/dataset/502/online+retail+ii. Licence: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. No endorsement is implied. Changes: overlap precedence, UK-customer/positive merchandise-proxy filters, training-only product selection and weekly aggregation.

The original two sheets contain 1,067,371 invoice lines. The second sheet takes precedence over the matching 22,523-line overlap, leaving 1,044,848 rows. Ordered filters keep UK customer country, positive quantity, positive price, non-cancellation invoices, a description and a five-digit product code with optional alphabetic suffix. Keys are trimmed without changing case. The code pattern is a merchandise proxy; excluded codes are not all certified administrative records. The resulting primary subset has 935,027 lines across 4,866 codes. Missing customer IDs do not exclude positive activity.

Training weeks alone select 30 products: at least 26 active weeks, ranked by positive units, invoice count and lexical StockCode. Training also fixes product descriptions, high/low volume halves and the per-product nearest-rank 99th-percentile positive-line cap. The whole 104-week by 30-product panel is preserved; no recorded product-week activity means zero in the proxy. Product 84270 remains despite no positive test-period activity.

Primary activity retains exact repeated invoice lines. Three separate sensitivities collapse exact repeats; subtract only uniquely matched same-week positive/cancellation pairs; or cap positive line quantities using the training-only threshold. The reversal heuristic requires an earlier positive line with the same product, nonmissing customer, price and absolute quantity, uniquely paired in both directions. Ambiguous pairs, later-week cancellations and non-C adjustments remain unmatched. No cancellation is assumed to represent physical stock returned. Sensitivities change the target definition and are reported separately without changing the primary cohort or selecting another window from test outcomes.

Only product/week aggregates are distributed with the website. Original data remain available from UCI; row-level ledgers stay private. Exact raw workbook SHA-256: bcbe73b35f5b7babf197fb0cb983a11f5d9ff929078d4aa53d171b1f2df2e980.

## Decision and exact objective

At each Monday choose integer q_i >= m_i >= 0, with sum(q_i) <= B. Past complete weekly product vectors d_is receive equal scenario weight. Minimize the mean over scenarios of sum_i[lambda*max(d_is-q_i,0)+(1-lambda)*max(q_i-d_is,0)]. B is a unit-count scenario; lambda is a preference, not a cost or service target. Every policy sees identical B and minima.

The chosen priorities lambda=0.5,0.8,0.95 give shortfall-to-leftover weights 1:1,4:1,19:1. Scores are weighted units and must be compared at the same lambda. The additive objective depends on marginal product distributions, even though complete weekly vectors are retained; no extra benefit from cross-product correlation is claimed.

For current integer q_i, the next unit has expected improvement lambda-F_i(q_i). With lambda=a/20 and W equal-weight weeks, rank exact integer scores a*W-20*count(d_is<=q_i). Allocate positive-benefit CDF segments in descending score and ascending StockCode order until budget is exhausted or no positive benefit remains. Zero-benefit units stay unused. This minimizes expected loss, then total allocated units, with a fixed code-order tie rule. No expected-loss superiority implies superiority against later observations.

## Baselines and parameters

The budget is half-up rounded factor times the sum of unrounded trailing-eight-week mean quantities. Factors are 0.5,0.75,1.0,1.25. The budget is fixed independently of policy, scenario window, priority and protection.

The mean rule targets half-up rounded eight-week averages. The seasonal rule targets activity 364 days earlier. Both raise targets to any minimum; if targets fit, surplus budget stays unused. Otherwise reserve minima and allocate remaining units proportional to unmet targets using integer floors, descending remainder and StockCode ties. The equal rule uses S=min(B,sum(mean-rule targets)) units and max-min water-fills final allocations from minima, with code-order ties. It has no individual mean-target caps. The perfect-information reference optimizes with the actual week known in advance; that information is unavailable when planning.

A minimum exceeding B is infeasible. A protected-product interaction keeps B fixed and applies the minimum to every policy. It may consume unused budget instead of displacing other products; report actual changes. Whole-period evidence refers to zero minima unless expressly recomputed.

## Chronology and evaluation

Training: 55 complete weeks beginning 7 December 2009 through 20 December 2010. Validation: 26 weeks beginning 27 December 2010 through 20 June 2011. Test: 23 weeks beginning 27 June through 28 November 2011, ending 4 December. Partial boundary weeks are excluded. Records are assumed available by week-end; the source is not a vintage-certified operational backtest.

Choose a single history window from 8,13,26 weeks by mean evaluated loss across all 26 validation weeks, four factors and three priorities, weighting settings equally. Exact ties prefer 13,8,26. Freeze the selected window before test scoring. Rolling updates may use completed prior test weeks, without changing the selected method. Default week is 4 July 2011, factor1.0, priority0.8, fixed before evaluation.

Evaluate every test week and retain worse results. Report shortfall, leftover allocation, unused budget, weighted mismatch and recorded-activity coverage. Coverage is sum(min(q_i,d_i))/sum(d_i); zero denominator is undefined. It is not achieved fill rate. Forecast MAE includes zeros; WAPE pools the observed-unit denominator and is undefined when that denominator is zero. Quantile diagnostics refer to unconstrained empirical quantiles, not resource-constrained allocations.

Paired weekly comparisons include mean, median and better/tied/worse counts. A fixed-seed four-week moving-block resampling interval is a descriptive sensitivity across this short sequence, not a population guarantee or evidence of general commercial superiority. Numerical checks and actual results are recorded with the executed release.
