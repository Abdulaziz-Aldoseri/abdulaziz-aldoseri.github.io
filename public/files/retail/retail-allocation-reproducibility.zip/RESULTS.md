# Retail allocation — executed results

Independent historical study; hypothetical unit budget and priorities. Results concern gross positive invoice activity from UK customers of an unnamed retailer, not latent demand, fulfilled orders, achieved service, monetary savings or deployment.

Validation selected **26 prior weeks** by minimum equal-setting mean loss across 26 validation weeks × 12 settings. Selection was written to validation_frozen.json before any test score was computed. No test retuning was performed.

| Window | Validation mean weighted-unit loss |
| --- | ---: |
| 8 | 3488.0216 |
| 13 | 3480.3806 |
| 26 | 3478.2617 |

## Default setting: budget factor 1.0, shortfall priority 0.8

All 23 test weeks are retained. These priorities weight one unit of shortfall four times one unit left over. Compare scores only within the same setting. Coverage is pooled recorded-activity coverage across 266,056 positive units.

| Policy | Mean loss | Mean shortfall | Mean leftover | Mean unused budget | Recorded-activity coverage |
| --- | ---: | ---: | ---: | ---: | ---: |
| equal | 5078.53 | 5286.61 | 4246.22 | 0.04 | 54.30% |
| hindsight | 1438.57 | 1798.22 | 0.00 | 757.87 | 84.45% |
| mean | 3829.01 | 4037.09 | 2996.70 | 0.04 | 65.10% |
| scenario | 3958.58 | 4166.65 | 3126.30 | 0.00 | 63.98% |
| seasonal | 4968.16 | 5180.48 | 4118.87 | 21.26 | 55.22% |

| Scenario minus baseline | Mean difference | Median difference | Better / tied / worse weeks | Descriptive block interval |
| --- | ---: | ---: | --- | --- |
| mean | 129.57 | 71.00 | 9 / 0 / 14 | [-65.96, 324.99] |
| seasonal | -1009.57 | -1017.00 | 20 / 0 / 3 | [-1274.87, -706.71] |
| equal | -1119.95 | -1078.00 | 21 / 0 / 2 | [-1418.28, -747.56] |

Negative differences favour the scenario allocation. Intervals use 2,000 seeded, noncircular four-week moving-block resamples from only 23 paired weeks; they are descriptive dependence sensitivity, not population guarantees. Perfect-information allocations use the actual week and are unattainable when planning.

## Complete evidence

- public_index.json contains all 60 primary policy-setting summaries, 36 paired baseline comparisons and 180 sensitivity summaries.
- evaluated_cases.json contains every primary week/setting/policy allocation and score; sensitivity_cases.json retains all three modified targets.
- diagnostics.json contains unrounded mean and seasonal forecast MAE/WAPE, unconstrained empirical-quantile pinball loss and nonexceedance, fixed training-volume segments and all product-level scores. Zeros remain in denominators for MAE; WAPE and activity coverage are undefined (null) if recorded units sum to zero.
- parity_fixtures.json adds 70 independently seeded small/protected browser-reconciliation cases, including zero and ample budgets.

Each sensitivity modifies both historical and evaluated activity, recomputes that variant's past-only budget and baselines, and retains the primary cohort and selected window. Duplicate/reversal changes are alternative record treatments; the training-line cap changes the target. Their levels do not share the primary outcome definition and must not be read as causal improvements.

All 5,520 primary and sensitivity allocations passed integer, nonnegative, budget, exact empirical-objective and unattainable-bound checks. The exact algorithm has no floating optimization gap. Independent tiny-case enumeration and SciPy MILP parity are recorded in tests_verification.json.

## Limits

One historical retailer, 30 training-selected products and 23 test weeks cannot establish general retail performance. Product 84270 remains despite zero recorded test activity. Zero history can suppress a data-only allocation; observed zeros do not establish zero latent demand or a stockout. The aggregate unit resource treats all product units equally; size, margin, lead time, carry-over, inventory, capacity and availability are unobserved. Lambda is a preference, not an estimated economic cost. Historical invoice availability by week-end is assumed, not verified by data vintages. The separable expected objective uses marginal distributions; retaining weekly vectors does not establish an optimization benefit from correlations.

Source: Chen, D. (2012), Online Retail II, UCI Machine Learning Repository, https://doi.org/10.24432/C5CG6D, CC BY 4.0. Derived product/week aggregates and model outputs by Abdulaziz Aldoseri. No endorsement implied.
