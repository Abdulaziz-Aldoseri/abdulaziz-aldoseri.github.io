# Admission, surgery and recovery-bed scheduling

An independent Decision Science and Analytics study by Abdulaziz Aldoseri.

Choose an admission day and eligible recovery ward for each patient in a generated hospital benchmark. Surgery occurs on admission day, and the patient remains in one ward for the fixed length of stay. Compare two priorities: first minimize admission delay, then excess surgery minutes; or first minimize excess surgery minutes, then admission delay. These are two lexicographic endpoints, not a complete Pareto frontier.

The comparison covers five predetermined source cohorts, all four native ward-compatibility variants, and zero or one hypothetical bed closure per ward: 40 cases. All patient records in those source cohorts remain included. A deterministic deadline-first insertion/backtracking baseline provides a comparator only when it finds a complete, independently verified schedule. A separate strict-calendar diagnostic tests whether the same cohort fits entirely within the given daily surgical allocations.

## Source and scope

Pieter Smet, **Data for “Generating balanced workload allocations in hospitals”**, Mendeley Data, version 1, 13 April 2023, DOI [10.17632/3mv4rtxtfs.1](https://data.mendeley.com/datasets/3mv4rtxtfs/1). The dataset is licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). These are generated benchmark instances informed by one Belgian hospital, not observed patient records. Source codes, fixed requirements and selected native file bytes are preserved; transformations and the independent timing/capacity objectives are documented in the protocol and preparation records. No source-author, hospital or publisher endorsement is implied.

Days 1 through 7 are relative labels for source days 0 through 6, not civil dates or weekdays. Durations and scheduled surgery allocations use integer minutes. The census includes every new patient's complete stay and the exact native daily carryover counts. Carryover is aggregate ward/day occupancy: individual identities and discharge dates are unavailable. Positive carryover on the last day is retained; no later recovery trajectory is invented.

The model accounts for whole-day beds and surgery minutes by discipline and day. Excess minutes describe additional capacity a plan would require; they do not establish that this capacity is available. Staffing, workload balance, clinical decisions, within-day operating rooms, surgeon rosters and clinical outcomes are outside scope. A model-feasible plan is not proof of an operational hospital timetable or realized improvement. The original paper studies workload balance; this project changes the objectives and does not reproduce its reported findings.

## Reproduction

The website provides one **Open in Google Colab** link. That delivery notebook automatically retrieves the complete pinned package, checks its size and SHA-256, validates archive members before extraction/imports, and installs the pinned numerical requirements in Colab. No separate upload or Drive mount is required. Hosted Colab execution is a separate check from local reproduction; consult the release record for what was actually verified.

For local execution, use Python 3.12 or later with the exact versions in `requirements.txt`. Open `healthcare_scheduling.ipynb` inside the extracted package. Its setup verifies package contents before importing study modules; local setup makes no network request and installs nothing. Run every cell in order. The notebook explains the inputs, validates the source/model freeze, checks every saved schedule, runs the model tests, and presents complete-case evidence with solver and baseline statuses. A fresh full-grid rerun is available through its explicitly labelled reproduction control and writes to a new directory, preserving frozen results.

From the extracted folder, the equivalent command-line checks are:

```text
python -m pip install -r requirements.txt
python pipeline.py verify
python -m unittest discover -s tests -v
python pipeline.py reproduce --output-dir fresh-reproduction
```

The first command installs requirements only when needed for a new local environment. The final command requests a complete rerun; choose a new output directory each time. `FREEZE.json` pins the evaluated code/inputs, while `package_manifest.json` covers the complete distribution, including documentation and source files.

The public notebook is distributed without saved cell outputs. The package retains original selected native data, prepared data, protocol and code fingerprints, complete evaluated results, source attribution and implementation tests. SHA-256 values establish consistency with the pinned package; they are not an independent guarantee of publisher identity or model validity.

## Interpreting reproduction differences

Different valid assignments may have the same objective pair because neither priority uniquely identifies a schedule. Compare exact reconstructed feasibility, objective pairs, primary/secondary status and complete-case coverage; report assignment differences explicitly. A runtime limit can also change which incumbent a bounded solve returns. Do not replace an unresolved primary optimum with a claim of lexicographic optimality, or treat a failed baseline search as model infeasibility.

Keep missing baselines, proven infeasibility, limits, ties and adverse comparisons in the evidence. Forty cases are a fixed demonstration grid, not an estimate of how often a method helps hospitals. Original study code licensing is recorded in `LICENSE`; it is separate from the dataset's CC BY 4.0 attribution requirements.
