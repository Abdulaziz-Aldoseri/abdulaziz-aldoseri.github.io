# Complete evaluated results — evidence 1.0.0

Generated benchmark evaluation, 15 September 2026. All 40 cases were selected and the model frozen before the first native solve. Exact complete outputs are retained under `outputs/cases/`; `outputs/overview.json` indexes every case. This report is generated after evaluation and does not tune or select cases.

Both objective priorities have proven lexicographic optima in 30 cases. The remaining 10 cases are infeasible under the all-patient hard-bed constraints. The baseline is complete and verified in the same 30 feasible cases; in the other cases it exhausts its finite search twice and reaches its predefined search-node limit eight times. No solver time limit occurred in either optimized endpoint.

Earlier-admission optimization ties the baseline in both reported objectives in all 30 feasible cases: every patient can be admitted on the earliest permissible day. Prioritizing less calendar excess reduces excess minutes in all 30 feasible cases, while increasing total admission-delay days in all 30. This is a trade-off, not a claim that optimization dominates the baseline on both objectives.

The fixed reference s0m0b0 has 117 new patients. Its baseline and earlier-admission endpoint both produce 0 patient-days of delay and 9,404 excess surgery minutes. The lower-excess endpoint produces 4 patient-days of delay and 8,754 excess minutes: 650 fewer excess minutes in exchange for 4 patient-days of delay. This additional capacity requirement does not establish available overtime, a clinically safe plan or measured operational savings.

All 40 strict-calendar diagnostics are infeasible because fixed-date patient loads alone exceed at least one specialty/day scheduled allocation. The independent mandatory-load excess lower bounds are 6,374, 6,365, 6,021, 9,423 and 4,991 minutes for seeds 0 through 4, respectively. These lower bounds are capacity certificates, not optimized results or a staffing requirement.

All eight compatibility/closure cases for seed 1 remain hard-bed infeasible. Seed 3 is hard-bed infeasible under M=0 for both bed scenarios; its native M=1,2,3 configurations permit complete schedules. Every other case is feasible under the soft-calendar model. Closing one bed per ward changes neither endpoint objective pair nor feasibility in this selected sample; the complete occupancy consequences remain available. A lack of objective change is retained, not hidden.

In feasible cases, the two objectives do not penalize minor-specialty assignments or peak census. Their counts and plotted ward patterns can change between equal-objective solutions. These descriptive differences do not establish better staffing balance, patient care or unique optimal placement.

| Case | Baseline status | Baseline delay / excess | Earlier-admission delay / excess | Less-excess delay / excess |
| --- | --- | --- | --- | --- |
| s0m0b0 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m0b1 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m1b0 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m1b1 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m2b0 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m2b1 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m3b0 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s0m3b1 | verified_baseline | 0 / 9,404 | 0 / 9,404 | 4 / 8,754 |
| s1m0b0 | proven_infeasible | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m0b1 | proven_infeasible | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m1b0 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m1b1 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m2b0 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m2b1 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m3b0 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s1m3b1 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s2m0b0 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m0b1 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m1b0 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m1b1 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m2b0 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m2b1 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m3b0 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s2m3b1 | verified_baseline | 0 / 10,449 | 0 / 10,449 | 11 / 9,681 |
| s3m0b0 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s3m0b1 | baseline_search_limit | infeasible / unavailable | infeasible / unavailable | infeasible / unavailable |
| s3m1b0 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s3m1b1 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s3m2b0 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s3m2b1 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s3m3b0 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s3m3b1 | verified_baseline | 0 / 14,290 | 0 / 14,290 | 1 / 14,227 |
| s4m0b0 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m0b1 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m1b0 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m1b1 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m2b0 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m2b1 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m3b0 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |
| s4m3b1 | verified_baseline | 0 / 6,027 | 0 / 6,027 | 9 / 5,517 |

Delay is summed patient-days after each earliest permitted admission. Excess is minutes beyond the original specialty/day surgery calendar. M is the number of native minor specialties per ward; b is the hypothetical number of beds closed in each ward. Zero-calendar additional-session minutes are zero for all selected native cases because all their calendar cells have positive scheduled minutes.

Validation: the 22-test pre-evaluation suite passed; all 40 frozen cases passed exact complete-schedule reconstruction and 74 applicable primary-objective monotonicity comparisons. Independent native-file and package reviews are recorded with the release. These five numerically first cohorts are a bounded demonstration sample; no population-level impact estimate is implied.
