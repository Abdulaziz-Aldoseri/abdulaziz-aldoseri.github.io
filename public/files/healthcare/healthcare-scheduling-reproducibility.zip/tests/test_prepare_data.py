import copy
import unittest
from prepare_data import validate_instance
from test_scheduling_model import instance, patient


class PreparationTests(unittest.TestCase):
    def test_invalid_input_guard_cases(self):
        base = instance([patient('p0')])
        cases = []
        d = copy.deepcopy(base); d['patients'].append(copy.deepcopy(d['patients'][0])); cases.append(d)
        d = copy.deepcopy(base); d['patients'][0]['duration'] = 1.5; cases.append(d)
        d = copy.deepcopy(base); d['specialties'][0]['minutes'].pop(); cases.append(d)
        d = copy.deepcopy(base); d['patients'][0]['latest'] = -1; cases.append(d)
        d = copy.deepcopy(base); d['patients'][0]['los'] = 5; cases.append(d)
        d = copy.deepcopy(base); d['patients'][0]['specialty'] = 'unknown'; cases.append(d)
        d = copy.deepcopy(base); d['wards'][0]['carryover'].pop(); cases.append(d)
        for value in cases:
            with self.assertRaises(ValueError): validate_instance(value)


if __name__ == '__main__': unittest.main()
