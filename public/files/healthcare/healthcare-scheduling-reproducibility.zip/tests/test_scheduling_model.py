import copy
import itertools
import unittest
from unittest.mock import patch
import numpy as np
import scheduling_model as sm


def instance(patients=None, beds=2, days=3, carryover=None, minutes=None):
    return {'days': days, 'wards': [{'id': 'A', 'major': 'A', 'minors': [], 'capacity': beds,
                                   'carryover': carryover or [0] * days}],
            'specialties': [{'id': 'A', 'minutes': minutes or [6] * days}],
            'patients': patients or []}


def patient(pid, earliest=0, latest=1, los=1, duration=6):
    return {'id': pid, 'specialty': 'A', 'earliest': earliest, 'latest': latest, 'los': los, 'duration': duration}


def enumerate_exact(data, closures=0):
    """Independent Cartesian enumeration and census arithmetic, no matrix/checker reuse."""
    options = []
    for p in data['patients']:
        options.append([(w['id'], d) for w in data['wards'] if p['specialty'] == w['major'] or p['specialty'] in w['minors']
                        for d in range(p['earliest'], p['latest'] + 1)])
    metrics = []
    for choices in itertools.product(*options):
        census = {w['id']: list(w['carryover']) for w in data['wards']}
        usage = {s['id']: [0] * data['days'] for s in data['specialties']}
        delay = 0
        for p, (ward, admission) in zip(data['patients'], choices):
            for d in range(admission, admission + p['los']): census[ward][d] += 1
            usage[p['specialty']][admission] += p['duration']
            delay += admission - p['earliest']
        if any(max(census[w['id']]) > w['capacity'] - closures for w in data['wards']): continue
        excess = sum(max(0, u - q) for s in data['specialties'] for u, q in zip(usage[s['id']], s['minutes']))
        metrics.append((delay, excess))
    return metrics


class SchedulingTests(unittest.TestCase):
    def test_endpoint_tradeoff(self):
        data = instance([patient('p0', los=2), patient('p1', latest=0)])
        all_pairs = enumerate_exact(data)
        for policy, key in [('delay_first', lambda x: x), ('overtime_first', lambda x: (x[1], x[0]))]:
            r = sm.solve(data, priority=policy)
            self.assertEqual(r['status'], 'lexicographic_optimal')
            self.assertEqual((r['metrics']['delay_days'], r['metrics']['overtime_minutes']), min(all_pairs, key=key))
        self.assertIn((0, 6), all_pairs)
        self.assertIn((1, 0), all_pairs)

    def test_backtracking_beats_dead_end(self):
        data = instance([patient('p0', los=2), patient('p1', los=1)], beds=1)
        r = sm.baseline(data)
        self.assertEqual(r['status'], 'verified_baseline')
        self.assertEqual([a['day'] for a in r['assignments']], [1, 0])
        self.assertGreater(r['search']['nodes'], 2)
        limited = sm.baseline(data, node_limit=1)
        self.assertEqual(limited['status'], 'baseline_search_limit')
        self.assertIsNone(limited['metrics'])
        timed = sm.baseline(data, time_limit=0)
        self.assertEqual(timed['status'], 'baseline_time_limit')

    def test_fullstay_carryover_tail(self):
        data = instance([patient('p0', latest=0, los=3)], beds=1, carryover=[0, 0, 1])
        self.assertEqual(enumerate_exact(data), [])
        self.assertEqual(sm.solve(data)['status'], 'proven_infeasible')
        self.assertEqual(sm.baseline(data)['status'], 'proven_infeasible')
        check = sm.verify_schedule(data, [{'patient_id': 'p0', 'ward_id': 'A', 'day': 0}])
        self.assertFalse(check['verification']['feasible'])

    def test_los_one_release_boundary(self):
        data = instance([patient('p0', latest=0), patient('p1', earliest=1, latest=1)], beds=1)
        r = sm.solve(data)
        self.assertEqual(r['occupancy'], [[1, 1, 0]])
        self.assertEqual(r['metrics']['delay_days'], 0)

    def test_closure_preserves_carryover(self):
        data = instance([], beds=1, carryover=[1, 0, 0])
        self.assertEqual(sm.solve(data, closed_beds=1)['status'], 'proven_infeasible')

    def test_empty_and_zero_calendar(self):
        self.assertEqual(sm.solve(instance())['metrics']['overtime_minutes'], 0)
        data = instance([patient('p0', latest=0)], minutes=[0, 0, 0])
        r = sm.solve(data)
        self.assertEqual(r['metrics']['additional_session_minutes'], 6)
        diag = sm.strict_calendar(data)
        self.assertEqual(diag['status'], 'proven_infeasible')
        self.assertEqual(diag['mandatory_overtime_lower_bound_minutes'], 6)

    def test_strict_calendar_solver_feasible_and_infeasible(self):
        self.assertEqual(sm.strict_calendar(instance([patient('p0')]))['status'], 'feasible')
        data = instance([patient('p0', duration=20)])
        self.assertEqual(sm.strict_calendar(data)['status'], 'proven_infeasible')

    def test_no_eligible_ward_and_competing_fixed_patients(self):
        data = instance([patient('p0')])
        data['specialties'].append({'id': 'B', 'minutes': [6, 6, 6]})
        data['patients'][0]['specialty'] = 'B'
        self.assertEqual(sm.solve(data)['status'], 'proven_infeasible')
        self.assertEqual(sm.baseline(data)['status'], 'proven_infeasible')
        data = instance([patient('p0', latest=0), patient('p1', latest=0)], beds=1)
        self.assertEqual(sm.solve(data)['status'], 'proven_infeasible')

    def test_tiny_matrix_of_independent_enumerations(self):
        for beds, duration, capacity, closure in itertools.product([1, 2], [2, 7], [0, 5], [0, 1]):
            data = instance([patient('p0', los=2, duration=duration), patient('p1', duration=3)], beds=beds, minutes=[capacity] * 3)
            pairs = enumerate_exact(data, closure)
            for policy, key in [('delay_first', lambda x: x), ('overtime_first', lambda x: (x[1], x[0]))]:
                r = sm.solve(data, closure, policy)
                if pairs:
                    self.assertEqual(r['status'], 'lexicographic_optimal')
                    self.assertEqual((r['metrics']['delay_days'], r['metrics']['overtime_minutes']), min(pairs, key=key))
                else:
                    self.assertEqual(r['status'], 'proven_infeasible')

    def test_invalid_assignments_rejected(self):
        data = instance([patient('p0')])
        for choices in [[], [{'patient_id': 'p0', 'ward_id': 'A', 'day': 0}] * 2,
                        [{'patient_id': 'p0', 'ward_id': 'A', 'day': .5}],
                        [{'patient_id': 'p0', 'ward_id': 'missing', 'day': 0}]]:
            self.assertFalse(sm.verify_schedule(data, choices)['verification']['feasible'])

    def test_stage_status_and_corrupted_incumbent(self):
        data = instance([patient('p0')])
        original = sm.milp
        for target, corrupt, expected in [(1, 'limit', 'feasible_incumbent_primary_unresolved'),
                                          (2, 'limit', 'primary_optimal_secondary_unresolved'),
                                          (1, 'no_incumbent', 'unknown_no_incumbent'),
                                          (1, 'fraction', 'invalid_result'),
                                          (1, 'objective', 'invalid_result'),
                                          (1, 'contradiction', 'invalid_result'),
                                          (2, 'fraction', 'primary_optimal_secondary_unresolved'),
                                          (2, 'objective', 'primary_optimal_secondary_unresolved'),
                                          (2, 'contradiction', 'primary_optimal_secondary_unresolved'),
                                          (2, 'exception', 'primary_optimal_secondary_unresolved')]:
            calls = [0]
            def wrapped(*args, **kwargs):
                value = original(*args, **kwargs)
                calls[0] += 1
                if calls[0] == target:
                    if corrupt == 'exception': raise RuntimeError('simulated second-stage solver failure')
                    if corrupt == 'limit': value.status = 1
                    if corrupt == 'no_incumbent': value.status = 1; value.x = None
                    if corrupt == 'fraction': value.x[0] = .5
                    if corrupt == 'objective': value.fun += 1
                    if corrupt == 'contradiction': value.status = 2
                return value
            with patch.object(sm, 'milp', wrapped):
                r = sm.solve(data)
            self.assertEqual(r['status'], expected)
            self.assertEqual(calls[0], target)
            if expected in ('unknown_no_incumbent', 'invalid_result'): self.assertIsNone(r['assignments'])

    def test_invalid_closures_every_entry(self):
        for closure in (-1, .5, True):
            for method in (sm.baseline, sm.build_model, sm.solve, sm.strict_calendar):
                with self.assertRaises(ValueError): method(instance([patient('p0')]), closure)


if __name__ == '__main__': unittest.main()
