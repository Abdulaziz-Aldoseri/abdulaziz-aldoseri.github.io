# Healthcare benchmark data preparation

This independent study uses Pieter Smet's *Data for 'Generating balanced workload allocations in hospitals'*, Mendeley Data version 1, published 13 April 2023, DOI [10.17632/3mv4rtxtfs.1](https://data.mendeley.com/datasets/3mv4rtxtfs/1), under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The data are generated benchmark instances based on one Belgian hospital. They are not observed patient records or an observed operating schedule. The creator and hospital do not endorse this independent study.

## Frozen cohort and source integrity

The source contains 250 numeric seeds, each with four native ward-compatibility variants. Select seeds **0, 1, 2, 3 and 4**, all four variants `M=0,1,2,3`, using numeric identifiers before optimization. Every source patient, ward, specialty, admission day and carryover occupancy cell is retained. The selected cohorts have 117, 102, 142, 113 and 118 new patients; four wards and seven days each. The same patient's record is repeated only as part of another explicit compatibility scenario, not counted as a different observed patient.

The reproduction package carries 20 unchanged native files under `sources/original/instances/` and the unchanged format guide `sources/original/README.pdf`. `source_manifest.json` supplies their byte lengths, SHA-256 values, exact original URLs and reuse terms. All 21 files match the publisher's per-file hashes. The complete source corpus, paper PDFs and web/API snapshots are not required to reproduce this bounded study and are excluded from the package.

## Parsing and transformations

Parse whitespace-separated rows and semicolon-separated arrays using the original README. Preserve the source row order and string identifiers. Convert native integer days, lengths of stay, surgery minutes, bed capacities and carryover counts without rounding, rescaling, imputation, interpolation or random generation.

| Native inputs | Prepared meaning |
| --- | --- |
| `Seed`, `M`, `Days` | Numeric cohort, native compatibility variant, seven-day horizon. |
| Specialty ID and available OT time per day | Fixed specialty/day surgery-minute budgets. |
| Ward ID, beds, major/minor specialties | Integer bed capacity and permitted patient specialties. `NONE` becomes an empty minor-specialty list. |
| Ward carryover patients | Fixed aggregate occupied beds for days 0..6. These are not individual records. |
| Patient ID, specialty, earliest/latest, LOS, surgery duration | Complete patient requirements, retaining original day indices and integer minutes. |

Unused source fields remain in the unchanged native files but are excluded from the prepared optimization inputs: workload scaling factors, ward workload capacity, carryover workload, patient workload arrays and the original overtime/undertime/delay weights. The present study changes the objective to two lexicographic admission-delay/excess-time priorities and does not reproduce the source paper's workload-balance results.

Derive each patient's eligible ward list from the source major/minor specialty membership. Derive admissible admission days from its inclusive earliest/latest window. A new patient admitted on day `a` with stay `L` occupies one bed on every day `a <= t < a+L`; surgery occurs on day `a`. This convention follows the paper's day-based scheduling formulation. Every native `latest+LOS` is at most 7, so no stay is clipped or extended. Source day 0 can be displayed as Day 1; no calendar date, weekday or time zone is invented.

Source minor-specialty sets are nested as M increases within a seed. All other patient, capacity, calendar and carryover values are identical across its variants. This represents alternative compatibility assumptions, not a measured expansion of clinical capabilities.

## Explicit scenarios and derived quantities

The only bed scenario modification is closing zero or one bed **in each ward** for the complete seven days. This is hypothetical. Existing occupancy remains unchanged, and an occupancy/capacity conflict is infeasible. No patient is removed, rescheduled outside its window, transferred between wards or given a shorter stay to repair a scenario.

The 20 native inputs and two closure settings produce 40 predetermined cases. The fixed reference is seed 0, M0, no closures, admission-delay-first priority. Derived choices, bed censuses, delay and surgery excess are model outputs and must be labelled separately from inputs.

For the strict-calendar diagnostic, sum the durations of fixed-date patients by specialty/day and compare that compulsory load with the original budget. Positive excess is a mathematical certificate that a plan respecting that strict calendar cannot schedule everyone. It is not an optimized attainable excess total. Fixed-date patients are not labelled urgent: no individual urgency flag is available.

## Validation and interpretation limits

Check declared row counts, unique patient identifiers within each instance, valid specialty references, eligibility, exact seven-cell calendars/carryover arrays, nonnegative capacities, positive durations and LOS, and `0 <= earliest <= latest < 7` with `latest+LOS <= 7`. Reconcile every new patient and all calendar/occupancy cells before solving. Initial occupied beds must remain within the scenario's effective capacities.

All inputs are known in this static deterministic benchmark, so a predictive train/test split is inapplicable. Duration and LOS uncertainty, future unannounced arrivals, actual procedures/clinical priorities, surgeon and nurse rosters, room-level sequencing, cleaning time, financial costs and observed service outcomes are not supplied. Soft calendar excess estimates additional required surgery minutes; it does not establish those minutes are operationally available. Do not infer patient benefit, hospital savings or real implementation from this demonstration.
