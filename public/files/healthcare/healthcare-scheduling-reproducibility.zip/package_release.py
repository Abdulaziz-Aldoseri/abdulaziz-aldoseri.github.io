"""Build and strictly extract-check the complete allowlisted healthcare package."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import zipfile

from notebook_setup import manifest_entries, safe_extract_package, safe_name


ROOT = Path(__file__).resolve().parent
ARCHIVE = "healthcare-scheduling-reproducibility.zip"
BASE_FILES = [
    "README.md", "LICENSE", "METHODS.md", "RESULTS.md", "DATA_PREPARATION.md", "DATA_PREPARATION.json", "source_manifest.json",
    "PROTOCOL.json", "FREEZE.json", "UI_SCHEMA.json", "requirements.txt",
    "prepare_data.py", "scheduling_model.py", "pipeline.py",
    "notebook_setup.py", "make_notebook.py", "package_release.py", "verify_notebook.py",
    "healthcare_scheduling.ipynb", "data/manifest.json",
    "sources/original/README.pdf",
    "outputs/overview.json", "outputs/evaluation_verification.json",
    "outputs/EVIDENCE_MANIFEST.json", "outputs/reproduction_verification.json",
]


def selected_files() -> list[str]:
    names = list(BASE_FILES)
    for seed in range(5):
        for variant in range(4):
            names.append(f"sources/original/instances/s{seed}m{variant}.dat")
            names.append(f"data/instances/s{seed}m{variant}.json")
            for closure in (0, 1):
                names.append(f"outputs/cases/s{seed}m{variant}b{closure}.json")
    tests = sorted((ROOT / "tests").glob("test_*.py"))
    required = {"test_notebook_setup.py", "test_scheduling_model.py", "test_prepare_data.py"}
    if not required <= {p.name for p in tests}:
        raise ValueError("The required source, model and safe-setup tests must be present")
    names.extend(p.relative_to(ROOT).as_posix() for p in tests)
    if len(names) != len(set(names)):
        raise ValueError("Duplicate package allowlist member")
    return sorted(names)


def read_member(name: str) -> bytes:
    safe_name(name)
    path = ROOT / name
    if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
        raise ValueError("Missing or unsafe package member: " + name)
    if any(parent.is_symlink() for parent in path.parents if parent != ROOT.parent):
        raise ValueError("Symlink in package member ancestry: " + name)
    raw = path.read_bytes()
    if path.suffix.casefold() != ".pdf":
        text = raw.decode("utf-8")
        # Build tokens from pieces so this verifier can itself be redistributed.
        forbidden = ["C:" + "/Users/", "C:" + "\\Users\\", "Career" + " Planning", "employment" + "-dispute", "contract" + " value"]
        if any(token.casefold() in text.casefold() for token in forbidden):
            raise ValueError("Private or machine-specific text in package member: " + name)
    return raw


def build() -> dict:
    # The pipeline's verifier checks frozen source/code and every saved schedule.
    # A valid unresolved/infeasible case remains admissible; failures cannot be
    # removed merely to obtain an attractive complete-grid success statistic.
    check = subprocess.run(
        [sys.executable, str(ROOT / "pipeline.py"), "verify"],
        cwd=ROOT, text=True, capture_output=True, check=True,
    )
    expected = {f"s{s}m{m}b{b}" for s in range(5) for m in range(4) for b in (0, 1)}
    available = {p.stem for p in (ROOT / "outputs" / "cases").glob("*.json")}
    if available != expected:
        raise ValueError("The exact predetermined 40-case grid is required")
    overview = json.loads((ROOT / "outputs" / "overview.json").read_text(encoding="utf-8"))
    if {s["id"] for s in overview["scenarios"]} != expected or len(overview["scenarios"]) != 40:
        raise ValueError("Overview does not index every case exactly once")

    contents = {name: read_member(name) for name in selected_files()}
    frozen = json.loads(contents["FREEZE.json"].decode("utf-8"))
    for relative, expected_hash in frozen["files"].items():
        if relative not in contents or hashlib.sha256(contents[relative]).hexdigest() != expected_hash:
            raise ValueError("A frozen artifact is absent or changed in the package: " + relative)
    for filename, expected_hash in frozen["source_files"].items():
        relative = "sources/original/instances/" + filename
        if relative not in contents or hashlib.sha256(contents[relative]).hexdigest() != expected_hash:
            raise ValueError("A native source artifact is absent or changed: " + filename)
    for scenario in overview["scenarios"]:
        relative = "outputs/cases/" + scenario["id"] + ".json"
        if hashlib.sha256(contents[relative]).hexdigest() != scenario["sha256"]:
            raise ValueError("Overview does not match frozen case bytes: " + scenario["id"])
    reference = json.loads(contents["outputs/cases/s0m0b0.json"].decode("utf-8"))
    if overview["default_case"] != reference or overview["default_policy"] != "delay_first":
        raise ValueError("The predetermined reference must remain unchanged")
    files = [{"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()} for name, raw in contents.items()]
    manifest = (json.dumps({"project": "healthcare-scheduling", "source_license": "CC BY 4.0", "source_doi": "10.17632/3mv4rtxtfs.1", "native_instances": 20, "cases": 40, "files": files}, indent=2) + "\n").encode("utf-8")
    manifest_entries(manifest)
    output = ROOT / "outputs" / "downloads"
    output.mkdir(parents=True, exist_ok=True)
    archive = output / ARCHIVE
    # Stable member timestamps and order make the same frozen inputs produce
    # the same archive, independent of machine-local source modification times.
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, raw in [*contents.items(), ("package_manifest.json", manifest)]:
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 15, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zipped.writestr(info, raw, compresslevel=9)
    with tempfile.TemporaryDirectory(prefix="healthcare-package-check-") as temporary:
        safe_extract_package(archive, Path(temporary) / "verified")
    report = {
        "status": "PASS",
        "file": ARCHIVE,
        "bytes": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "members": len(files) + 1,
        "native_instances_included": 20,
        "complete_grid_cases": 40,
        "strict_safe_extraction": "PASS",
        "frozen_pipeline_verification": check.stdout.strip(),
        "private_paper_pdf_included": False,
        "built_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
    }
    (output / "manifest.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return {key: value for key, value in report.items() if key != "files"}


if __name__ == "__main__":
    print(json.dumps(build(), indent=2))
