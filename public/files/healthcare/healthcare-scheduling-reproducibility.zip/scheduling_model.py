"""Whole-patient admission scheduling with hard beds and measured surgery excess."""
import math
import time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_array, vstack
from prepare_data import validate_instance, canonical, digest

TOL = 1e-6


def validate_closure(closed_beds):
    if type(closed_beds) is not int or closed_beds < 0:
        raise ValueError('Invalid closure count')


def allowed(instance, p):
    return [i for i, w in enumerate(instance['wards']) if p['specialty'] in [w['major'], *w['minors']]]


def verify_schedule(instance, assignments, closed_beds=0, strict=False):
    """Reconstruct original requirements without consulting constraint matrices/slacks."""
    validate_instance(instance)
    validate_closure(closed_beds)
    errors = []
    wards = {w['id']: i for i, w in enumerate(instance['wards'])}
    specs = {s['id']: i for i, s in enumerate(instance['specialties'])}
    patients = {p['id']: p for p in instance['patients']}
    occupancy = [list(w['carryover']) for w in instance['wards']]
    usage = [[0] * instance['days'] for _ in instance['specialties']]
    seen, delays, minors = set(), [], 0
    if assignments is None:
        assignments = []
        errors.append('No assignment supplied')
    for a in assignments:
        pid, wid, day = a.get('patient_id'), a.get('ward_id'), a.get('day')
        if pid not in patients or pid in seen:
            errors.append('Unknown or duplicate patient: ' + str(pid)); continue
        seen.add(pid)
        p = patients[pid]
        if wid not in wards or type(day) is not int:
            errors.append('Invalid ward or day: ' + str(pid)); continue
        widx = wards[wid]
        ward = instance['wards'][widx]
        if p['specialty'] not in [ward['major'], *ward['minors']]:
            errors.append('Ineligible ward: ' + pid); continue
        if not p['earliest'] <= day <= p['latest'] or day < 0 or day + p['los'] > instance['days']:
            errors.append('Invalid date or clipped full stay: ' + pid); continue
        for t in range(day, day + p['los']):
            occupancy[widx][t] += 1
        usage[specs[p['specialty']]][day] += p['duration']
        delays.append(day - p['earliest'])
        minors += p['specialty'] != ward['major']
    if seen != set(patients):
        errors.append('Not every patient assigned exactly once')
    slacks = []
    for wi, w in enumerate(instance['wards']):
        for d, census in enumerate(occupancy[wi]):
            slack = w['capacity'] - closed_beds - census
            slacks.append(slack)
            if slack < 0:
                errors.append(f'Bed capacity exceeded: {w["id"]} day {d}')
    excess, additional = 0, 0
    for si, specialty in enumerate(instance['specialties']):
        for d, q in enumerate(specialty['minutes']):
            over = max(0, usage[si][d] - q)
            excess += over
            if q == 0:
                additional += over
            if strict and over:
                errors.append(f'Strict calendar exceeded: {specialty["id"]} day {d}')
    complete = len(assignments) == len(patients) and seen == set(patients)
    verification = {'complete': complete, 'feasible': complete and not errors, 'errors': errors}
    if errors:
        return {'verification': verification, 'metrics': None, 'occupancy': None, 'or_minutes': None}
    metrics = {'delay_days': sum(delays), 'mean_delay_days': sum(delays) / len(delays) if delays else None,
               'delayed_patients': sum(d > 0 for d in delays), 'max_delay_days': max(delays, default=0),
               'overtime_minutes': excess, 'additional_session_minutes': additional,
               'minor_assignments': int(minors), 'min_bed_slack': min(slacks)}
    return {'verification': verification, 'metrics': metrics, 'occupancy': occupancy, 'or_minutes': usage}


def result(instance, assignments, closed_beds, status, message, stages=None, search=None):
    checked = verify_schedule(instance, assignments, closed_beds) if assignments is not None else {
        'verification': {'complete': False, 'feasible': False, 'errors': []},
        'metrics': None, 'occupancy': None, 'or_minutes': None}
    if assignments is not None and not checked['verification']['feasible']:
        status, message, assignments = 'invalid_result', 'Independent schedule verification failed.', None
    return {'status': status, 'message': message, 'assignments': assignments,
            **checked, 'solver_stages': stages or [], 'search': search,
            'assignment_sha256': digest(canonical(assignments)) if assignments is not None else None}


def baseline(instance, closed_beds=0, node_limit=100000, time_limit=60):
    validate_instance(instance)
    validate_closure(closed_beds)
    start, nodes, stop = time.monotonic(), 0, None
    ordered = sorted(enumerate(instance['patients']), key=lambda item: (item[1]['latest'], item[1]['earliest'], item[0]))
    occupancy = [list(w['carryover']) for w in instance['wards']]
    capacities = [w['capacity'] - closed_beds for w in instance['wards']]
    selected = {}
    if any(x > capacities[wi] for wi, row in enumerate(occupancy) for x in row):
        return result(instance, None, closed_beds, 'proven_infeasible', 'Fixed carryover exceeds available beds.',
                      search={'nodes': 0, 'node_limit': node_limit, 'seconds': time.monotonic() - start, 'stop_reason': 'exhausted'})

    choices = {}
    for pi, p in ordered:
        eligible = sorted(allowed(instance, p), key=lambda wi: (instance['wards'][wi]['major'] != p['specialty'], wi))
        choices[pi] = [(day, wi) for day in range(p['earliest'], p['latest'] + 1) for wi in eligible]

    def can_place(p, day, wi):
        return all(occupancy[wi][d] < capacities[wi] for d in range(day, day + p['los']))

    def visit(index):
        nonlocal nodes, stop
        if index == len(ordered):
            return True
        pi, p = ordered[index]
        for day, wi in choices[pi]:
            if nodes >= node_limit:
                stop = 'node_limit'; return False
            if time.monotonic() - start >= time_limit:
                stop = 'time_limit'; return False
            nodes += 1
            if not can_place(p, day, wi):
                continue
            for d in range(day, day + p['los']):
                occupancy[wi][d] += 1
            selected[pi] = {'patient_id': p['id'], 'ward_id': instance['wards'][wi]['id'], 'day': day}
            viable = all(any(can_place(rp, rd, rw) for rd, rw in choices[ri]) for ri, rp in ordered[index + 1:])
            if viable and visit(index + 1):
                return True
            del selected[pi]
            for d in range(day, day + p['los']):
                occupancy[wi][d] -= 1
            if stop:
                return False
        return False

    found = visit(0)
    stop = 'complete' if found else stop or 'exhausted'
    status = {'complete': 'verified_baseline', 'exhausted': 'proven_infeasible',
              'node_limit': 'baseline_search_limit', 'time_limit': 'baseline_time_limit'}[stop]
    assignments = [selected[i] for i in range(len(instance['patients']))] if found else None
    return result(instance, assignments, closed_beds, status,
                  'First complete deadline-first schedule.' if found else 'Baseline search stopped: ' + stop,
                  search={'nodes': nodes, 'node_limit': node_limit, 'seconds': time.monotonic() - start, 'stop_reason': stop})


def build_model(instance, closed_beds=0, strict=False):
    validate_instance(instance)
    validate_closure(closed_beds)
    pcount, wcount, scount, days = len(instance['patients']), len(instance['wards']), len(instance['specialties']), instance['days']
    smap = {s['id']: i for i, s in enumerate(instance['specialties'])}
    variables = [(pi, wi, d) for pi, p in enumerate(instance['patients']) for d in range(p['earliest'], p['latest'] + 1) for wi in allowed(instance, p)]
    nx = len(variables)
    nvars, nrows = nx + scount * days, pcount + wcount * days + scount * days
    ri, ci, va = [], [], []
    lb = np.full(nrows, -np.inf)
    ub = np.zeros(nrows)
    lb[:pcount] = ub[:pcount] = 1
    for wi, w in enumerate(instance['wards']):
        for d in range(days):
            ub[pcount + wi * days + d] = w['capacity'] - closed_beds - w['carryover'][d]
    for si, s in enumerate(instance['specialties']):
        for d in range(days):
            ub[pcount + wcount * days + si * days + d] = s['minutes'][d]
    delay, overtime = np.zeros(nvars), np.zeros(nvars)
    for col, (pi, wi, d) in enumerate(variables):
        p = instance['patients'][pi]
        ri.append(pi); ci.append(col); va.append(1)
        for day in range(d, d + p['los']):
            ri.append(pcount + wi * days + day); ci.append(col); va.append(1)
        ri.append(pcount + wcount * days + smap[p['specialty']] * days + d); ci.append(col); va.append(p['duration'])
        delay[col] = d - p['earliest']
    for i in range(scount * days):
        ri.append(pcount + wcount * days + i); ci.append(nx + i); va.append(-1)
        overtime[nx + i] = 1
    matrix = coo_array((np.asarray(va, dtype=float), (np.asarray(ri, dtype=np.int32), np.asarray(ci, dtype=np.int32))), shape=(nrows, nvars)).tocsc()
    total_duration = sum(p['duration'] for p in instance['patients'])
    upper = np.r_[np.ones(nx), np.full(scount * days, 0 if strict else total_duration)]
    return {'variables': variables, 'matrix': matrix, 'lower': lb, 'upper': ub,
            'bounds': Bounds(np.zeros(nvars), upper), 'integrality': np.r_[np.ones(nx), np.zeros(scount * days)],
            'delay_days': delay, 'overtime_minutes': overtime}


def _finite(value):
    return float(value) if value is not None and math.isfinite(float(value)) else None


def _stage(model, objective, index, time_limit, lock=None):
    matrix, lower, upper = model['matrix'], model['lower'], model['upper']
    if lock:
        vector = coo_array(model[lock[0]].reshape(1, -1)).tocsc()
        matrix = vstack([matrix, vector], format='csc')
        lower, upper = np.r_[lower, lock[1]], np.r_[upper, lock[1]]
    start = time.monotonic()
    coeff = np.zeros(len(model['bounds'].lb)) if objective == 'feasibility' else model[objective]
    solved = milp(coeff, integrality=model['integrality'], bounds=model['bounds'],
                  constraints=LinearConstraint(matrix, lower, upper),
                  options={'presolve': True, 'time_limit': time_limit, 'mip_rel_gap': 0.0})
    record = {'stage': index, 'objective': objective, 'status': int(solved.status), 'message': str(solved.message),
              'optimal': solved.status == 0, 'objective_value': _finite(getattr(solved, 'fun', None)),
              'dual_bound': _finite(getattr(solved, 'mip_dual_bound', None)), 'gap': _finite(getattr(solved, 'mip_gap', None)),
              'nodes': int(solved.mip_node_count) if getattr(solved, 'mip_node_count', None) is not None else None,
              'seconds': time.monotonic() - start, 'primary_value_locked': lock[1] if lock else None}
    return solved, record


def _decode(instance, model, solved):
    raw = getattr(solved, 'x', None)
    if raw is None:
        return None
    if len(raw) != len(model['bounds'].lb) or not np.all(np.isfinite(raw)):
        raise ValueError('Nonfinite or malformed incumbent')
    x = np.asarray(raw[:len(model['variables'])])
    if np.any(x < -TOL) or np.any(x > 1 + TOL) or np.max(np.abs(x - np.rint(x)), initial=0) > TOL:
        raise ValueError('Nonintegral/out-of-bound assignment incumbent')
    assignments = []
    for value, (pi, wi, day) in zip(x, model['variables']):
        if round(float(value)) == 1:
            assignments.append({'patient_id': instance['patients'][pi]['id'], 'ward_id': instance['wards'][wi]['id'], 'day': day})
    porder = {p['id']: i for i, p in enumerate(instance['patients'])}
    return sorted(assignments, key=lambda a: porder[a['patient_id']])


def solve(instance, closed_beds=0, priority='delay_first', time_limit=60):
    if priority not in ('delay_first', 'overtime_first'):
        raise ValueError('Unknown priority')
    model = build_model(instance, closed_beds)
    objectives = ('delay_days', 'overtime_minutes') if priority == 'delay_first' else ('overtime_minutes', 'delay_days')
    if not instance['patients']:
        checked = verify_schedule(instance, [], closed_beds)
        if not checked['verification']['feasible']:
            return result(instance, None, closed_beds, 'proven_infeasible', 'Fixed carryover exceeds capacity in an empty new-patient cohort.')
        trivial = [{'stage': i, 'objective': name, 'status': 0, 'message': 'Exact empty-cohort certificate: both nonnegative objectives equal zero.',
                    'optimal': True, 'objective_value': 0, 'dual_bound': 0, 'gap': 0, 'nodes': 0, 'seconds': 0,
                    'primary_value_locked': None if i == 1 else 0, 'method': 'exact_empty_cohort'} for i, name in enumerate(objectives, 1)]
        return result(instance, [], closed_beds, 'lexicographic_optimal', 'Exact empty-cohort objective certificate and fixed occupancy verified.', trivial)
    stages, incumbent, primary_value = [], None, None
    for index, objective in enumerate(objectives, 1):
        try:
            solved, record = _stage(model, objective, index, time_limit, (objectives[0], primary_value) if index == 2 else None)
        except Exception as exc:
            stages.append({'stage': index, 'objective': objective, 'status': 4, 'message': str(exc), 'optimal': False,
                           'objective_value': None, 'dual_bound': None, 'gap': None, 'nodes': None, 'seconds': None,
                           'primary_value_locked': primary_value if index == 2 else None, 'exception': type(exc).__name__})
            return result(instance, incumbent, closed_beds,
                          'primary_optimal_secondary_unresolved' if index == 2 else 'invalid_result',
                          'Solver call failed; any verified primary optimum is retained. ' + str(exc), stages)
        stages.append(record)
        def reject(message):
            record['optimal'] = False
            record['rejection_reason'] = message
            if index == 2 and incumbent is not None:
                return result(instance, incumbent, closed_beds, 'primary_optimal_secondary_unresolved',
                              'Rejected secondary result; retained verified primary optimum. ' + message, stages)
            return result(instance, None, closed_beds, 'invalid_result', message, stages)
        try:
            assignments = _decode(instance, model, solved)
        except ValueError as exc:
            return reject(str(exc))
        if assignments is not None:
            checked = verify_schedule(instance, assignments, closed_beds)
            if not checked['verification']['feasible']:
                return reject('Invalid solver incumbent: ' + str(checked['verification']['errors']))
            if solved.status in (2, 3):
                return reject('Solver status contradicts a complete verified feasible incumbent.')
            exact = checked['metrics'][objective]
            if record['objective_value'] is None or abs(record['objective_value'] - exact) > 1e-5:
                return reject('Solver objective differs from reconstructed schedule.')
            if index == 2 and checked['metrics'][objectives[0]] != primary_value:
                return reject('Secondary solve changed primary optimum.')
            incumbent = assignments
        if solved.status == 2:
            if index == 2:
                return result(instance, incumbent, closed_beds, 'primary_optimal_secondary_unresolved', 'Secondary solve unexpectedly reported infeasible; retained primary optimum.', stages)
            return result(instance, None, closed_beds, 'proven_infeasible', 'All-patient hard-bed model is infeasible.', stages)
        if solved.status == 3:
            return reject('Unexpected unbounded assignment model.')
        if solved.status != 0:
            status = 'primary_optimal_secondary_unresolved' if index == 2 else ('feasible_incumbent_primary_unresolved' if incumbent is not None else 'unknown_no_incumbent')
            return result(instance, incumbent, closed_beds, status, 'Solver stopped before both objectives were proven optimal.', stages)
        if assignments is None:
            return reject('Optimal status without complete incumbent.')
        bound = record['dual_bound']
        if bound is None or abs(exact - bound) > 1e-5:
            return reject('Optimal status without matching objective bound.')
        if index == 1:
            primary_value = exact
    return result(instance, incumbent, closed_beds, 'lexicographic_optimal', 'Both objective stages proven optimal and complete schedule verified.', stages)


def strict_calendar(instance, closed_beds=0, time_limit=60):
    validate_instance(instance)
    validate_closure(closed_beds)
    certificate = []
    for s in instance['specialties']:
        for day, capacity in enumerate(s['minutes']):
            forced = [p for p in instance['patients'] if p['specialty'] == s['id'] and p['earliest'] == p['latest'] == day]
            load = sum(p['duration'] for p in forced)
            if load > capacity:
                certificate.append({'specialty_id': s['id'], 'day': day, 'patient_ids': [p['id'] for p in forced],
                                    'mandatory_minutes': load, 'capacity_minutes': capacity, 'excess_minutes': load - capacity})
    base = {'mandatory_overtime_lower_bound_minutes': sum(c['excess_minutes'] for c in certificate),
            'certificate': certificate, 'solver_stages': []}
    if certificate:
        return {**base, 'status': 'proven_infeasible', 'method': 'fixed_day_capacity_certificate',
                'message': 'Fixed-date patients alone exceed at least one specialty/day scheduled capacity.'}
    model = build_model(instance, closed_beds, strict=True)
    solved, stage = _stage(model, 'feasibility', 1, time_limit)
    base.update({'method': 'milp_feasibility', 'solver_stages': [stage]})
    if solved.status == 2:
        return {**base, 'status': 'proven_infeasible', 'message': 'Strict-calendar feasibility model is infeasible.'}
    try:
        assignments = _decode(instance, model, solved)
        checked = verify_schedule(instance, assignments, closed_beds, strict=True) if assignments is not None else None
    except ValueError:
        checked = None
    if checked and checked['verification']['feasible']:
        return {**base, 'status': 'feasible', 'message': 'Complete schedule verified within original calendar.', 'assignments': assignments}
    return {**base, 'status': 'invalid_result' if solved.status in (0, 3) else 'unknown',
            'message': 'No verified complete strict-calendar schedule obtained.'}
