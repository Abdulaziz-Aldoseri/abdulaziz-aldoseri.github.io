"""Freeze, evaluate, independently verify and reproduce all predetermined cases."""
from pathlib import Path
import argparse
import datetime
import json
import platform
import sys
import numpy
import scipy
from prepare_data import ROOT, prepare, canonical, digest, save_json
from scheduling_model import baseline, solve, strict_calendar, verify_schedule

VERSION = '1.0.0'
SOURCE = {'title': 'Data for Generating balanced workload allocations in hospitals', 'creator': 'Pieter Smet',
          'credit': 'Pieter Smet (2023), Mendeley Data version 1, CC BY 4.0. Generated benchmark based on one Belgian hospital.',
          'url': 'https://data.mendeley.com/datasets/3mv4rtxtfs/1', 'doi': '10.17632/3mv4rtxtfs.1',
          'license': 'CC BY 4.0', 'license_url': 'https://creativecommons.org/licenses/by/4.0/', 'kind': 'generated benchmark'}


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def protocol():
    return {'version': VERSION, 'project_id': 'healthcare-scheduling', 'state': 'frozen_before_native_evaluation',
            'date': '2026-09-15', 'seeds': [0, 1, 2, 3, 4], 'm': [0, 1, 2, 3], 'closed_beds_per_ward': [0, 1],
            'case_count': 40, 'selection': 'First five numeric source generator seeds; all native patients and four compatibility variants. No result-driven selection.',
            'default_case': {'id': 's0m0b0', 'policy': 'delay_first'}, 'source': SOURCE,
            'objective_order': {'delay_first': ['delay_days', 'overtime_minutes'], 'overtime_first': ['overtime_minutes', 'delay_days']},
            'objective_semantics': 'Two lexicographic endpoint priorities; not a complete Pareto frontier; no workload/staff objective.',
            'patient_requirements': 'Original specialty, admission window, LOS and integer surgery minutes unchanged. Surgery occurs on admission day. No individual urgency flag or procedure ID supplied.',
            'occupancy': 'Patient admitted a occupies a<=d<a+LOS. Source days0..6 cover all complete new-patient stays. Fixed carryover is aggregate ward/day census and remains within supplied seven days; later carryover discharge is unknown.',
            'capacities': 'Hard ward beds, reduced by zero or one bed in each ward for all seven days. Fixed calendar soft excess independently recomputed as max(0,used-scheduled). No room/staff/within-day feasibility claim.',
            'calendar_diagnostic': 'Strict original capacity; fixed-date mandatory load certificate first, otherwise zero-objective MILP. No cohort removal.',
            'baseline': {'patient_order': 'latest, earliest, source row order; parser verifies row order equals numeric patient suffix',
                         'placement_order': 'earliest day, major ward first, source ward order', 'node_limit': 100000,
                         'time_limit_seconds': 60, 'algorithm': 'depth-first insertion/backtracking; first complete schedule; forward-check individual remaining placements'},
            'solver': {'library': 'scipy.optimize.milp/HiGHS', 'scipy': scipy.__version__, 'numpy': numpy.__version__,
                       'stage_time_limit_seconds': 60, 'presolve': True, 'mip_rel_gap': 0.0, 'integrality_tolerance': 1e-6,
                       'stage_gate': 'Secondary stage only after proven primary optimum; exact primary value locked; incomplete status preserved.'},
            'review_gate': {'reviews': ['root-protocol-review.md', 'protocol-calendar-review.md', 'SOURCE_FINDINGS.md'],
                            'closed_before_evaluation': ['aggregate carryover with unknown later discharge', 'source-order wards/numeric-suffix patients',
                            'complete native seven-day new stays', 'integer minutes and native codes', 'no urgency/procedure/staff claims',
                            'audited full corpus57–162; selected counts117,102,142,113,118', 'native M eligibility containment verified']},
            'evaluation': 'All40cases, baseline and both endpoints and strict diagnostic. No heldout predictive evaluation; generated deterministic benchmark. All failures/ties/adverse comparisons retained.',
            'publication_state_at_freeze': 'private local preparation; no published healthcare results'}


def freeze(root=ROOT):
    if (root / 'FREEZE.json').exists():
        verify_freeze(root)
        return load(root / 'FREEZE.json')
    prepare(root)
    save_json(root / 'PROTOCOL.json', protocol())
    paths = ['PROTOCOL.json', 'prepare_data.py', 'scheduling_model.py', 'pipeline.py', 'requirements.txt', 'source_manifest.json', 'DATA_PREPARATION.json',
             'tests/test_scheduling_model.py', 'tests/test_prepare_data.py', 'data/manifest.json']
    paths += [x['file'] for x in load(root / 'data/manifest.json')['instances']]
    paths += [x['path'] for x in load(root / 'source_manifest.json')['allowlisted_source_files']]
    record = {'version': VERSION, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'python': platform.python_version(), 'numpy': numpy.__version__, 'scipy': scipy.__version__,
              'files': {p: digest((root / p).read_bytes()) for p in sorted(paths)},
              'source_files': {x['source']: x['source_sha256'] for x in load(root / 'data/manifest.json')['instances']}}
    save_json(root / 'FREEZE.json', record)
    return record


def verify_freeze(root=ROOT):
    frozen = load(root / 'FREEZE.json')
    for relative, expected in frozen['files'].items():
        if digest((root / relative).read_bytes()) != expected:
            raise ValueError('Frozen artifact differs: ' + relative)
    if scipy.__version__ != frozen['scipy'] or numpy.__version__ != frozen['numpy']:
        raise ValueError('Pinned numerical dependency version differs')
    return frozen


def case_result(instance, closure):
    params = {'seed': instance['seed'], 'm': instance['m'], 'closed_beds': closure}
    return {'id': f's{instance["seed"]}m{instance["m"]}b{closure}', 'parameters': params,
            'input_sha256': digest(canonical({'instance': instance, 'parameters': params})), 'instance': instance,
            'schedules': {'baseline': baseline(instance, closure), 'delay_first': solve(instance, closure, 'delay_first'),
                          'overtime_first': solve(instance, closure, 'overtime_first')},
            'strict_calendar': strict_calendar(instance, closure)}


def verify_case(case):
    instance, closure = case['instance'], case['parameters']['closed_beds']
    errors = []
    if case['input_sha256'] != digest(canonical({'instance': instance, 'parameters': case['parameters']})):
        errors.append('Case input hash differs')
    for name, r in case['schedules'].items():
        if r['assignments'] is None:
            if any(r[k] is not None for k in ('metrics', 'occupancy', 'or_minutes')):
                errors.append(name + ': output retained without assignment')
            if r['status'] in ('verified_baseline', 'lexicographic_optimal', 'primary_optimal_secondary_unresolved', 'feasible_incumbent_primary_unresolved'):
                errors.append(name + ': feasible status without assignment')
            continue
        checked = verify_schedule(instance, r['assignments'], closure)
        if not checked['verification']['feasible']:
            errors.append(name + ': ' + str(checked['verification']['errors']))
        for field in ('metrics', 'occupancy', 'or_minutes'):
            if checked[field] != r[field]: errors.append(name + ': inconsistent ' + field)
        if digest(canonical(r['assignments'])) != r['assignment_sha256']:
            errors.append(name + ': assignment hash differs')
        if r['status'] == 'lexicographic_optimal' and (len(r['solver_stages']) != 2 or any(s['status'] != 0 or not s['optimal'] for s in r['solver_stages'])):
            errors.append(name + ': false lexicographic status')
    strict = case['strict_calendar']
    expected = strict_calendar(instance, closure) if strict['method'] == 'fixed_day_capacity_certificate' else None
    if expected is not None and expected != strict:
        errors.append('Strict-calendar certificate differs')
    policies = case['schedules']
    b = policies['baseline']
    for name, primary, secondary in [('delay_first', 'delay_days', 'overtime_minutes'), ('overtime_first', 'overtime_minutes', 'delay_days')]:
        r = policies[name]
        if r['status'] == 'lexicographic_optimal' and b['metrics'] is not None:
            if (r['metrics'][primary], r['metrics'][secondary]) > (b['metrics'][primary], b['metrics'][secondary]):
                errors.append(name + ': proven optimum worse than feasible baseline')
    return errors


def verify_outputs(output_dir, root=ROOT):
    cases, errors = [], []
    expected = [f's{s}m{m}b{b}' for s in range(5) for m in range(4) for b in range(2)]
    found = sorted(p.stem for p in (output_dir / 'cases').glob('*.json'))
    if sorted(expected) != found:
        errors.append('Complete40case roster differs')
    for identifier in expected:
        path = output_dir / 'cases' / (identifier + '.json')
        if not path.exists(): continue
        case = load(path)
        errors.extend(identifier + ': ' + err for err in verify_case(case))
        cases.append(case)
    byid = {x['id']: x for x in cases}
    comparisons = 0
    for case in cases:
        p = case['parameters']
        for other_id in ([f's{p["seed"]}m{p["m"]}b1'] if p['closed_beds'] == 0 else []):
            other = byid.get(other_id)
            if other:
                for policy, primary in [('delay_first', 'delay_days'), ('overtime_first', 'overtime_minutes')]:
                    a, b = case['schedules'][policy], other['schedules'][policy]
                    if a['status'] == b['status'] == 'lexicographic_optimal':
                        comparisons += 1
                        if a['metrics'][primary] > b['metrics'][primary]: errors.append('Bed closure monotonicity violated: ' + other_id)
        if p['m'] < 3:
            other = byid.get(f's{p["seed"]}m{p["m"] + 1}b{p["closed_beds"]}')
            if other:
                containment = all(set([w['major'], *w['minors']]) <= set([ow['major'], *ow['minors']]) for w, ow in zip(case['instance']['wards'], other['instance']['wards']))
                if not containment: errors.append('Native eligibility containment differs')
                for policy, primary in [('delay_first', 'delay_days'), ('overtime_first', 'overtime_minutes')]:
                    a, b = case['schedules'][policy], other['schedules'][policy]
                    if containment and a['status'] == b['status'] == 'lexicographic_optimal':
                        comparisons += 1
                        if a['metrics'][primary] < b['metrics'][primary]: errors.append('Eligibility monotonicity violated: ' + other['id'])
    report = {'status': 'pass' if not errors else 'fail', 'cases': len(cases), 'monotonicity_comparisons': comparisons,
              'errors': errors, 'counts': {policy: {status: sum(x['schedules'][policy]['status'] == status for x in cases)
                          for status in sorted({x['schedules'][policy]['status'] for x in cases})} for policy in ('baseline', 'delay_first', 'overtime_first')}}
    save_json(output_dir / 'evaluation_verification.json', report)
    if errors: raise ValueError(json.dumps(report))
    return report


def evaluate(output_dir=None, root=ROOT):
    verify_freeze(root)
    output_dir = Path(output_dir) if output_dir else root / 'outputs'
    if (output_dir / 'overview.json').exists():
        raise ValueError('Refusing to overwrite completed evaluation; choose a new output directory')
    entries = load(root / 'data/manifest.json')['instances']
    cases, scenarios = [], []
    for entry in entries:
        instance = load(root / entry['file'])
        for closure in (0, 1):
            case = case_result(instance, closure)
            errors = verify_case(case)
            if errors: raise ValueError(case['id'] + str(errors))
            path = output_dir / 'cases' / (case['id'] + '.json')
            save_json(path, case)
            cases.append(case)
            scenarios.append({'id': case['id'], **case['parameters'], 'sha256': digest(path.read_bytes()),
                              'summaries': {key: {k: value[k] for k in ('status', 'metrics', 'verification')} for key, value in case['schedules'].items()},
                              'strict_calendar': case['strict_calendar']})
            print(json.dumps({'case': case['id'], 'policies': {k: {'status': v['status'], 'metrics': v['metrics']} for k, v in case['schedules'].items()}}), flush=True)
    overview = {'version': VERSION, 'source': SOURCE, 'cohorts': [{'seed': seed, 'label': f'Generated cohort {seed}',
                'patient_count': len(next(c for c in cases if c['parameters']['seed'] == seed)['instance']['patients'])} for seed in range(5)],
                'scenarios': scenarios, 'default_case': next(c for c in cases if c['id'] == 's0m0b0'), 'default_policy': 'delay_first'}
    save_json(output_dir / 'overview.json', overview)
    report = verify_outputs(output_dir, root)
    verify_freeze(root)
    return report


def reproduce(output_dir, root=ROOT):
    output_dir = Path(output_dir)
    if output_dir.resolve() == (root / 'outputs').resolve():
        raise ValueError('Reproduction needs a fresh output directory')
    report = evaluate(output_dir, root)
    differences = []
    for path in sorted((root / 'outputs/cases').glob('*.json')):
        original, current = load(path), load(output_dir / 'cases' / path.name)
        for policy, result in original['schedules'].items():
            rerun = current['schedules'][policy]
            if result['status'] != rerun['status']:
                differences.append(path.stem + '/' + policy + ': status differs')
            if result['metrics'] is not None and rerun['metrics'] is not None:
                for field in ('delay_days', 'overtime_minutes'):
                    if result['metrics'][field] != rerun['metrics'][field]: differences.append(path.stem + '/' + policy + ': objective differs')
    comparison = {'status': 'pass' if not differences else 'fail', 'compared_cases': 40, 'differences': differences,
                  'comparison': 'Primary/secondary objectives and status; complete independent feasibility. Alternate optimal assignments/descriptive secondary metrics and runtime may differ.'}
    save_json(output_dir / 'reproduction_comparison.json', comparison)
    if differences: raise ValueError(json.dumps(comparison))
    return comparison


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['freeze', 'evaluate', 'verify', 'reproduce'])
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    if args.command == 'freeze': answer = freeze()
    elif args.command == 'evaluate': answer = evaluate(args.output_dir)
    elif args.command == 'verify': verify_freeze(); answer = verify_outputs(args.output_dir or ROOT / 'outputs')
    else:
        if args.output_dir is None: parser.error('reproduce requires --output-dir')
        answer = reproduce(args.output_dir)
    print(json.dumps(answer, indent=2))
