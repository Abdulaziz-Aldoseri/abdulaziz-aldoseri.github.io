"""Strict preparation of whole, preselected public healthcare benchmark instances."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SEEDS = list(range(5))
VARIANTS = list(range(4))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def parse_native(path):
    """Map README fields; omit workload and source cost weights from this new model."""
    raw = path.read_bytes()
    lines = raw.decode('utf-8').splitlines()
    cursor = 0

    def scalar(expected):
        nonlocal cursor
        if cursor >= len(lines):
            raise ValueError('Missing header: ' + expected)
        parts = lines[cursor].split(':', 1)
        cursor += 1
        if len(parts) != 2 or parts[0] != expected:
            raise ValueError('Unexpected header: ' + repr(parts))
        return int(parts[1].strip())

    def row(count):
        nonlocal cursor
        values = lines[cursor].split()
        cursor += 1
        if len(values) != count:
            raise ValueError('Wrong field count')
        return values

    seed, m = scalar('Seed'), scalar('M')
    weights = [scalar(k) for k in ('Weight_overtime', 'Weight_undertime', 'Weight_delay')]
    days, ns = scalar('Days'), scalar('Specialisms')
    specialties = []
    for _ in range(ns):
        values = row(3)
        float(values[1])  # documented unused workload scale, still check parseability
        specialties.append({'id': values[0], 'minutes': [int(x) for x in values[2].split(';')]})
    wards = []
    for _ in range(scalar('Wards')):
        values = row(7)
        float(values[2])
        workloads = [float(x) for x in values[6].split(';')]
        if len(workloads) != days:
            raise ValueError('Carryover workload length differs from day count')
        wards.append({'id': values[0], 'capacity': int(values[1]), 'major': values[3],
                      'minors': [] if values[4] == 'NONE' else values[4].split(';'),
                      'carryover': [int(x) for x in values[5].split(';')]})
    patients = []
    for ordinal in range(scalar('Patients')):
        values = row(7)
        if values[0] != f'patient{ordinal}':
            raise ValueError('Native patient row order is not numeric suffix order')
        workloads = [float(x) for x in values[6].split(';')]
        p = {'id': values[0], 'specialty': values[1], 'earliest': int(values[2]),
             'latest': int(values[3]), 'los': int(values[4]), 'duration': int(values[5])}
        if len(workloads) != p['los']:
            raise ValueError('Patient workload length differs from LOS')
        patients.append(p)
    if any(line.strip() for line in lines[cursor:]):
        raise ValueError('Unexpected trailing content')
    instance = {'seed': seed, 'm': m, 'source': path.name, 'sha256': digest(raw),
                'days': days, 'wards': wards, 'specialties': specialties, 'patients': patients}
    validate_instance(instance)
    if days != 7 or len(wards) != 4 or len(specialties) != 4 or m not in VARIANTS:
        raise ValueError('Unexpected native dimensions')
    if path.name != f's{seed}m{m}.dat' or any(len(w['minors']) != m for w in wards):
        raise ValueError('Instance identifiers/compatibility do not reconcile')
    return instance


def validate_instance(instance):
    """Domain validation shared by construction and independently decoded checks."""
    days = instance['days']
    if type(days) is not int or days < 1:
        raise ValueError('Invalid day count')
    for collection in ('wards', 'specialties', 'patients'):
        ids = [item['id'] for item in instance[collection]]
        if len(ids) != len(set(ids)) or any(not isinstance(x, str) or not x for x in ids):
            raise ValueError('Invalid or duplicate ' + collection + ' IDs')
    specs = {s['id'] for s in instance['specialties']}
    if not instance['wards'] or not specs:
        raise ValueError('Missing wards or specialties')
    for s in instance['specialties']:
        if len(s['minutes']) != days or any(type(q) is not int or q < 0 for q in s['minutes']):
            raise ValueError('Invalid/missing exact surgery calendar')
    for w in instance['wards']:
        if type(w['capacity']) is not int or w['capacity'] < 0:
            raise ValueError('Invalid ward capacity')
        if len(w['carryover']) != days or any(type(x) is not int or x < 0 for x in w['carryover']):
            raise ValueError('Invalid carryover series')
        if w['major'] not in specs or not set(w['minors']) <= specs or w['major'] in w['minors'] or len(w['minors']) != len(set(w['minors'])):
            raise ValueError('Invalid specialty eligibility')
    for p in instance['patients']:
        if p['specialty'] not in specs:
            raise ValueError('Unknown patient specialty')
        if any(type(p[k]) is not int for k in ('earliest', 'latest', 'los', 'duration')):
            raise ValueError('Noninteger native time input')
        if not (0 <= p['earliest'] <= p['latest'] < days and p['los'] >= 1 and p['duration'] > 0):
            raise ValueError('Invalid patient times')
        if p['latest'] + p['los'] > days:
            raise ValueError('Full stay outside supplied occupancy horizon; do not truncate')


def prepare(root=ROOT):
    register = json.loads((root / 'source_manifest.json').read_text(encoding='utf-8'))
    published = {Path(x['path']).name: x['sha256'] for x in register['allowlisted_source_files']}
    manifest, prepared = [], []
    for seed in SEEDS:
        for m in VARIANTS:
            name = f's{seed}m{m}.dat'
            instance = parse_native(root / 'sources/original/instances' / name)
            if instance['sha256'] != published[name]:
                raise ValueError('Source publisher hash mismatch: ' + name)
            out = root / 'data/instances' / f's{seed}m{m}.json'
            save_json(out, instance)
            manifest.append({'file': str(out.relative_to(root)).replace('\\', '/'),
                             'source': name, 'source_sha256': instance['sha256'],
                             'sha256': digest(out.read_bytes()), 'seed': seed, 'm': m,
                             'patients': len(instance['patients']), 'days': instance['days']})
            prepared.append(instance)
    for seed in SEEDS:
        variants = [x for x in prepared if x['seed'] == seed]
        ref = variants[0]
        for item in variants[1:]:
            if item['patients'] != ref['patients'] or item['specialties'] != ref['specialties']:
                raise ValueError('Noncompatibility variant inputs differ')
            for w, rw in zip(item['wards'], ref['wards']):
                if {k: v for k, v in w.items() if k != 'minors'} != {k: v for k, v in rw.items() if k != 'minors'}:
                    raise ValueError('Native ward capacities or carryover differ across variants')
        for previous, current in zip(variants, variants[1:]):
            if any(not set(w['minors']) <= set(cw['minors']) for w, cw in zip(previous['wards'], current['wards'])):
                raise ValueError('Selected native eligibility sets are not nested')
    save_json(root / 'data/manifest.json', {'version': '1.0.0', 'instances': manifest})
    save_json(root / 'DATA_PREPARATION.json', {
        'status': 'pass', 'selection': {'numeric_seeds': SEEDS, 'm': VARIANTS},
        'native_instances': len(prepared), 'rows_excluded': 0, 'new_patients_per_cohort': [len(x['patients']) for x in prepared if x['m'] == 0],
        'carryover': 'Source aggregate ward/day occupancy preserved exactly; individual identities unavailable.',
        'days': 'Source 0..6; full stays all fit. No clipping or tail extension.',
        'time_units': 'Source integer surgery minutes and integer days preserved exactly.',
        'unused_fields': ['source objective weights', 'patient workload profiles', 'ward workload capacities', 'minor-specialty workload multipliers', 'carryover workload'],
        'unused_fields_reason': 'This study optimizes admission timing and calendar excess, not workload balance.',
        'no_clinical_priority': 'No individual urgency flag or procedure identifier is supplied; none inferred.',
        'native_eligibility_nested': True,
        'public_source_manifest_sha256': digest((root / 'source_manifest.json').read_bytes())})
    return manifest


if __name__ == '__main__':
    print(json.dumps({'prepared_instances': len(prepare())}))
