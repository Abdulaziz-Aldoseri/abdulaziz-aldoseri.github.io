"""Execute every scientific notebook code cell from a fresh, verified archive.

This is a local Python execution check, not a hosted Colab or Jupyter UI test.
The default validates all frozen schedules and executes implementation tests;
--rerun also requests the notebook's optional full-grid reproduction.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from notebook_setup import safe_extract_package, verify_package


ROOT = Path(__file__).resolve().parent
NOTEBOOK = "healthcare_scheduling.ipynb"
ARCHIVE = "healthcare-scheduling-reproducibility.zip"


def verify(rerun: bool = False) -> dict:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    folder = ROOT / "outputs" / "verification" / stamp
    folder.mkdir(parents=True, exist_ok=False)
    archive = ROOT / "outputs" / "downloads" / ARCHIVE
    original_archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    extracted = safe_extract_package(archive, folder / "extracted")
    entries = verify_package(extracted)
    notebook = json.loads((extracted / NOTEBOOK).read_text(encoding="utf-8"))
    code_cells = [c for c in notebook["cells"] if c["cell_type"] == "code"]
    if not code_cells or any(c.get("execution_count") is not None or c.get("outputs") != [] for c in code_cells):
        raise ValueError("Public notebook must contain unexecuted code cells with empty outputs")

    # Test the actual released setup cell against a source-like directory that
    # lacks the required manifest. No project module may execute in that case.
    unverified = folder / "unverified"
    unverified.mkdir()
    for module in extracted.glob("*.py"):
        (unverified / module.name).write_text("raise AssertionError('Unverified study import executed')\n", encoding="utf-8")
    notebook_path = (extracted / NOTEBOOK).resolve()
    missing_check = r'''
import json,sys
from pathlib import Path
notebook=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
namespace={"__name__":"__main__"}
def source(cell):
    value=cell["source"]
    return "".join(value) if isinstance(value,list) else value
exec(compile(source(notebook["cells"][2]),"notebook-helper","exec"),namespace)
try:
    exec(compile(source(notebook["cells"][3]),"unverified-notebook-setup","exec"),namespace)
except (ValueError,FileNotFoundError) as error:
    if "manifest" not in str(error).lower():
        raise AssertionError("Setup failed for an unexpected reason") from error
else:
    raise AssertionError("A directory without a package manifest was accepted")
print("Missing manifest rejected before study imports.")
'''
    checked = subprocess.run(
        [sys.executable, "-X", "utf8", "-c", missing_check, str(notebook_path)],
        cwd=unverified, text=True, capture_output=True, timeout=60,
    )
    (folder / "missing-manifest-stdout.txt").write_text(checked.stdout, encoding="utf-8")
    (folder / "missing-manifest-stderr.txt").write_text(checked.stderr, encoding="utf-8")
    if checked.returncode:
        raise RuntimeError("Missing-manifest setup guard failed; see verification logs")

    script = r'''
from pathlib import Path
import json,sys,time
notebook=json.loads(Path("healthcare_scheduling.ipynb").read_text(encoding="utf-8"))
namespace={"__name__":"__main__","RERUN_FULL_GRID":sys.argv[1]=="true"}
executed=[]
for index,cell in enumerate(notebook["cells"]):
    if cell["cell_type"]!="code":
        continue
    source=cell["source"]
    if isinstance(source,list):
        source="".join(source)
    began=time.perf_counter()
    exec(compile(source,f"healthcare_scheduling.ipynb:cell-{index}","exec"),namespace)
    executed.append({"cell":index,"seconds":round(time.perf_counter()-began,3)})
report={
    "status":"PASS",
    "executed_cells":executed,
    "frozen_evidence_check":namespace["evidence_check"],
    "full_grid_rerun_requested":namespace["RERUN_FULL_GRID"],
    "full_grid_reproduction_check":namespace.get("reproduction_check"),
}
Path("notebook-execution.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
'''
    result = subprocess.run(
        [sys.executable, "-X", "utf8", "-c", script, str(rerun).lower()],
        cwd=extracted, text=True, capture_output=True,
    )
    (folder / "stdout.txt").write_text(result.stdout, encoding="utf-8")
    (folder / "stderr.txt").write_text(result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError("Notebook code-cell execution failed; see verification logs")
    execution = json.loads((extracted / "notebook-execution.json").read_text(encoding="utf-8"))
    if len(execution["executed_cells"]) != len(code_cells):
        raise ValueError("Not all notebook code cells were executed")
    verify_package(extracted)
    if hashlib.sha256(archive.read_bytes()).hexdigest() != original_archive_hash:
        raise ValueError("Original reproduction package changed during verification")
    report = {
        "status": "PASS",
        "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "archive": ARCHIVE,
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": original_archive_hash,
        "notebook_sha256": hashlib.sha256((extracted / NOTEBOOK).read_bytes()).hexdigest(),
        "manifest_members": len(entries),
        "execution_mode": "Every actual code cell executed sequentially in a fresh local Python process from a strictly verified ZIP extraction; not a hosted Colab or Jupyter UI test",
        "public_notebook_outputs_empty": True,
        "missing_manifest_rejected_before_study_import": True,
        "original_package_unchanged": True,
        "execution": execution,
        "evidence_directory": folder.relative_to(ROOT).as_posix(),
    }
    (ROOT / "outputs" / "notebook_verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rerun", action="store_true", help="Also solve and compare the complete 40-case grid in a new directory")
    options = parser.parse_args()
    print(json.dumps(verify(options.rerun), indent=2))
