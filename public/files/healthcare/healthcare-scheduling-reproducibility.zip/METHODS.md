# Admission timing and recovery-bed scheduling

Independent deterministic benchmark study, evidence version 1.0.0. The model and 40-case grid were frozen before native evaluation. `PROTOCOL.json`, `FREEZE.json`, `source_manifest.json` and `DATA_PREPARATION.json` define the admitted inputs, choices and transformations.

## What the planner chooses

For every new patient, choose one admission day in the supplied window and one ward supporting the supplied specialty. Surgery takes place on that admission day. All patients must be scheduled. Each assigned patient occupies one bed on every day `admission <= day < admission + LOS`, without transfers. Integer surgery duration, LOS, specialty and admission-window requirements remain exactly as supplied. Carryover is the source's aggregate occupied-bed census for each ward/day; individual preexisting-patient identities and later discharges are unavailable.

The published source comprises generated benchmark instances informed by one Belgian hospital. The evaluated sample is the five smallest numeric generator seeds, 0–4, with all four native compatibility variants. Those seeds contain 117, 102, 142, 113 and 118 new patients. The archive-wide patient range is 57–162; the early preprint gives a different range. The preserved files govern this reproduction.

Every native day is represented: indices 0–6, displayed as relative Day 1–Day 7. All admissible new-patient stays end inside that horizon. We add no dates, weekends, arrivals, recovery tail or post-horizon carryover discharge assumptions. Fixed-date patients are not labelled urgent: the data contain no individual urgency flag or procedure identity.

## Resources and objectives

Ward bed capacity is hard. The two predefined bed scenarios retain the source capacity or close one bed in **each** of four wards throughout the seven days. Existing patients cannot be evicted or rescheduled. The original specialty/day surgery calendar stays fixed. Calendar excess is `max(0, assigned minutes - scheduled minutes)` summed across cells. It is an additional capacity requirement, not a claim that extra rooms, surgeons, nurses or safe overtime are available.

The binary variable `x[p,w,a]` selects patient `p`, ward `w` and admission day `a`. Exactly one admissible variable is selected per patient. Each ward/day census is the fixed carryover plus every selected stay covering that day. Each specialty/day surgery load sums the source durations of admissions on that day. Nonnegative excess variables exceed the difference between load and source calendar capacity. Excess variables have finite bounds; complete assignments and objectives are recomputed independently after each solve.

Two lexicographic priorities use identical information and constraints:

1. **Earlier admission:** minimize summed admission-delay patient-days, lock the proven integer optimum, then minimize calendar excess minutes.
2. **Less excess surgery time:** minimize calendar excess minutes, lock the proven integer optimum, then minimize total admission-delay patient-days.

These are two endpoint choices, not a complete Pareto frontier. Units remain separate. Neither objective includes clinical weights, staffing/workload equity, major/minor placement quality or within-day room sequencing. Ward/specialty labels remain source codes. Several schedules can share the same objective pair; ward placement, individual delays and peak occupancy can vary among tied optima. The website presents one frozen verified schedule, not a unique clinically preferred plan.

## Baseline and feasibility diagnostic

The baseline sorts patients by latest date, earliest date and original row order. Native row order is verified to equal ascending numeric `patientN` suffix. It tries dates earliest first and eligible wards in major-specialty-first/source-ward order. Bed-feasible placement uses every occupied day. Deterministic depth-first backtracking finds the first complete schedule; a forward check rejects branches where a remaining patient has no individually feasible placement. It stops at 100,000 attempted placements or a 60-second safeguard. It never optimizes either objective.

Only a complete verified baseline is compared. Search-limit/time-limit means unavailable; complete exhaustion or fixed carryover beyond capacity can establish baseline infeasibility. No partial baseline is scored. All failed baselines remain in the 40-case evidence table.

A separate diagnostic makes the source surgery calendar hard. It first sums fixed-date patient minutes in every specialty/day cell. Any mandatory load above that cell's capacity proves strict-calendar infeasibility. The certificate stores patient IDs, day, specialty, mandatory minutes, calendar minutes and excess. If there is no direct certificate, an otherwise identical zero-objective MILP tests strict-calendar feasibility. Limits without a verified complete incumbent are unknown. This diagnostic never changes patients or deletes infeasible cases from the study.

Every selected native calendar cell is positive. The code also handles a zero-calendar cell as an additional-session requirement and tests that behavior on constructed fixtures; that event does not occur in the native evaluated sample.

## Solution verification and reproduction

SciPy 1.16.3/HiGHS solves the binary model with NumPy 2.3.5. Each stage has an explicit 60-second limit, presolve enabled and requested relative MIP gap zero. Stage records retain raw status, message, incumbent objective, dual bound, gap, nodes and runtime. Secondary optimization runs only after a proven primary optimum. Independent reconstruction checks integrality within `1e-6`, patient completeness, windows, eligibility, every bed census, exact integer surgery minutes and objective equality. Secondary failure retains a verified primary solution with an unresolved status; contradictory or malformed solver output cannot become a claimed optimal schedule.

Before native evaluation, the test suite covered independent Cartesian enumeration of small endpoint objectives, a true timing/excess trade-off, backtracking, occupancy boundaries, carryover, final-day recovery, empty cohorts, strict-calendar and hard-bed infeasibility, zero calendar, duplicate/missing/malformed inputs, fractional decisions and simulated multi-stage failures. The initial 22 tests passed. The full evaluation verifies all 40 cases, exact baseline comparisons and 74 applicable monotonicity comparisons: removing beds cannot improve a proven primary objective, and adding eligible wards cannot worsen it when containment is verified.

The notebook/package contains all 20 selected original `.dat` files, the source README, prepared inputs, complete results, frozen protocol/code/environment, tests and source attribution. `python prepare_data.py` rebuilds admitted inputs from these local source files. `python pipeline.py verify` validates frozen inputs/code and complete result arithmetic. `python pipeline.py reproduce --output-dir new-output-directory` repeats the complete 40-case evaluation without overwriting frozen output, comparing objective pairs and statuses while checking every returned schedule. Alternative optimal assignment fingerprints are reported separately. A locally executed notebook is not evidence of a hosted Colab execution.

## Interpretation limits

This is a static, deterministic sample of five benchmark cohorts, not a representative estimate across the full collection or a hospital population. There is no forecasting train/test split and no claim of prospective prediction, real patient benefit, clinical prioritization, safe staffing, executable surgery timetables, cost savings or deployment. Capacity scenarios are hypothetical. The model demonstrates how exact patient timing and full recovery-bed occupancy constrain choices, and why lower excess surgery time can require longer admission delays.

Source: Pieter Smet (2023), [Mendeley Data v1, DOI 10.17632/3mv4rtxtfs.1](https://data.mendeley.com/datasets/3mv4rtxtfs/1), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The [associated paper](https://optimization-online.org/wp-content/uploads/2023/01/balancing-static.pdf) supplies the original problem context; this adaptation does not reproduce its workload-balance analysis.
