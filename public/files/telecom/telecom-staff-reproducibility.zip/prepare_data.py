"""Verify immutable raw FCC pages and produce daily/weekly non-identifying counts."""
from __future__ import annotations
import collections
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    protocol = json.loads((ROOT / "PROTOCOL.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "source_manifest.json").read_text(encoding="utf-8"))
    if manifest["license_id"] != "USGOV_WORKS" or not manifest["same_metadata_version_before_and_after"]:
        raise ValueError("Source admission failure")
    for item in manifest["files"]:
        path = ROOT / "source" / item["file"]
        if path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise ValueError(f"Source bytes changed: {path.name}")
    start = dt.date.fromisoformat(protocol["calendar"]["training"]["start"])
    end = dt.date.fromisoformat(protocol["calendar"]["test"]["end_exclusive"])
    map_issue = {issue: q["id"] for q in protocol["queues"] for issue in q["issues"]}
    excluded = set(protocol["exclusions"]["issues"])
    seen: dict[str, tuple] = {}
    daily = collections.Counter()
    raw_daily = collections.Counter()
    counts = collections.Counter()
    issue_counts = collections.Counter()
    page_counts = {}
    for item in manifest["files"]:
        if not item["file"].endswith(".csv"):
            continue
        count = 0
        previous = None
        with (ROOT / "source" / item["file"]).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            expected = {"id", "ticket_created", "issue_type", "issue"}
            if set(reader.fieldnames or []) != expected:
                raise ValueError(f"Unexpected field schema {reader.fieldnames}")
            for row in reader:
                count += 1
                counts["raw_rows"] += 1
                if not row["id"] or not row["ticket_created"] or row["issue_type"] not in ("Phone", "Internet"):
                    raise ValueError("Missing required source field")
                stamp = dt.datetime.fromisoformat(row["ticket_created"].replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    raise ValueError("Fixed timestamp lost timezone")
                stamp = stamp.astimezone(dt.timezone.utc)
                day = stamp.date()
                if not start <= day < end:
                    raise ValueError("Date outside frozen window")
                key = (stamp, int(row["id"]))
                if previous is not None and key < previous:
                    raise ValueError("Page is not deterministically ordered")
                previous = key
                signature = tuple(row[k] for k in ("ticket_created", "issue_type", "issue"))
                if row["id"] in seen:
                    if seen[row["id"]] != signature:
                        raise ValueError("Conflicting duplicate ticket ID")
                    counts["exact_duplicate_rows"] += 1
                    continue
                seen[row["id"]] = signature
                raw_daily[day] += 1
                issue = row["issue"]
                issue_counts[(row["issue_type"], issue)] += 1
                if not issue:
                    counts["unclassified_excluded"] += 1
                    continue
                if issue in excluded:
                    counts[f"excluded_{issue}"] += 1
                    continue
                if issue not in map_issue:
                    raise ValueError(f"Unknown nonempty issue label: {issue}")
                daily[(day, map_issue[issue])] += 1
                counts["eligible_rows"] += 1
        if count >= 50000:
            raise ValueError("API page hit its query limit; pagination needed")
        page_counts[item["file"]] = count
    control = json.loads((ROOT / "source/fcc-exact-window-counts.json").read_text())[0]
    if int(control["records"]) != counts["raw_rows"] or int(control["distinct_ids"]) != len(seen):
        raise ValueError("Independent FCC aggregate reconciliation failed")
    all_days = [start + dt.timedelta(days=n) for n in range((end-start).days)]
    missing_days = [d.isoformat() for d in all_days if raw_daily[d] == 0]
    if missing_days:
        raise ValueError(f"No broad-source records on dates {missing_days}; investigate, do not impute ordinary zero workload")
    out = ROOT / "data"
    out.mkdir(exist_ok=True)
    with (out / "daily_intake.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["date_utc", "queue", "complaints"])
        for day in all_days:
            for q in protocol["queues"]:
                writer.writerow([day.isoformat(), q["id"], daily[(day, q["id"])]])
    weekly = []
    with (out / "weekly_intake.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["week_start_utc", "split", *[q["id"] for q in protocol["queues"]]])
        for offset in range(0, len(all_days), 7):
            week = all_days[offset]
            split = next(k for k in ("training", "validation", "test") if protocol["calendar"][k]["start"] <= week.isoformat() < protocol["calendar"][k]["end_exclusive"])
            values = [sum(daily[(week+dt.timedelta(days=d), q["id"])] for d in range(7)) for q in protocol["queues"]]
            writer.writerow([week.isoformat(), split, *values])
            weekly.append({"week": week.isoformat(), "split": split, "intake": values})
    audit = {"status": "preparation-complete-pending-independent-review", "protocol_sha256": digest(ROOT/"PROTOCOL.json"),
             "source_manifest_sha256": digest(ROOT/"source_manifest.json"), "page_counts": page_counts,
             "counts": dict(counts), "distinct_ids": len(seen), "independent_aggregate_reconciled": True,
             "dates": len(all_days), "weeks": len(weekly), "zero_broad_source_dates": missing_days,
             "daily_broad_min": min(raw_daily.values()), "daily_broad_max": max(raw_daily.values()),
             "daily_eligible_min": min(sum(daily[(d,q["id"])] for q in protocol["queues"]) for d in all_days),
             "observed_issue_counts": [{"form": k[0], "issue": k[1], "rows": v} for k,v in sorted(issue_counts.items())],
             "by_split": {split:{"weeks":sum(w["split"]==split for w in weekly), "intake_by_queue":[sum(w["intake"][q] for w in weekly if w["split"]==split) for q in range(3)]} for split in ("training","validation","test")},
             "prepared_files": [{"file": p.name, "bytes": p.stat().st_size, "sha256": digest(p)} for p in (out/"daily_intake.csv", out/"weekly_intake.csv")]}
    (ROOT/"DATA_PREPARATION.json").write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"counts":audit["counts"],"days":len(all_days),"weeks":len(weekly),"minimum_daily_intake":audit["daily_eligible_min"],"aggregate_check":True}))


if __name__ == "__main__":
    main()
