# Telecom complaint-casework staffing

Independent project by Abdulaziz Aldoseri. This study asks where a limited hypothetical casework team should assign cross-trained staff before the next week's telecom complaint intake is known.

## Decision and evidence boundary

The observed data is consumer-submitted Phone and Internet complaint intake to the US Federal Communications Commission (FCC), not a telecom operator's contact-centre queue. The source supplies submission timestamps and issue labels. It supplies no employees, shifts, handling times, response/completion times or actual backlog. Allegations are not independently verified by FCC.

All staff pools, processing rates and skills below are hypothetical scenario assumptions. A processed case means a consumed slot in this model; it does not establish that a complaint was resolved. Backlog and age are simulated quantities. The study makes no claim about actual FCC staffing, a provider's service performance, customer satisfaction, measured waiting time or compliance with a response deadline.

## Source and preparation

Source: [Federal Communications Commission, CGB — Consumer Complaints Data](https://opendata.fcc.gov/Consumer/CGB-Consumer-Complaints-Data/3xyp-aqkj), public domain US Government work (`USGOV_WORKS`). The exact query URLs, retrieval times, source metadata version, byte counts and SHA-256 values are in `source_manifest.json`. The public package contains derived daily/weekly aggregates; original projected ticket records remain outside it.

Nine immutable source response pages select only `id`, `ticket_created`, `issue_type` and `issue`. They cover 6 January through 14 September 2025 in UTC. Two metadata reads verified a stable source update version during retrieval. Independent FCC aggregate queries reconcile the complete page count and distinct IDs. Exact duplicates are counted and removed; conflicting identifiers, unknown nonempty issue labels, absent required fields, query-limit saturation or missing broad-source dates fail preparation.

The broad source projection contains 205,892 unique Phone/Internet tickets. Exclusions are 100,600 unwanted-call records, 2,433 junk-fax records and 102 unclassified issue records. The final three-queue cohort contains 102,757 submissions across all 252 dates and 36 complete weeks. These exclusions narrow the casework question; they do not assert that other complaints have no workload.

The mapping is fixed in `PROTOCOL.json`: Billing and commercial includes billing, cramming, slamming and number portability. Service and technical includes availability, equipment, interference, speed and rural call completion. Privacy is separate. These are hypothetical workstreams, not a claim about FCC team organization. FCC's [handling explanation](https://consumercomplaints.fcc.gov/hc/en-us/articles/202752940-How-the-FCC-Handles-Your-Complaint) motivates separating billing/service casework from unwanted-call enforcement/policy intake. It does not establish labour effort.

Use the fixed `ticket_created` UTC timestamp, not the floating publisher-calendar `date_created` or consumer-reported issue date. The source has no verified historical publication lag/version history. This is a retrospective event-time replay assuming an internal planner observes submitted intake before the next decision cutoff. A later source discontinuity in October 2025 was detected during admission; it is outside the frozen January–September study window and is not interpreted as falling demand.

## Chronology and information

Training is 6 January–27 April 2025 (16 weeks), validation is 28 April–22 June (8 weeks), and held-out evaluation is 23 June–14 September (12 weeks). Weeks begin Monday 00:00 UTC and end the following Monday exclusively.

For each queue, candidate forecasts use the mean of the previous 1, 4, 8 or 13 completed calendar weeks. All required history must be present. Validation selects one window by total absolute error across eight weeks and three queues, with the smaller window breaking exact ties. Counts are represented on scale 104 so these means are exact rational values; forecasts are not rounded to whole cases before the decision. The selected window is persisted before any held-out policy run. Rolling forecasts use only earlier observations. Other held-out candidate errors are reported as diagnostics, without retuning.

At the start of a test week, each policy observes its own simulated opening backlog and the shared selected forecast. It chooses one staff allocation for that entire week. Hindsight replaces only the current week's forecast with the current week's actual intake and carries its own backlog. It is a weekly perfect-information comparison, not a globally optimal full-horizon bound.

## Staff and capacity scenarios

Let total staff be H and cross-trained share be f percent. Available cross-trained staff F = floor(H f / 100). The remaining specialists are apportioned 45%, 45% and 10% across Billing, Technical and Privacy using largest remainders, with queue order breaking ties. These percentages are scenarios rather than observed staffing proportions.

The base specialist processing rates are 60, 40 and 30 case-processing slots per staff-week respectively. Cross-trained staff work at 80% of the queue's specialist rate. A capacity multiplier m of 75%, 100% or 125% changes these rates. These values express uncertainty about available processing capacity; they are not estimated from elapsed complaint time or source records.

With dedicated count Dq and cross-trained assignment xq, whole-case queue capacity is:

`Cq = floor(baseq × m × (100 Dq + 80 xq) / 10000)`

The floor is applied once to pooled queue capacity. Thus two specialists each providing 22.5 model slots combine to 45 whole-case slots. Staff assignments are integers and sum to F. A specialist cannot cover a different queue and no person is assigned twice.

The interactive grid is H ∈ {0,24,36,48,60,72}, f ∈ {0,25,50,100}, m ∈ {75,100,125}: 72 scenarios. The fixed default is 48 staff, 25% cross-trained and 100% capacity, displayed at the first held-out week. These controls select a complete precomputed 12-week scenario trajectory.

## Objective and exact solution

For projected queue cases Nq = opening backlog + forecast intake, projected remaining cases are Rq = max(Nq − Cq, 0). The optimization compares feasible allocations lexicographically:

1. Lowest maximum Rq/Nq among queues, with empty-queue share defined as zero.
2. Lowest total projected remaining cases.
3. Fewest internal cross-trained staff reallocations from that policy's previous allocation.
4. Lexicographically smallest allocation in Billing, Technical, Privacy order.

This objective prioritizes balanced queue coverage. It may process fewer total cases than a volume-oriented staffing rule. It is not a monetary objective or an empirically estimated customer-priority weighting.

Every feasible triple x ≥ 0 with integer entries and sum F is enumerated. There are (F+1)(F+2)/2 triples. Primary ratios are compared with integer cross-products, secondary residuals remain on exact scale 104, and all further ties are deterministic. Exhaustive enumeration proves current-week optimality at that particular opening state and intake estimate. Different policies subsequently have different backlogs, so this proof implies neither cross-trajectory weekly dominance nor a globally optimal 12-week staffing plan.

Internal reallocations equal `(L1 allocation change − absolute flex-pool size change) / 2`. This is always an integer. Entrants and absences are separate counts. An absence cannot leave a baseline using more staff than are available: fixed training weights are re-apportioned to the reduced pool, and any adaptive no-need retention is re-apportioned if its prior pool size differs.

## Comparison policies

**Fixed training share:** cross-trained staff follow training complaint totals divided by the queue's base processing rate. Largest-remainder rounding makes the assignment feasible. The training weights remain fixed; an absence changes the available number apportioned.

**Adaptive workload share:** allocate cross-trained staff proportionally to the positive projected cases remaining after dedicated capacity, divided by the queue processing rate. If every queue is already covered, retain the feasible previous split; re-apportion to the available pool if needed. A zero prior pool uses training weights.

**Balanced allocation:** use the exact current-week minimax objective described above.

**Current-week hindsight:** use the same exact model and feasible staff pool with actual current-week intake. This is an unavailable-at-decision-time comparison, with no full-horizon bound claim.

## Queue replay and measures

All policies start the held-out period with zero backlog, an explicit clean-start scenario. At week end, available cases are opening backlog plus observed weekly intake. Process at most queue capacity, consuming oldest cohorts first. Remaining cohorts carry into the next week independently for each policy. Weekly pooling does not establish within-week staffing schedules or measured individual wait times.

For every queue/week: `opening backlog + observed intake = processed + ending backlog`. Across the whole period: `initial backlog + all intake = all processed + final backlog`. Final backlog is retained and reported rather than cleared by an artificial terminal action.

Measures include ending backlog, the sum of 12 weekly ending-backlog censuses, cumulative processed cases, unused model slots, worst and mean-worst realized unprocessed share, oldest remaining model cohort and internal staff reallocations. “Cumulative backlog” is a sum of weekly censuses, not a measured waiting-time quantity. Realized unprocessed share divides remaining cases by that policy's opening backlog plus actual intake. Empty queues have zero share.

Report every test week, both baseline comparisons and adverse results. The 12-week descriptive record is not a population-effect estimate. No confidence intervals, causal claims or general claims that optimization beats forecasting baselines are asserted.

## Stress and failure cases

The protocol specifies zero staff, zero intake, no flexible staff, all flexible staff, ample staff (240), persistent shortfall, removal of the technical specialist pool for all 12 weeks, one cross-trained absence on 4 August returning the following week, a doubled-intake shock on 4 August, and opening backlog equal to each queue's ceiling training mean at initial model age one week. The shock holds the original forecast path fixed and is labelled exogenous; it is not a refitted altered source series. Stress inputs and modified arrivals are separate from observed data.

Zero staff preserves all cases. Ample capacity should clear feasible cases. Missing skills expose a bottleneck unless flexible staff can cover it. Resource shortages accumulate backlog rather than being silently relaxed. These tests establish model behavior, not an actionable staffing prescription.

## Reproduction and review

`pipeline.py validate` requires an independent source/protocol gate, exact protocol/preparation/data hashes and an empty output directory. It records actual validation start/end times and saves a SHA sidecar. `pipeline.py evaluate` verifies that sidecar, recomputes the frozen validation arithmetic, checks unchanged input bytes, rejects existing completed outputs, and rechecks hashes before and after writing. A completed run has `evaluation_run.json` with artifact hashes. Use a separate `--output` directory for reproduction.

The first validation-only attempt was retained privately after independent review found weaker timestamp/overwrite guards. Those guards were corrected before any held-out evaluation. Corrected validation produced exactly the same candidate errors and selection; the held-out run used the corrected guarded version.

Tests compare the allocation with an independently implemented labelled-person assignment oracle using exact `Fraction` arithmetic, including fractional forecasts and changing staff pools. Other tests cover FIFO conservation, no future data, pooled rounding, zero resource/intake, absence and tampering/overwrite rejection. Public model/data files are manifest checked before notebook execution. Checksums detect corruption; they are not cryptographic proof of publisher identity.
