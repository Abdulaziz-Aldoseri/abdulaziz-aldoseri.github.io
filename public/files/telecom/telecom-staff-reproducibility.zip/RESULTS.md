# Telecom staffing — evaluated findings

Independent project by Abdulaziz Aldoseri. Results below are simulated staffing consequences using observed FCC telecom complaint intake and explicitly hypothetical staff capacity. They are not actual FCC staffing, complaint resolution or measured waiting-time results.

## What the experiment shows

**Balanced queue coverage comes with a throughput cost in the fixed default scenario.** Minimizing the worst queue's projected unprocessed share spreads the shortage more evenly, but it leaves more cases overall than the fixed or adaptive staffing baselines. Extra flexibility is not automatically beneficial because the scenario assumes cross-trained staff process at 80% of each specialist's rate.

The held-out record covers all 12 weeks from 23 June through 14 September 2025: 36,319 observed eligible telecom complaints. All policies begin from zero simulated backlog. The default was fixed before evaluation: 48 staff, 25% cross-trained and base processing capacity, first test week displayed.

| Default policy | Mean of weekly worst-queue unprocessed share | Ending simulated backlog | Sum of weekly backlog censuses | Maximum simulated cohort age |
| --- | ---: | ---: | ---: | ---: |
| Fixed training share | 78.19% | 10,256 | 68,765 | 5 weeks |
| Adaptive workload share | 74.50% | 10,439 | 70,010 | 4 weeks |
| Balanced allocation | 69.94% | 10,895 | 73,194 | 3 weeks |
| Current-week hindsight | 69.68% | 10,879 | 73,050 | 3 weeks |

Balanced allocation lowers the mean worst-queue share by 8.25 percentage points relative to fixed staffing and 4.56 points relative to adaptive staffing. It ends with 639 and 456 more cases respectively. Its total ending backlog is higher than both baselines in every one of the 12 weeks. These outcomes follow its fairness-oriented objective; they do not support a blanket “optimization improves service” claim.

The hindsight policy sees only that week's realized intake, carries its own backlog and is not a globally optimal 12-week bound. A sum of weekly backlog censuses is a descriptive model measure, not measured case waiting time. Differences are simulated, not causal organizational effects.

## Complete scenario grid

The evaluated grid contains 72 resource/skill/capacity settings, including zero staff: six staff counts, four cross-trained shares and three capacity multipliers. Against each baseline, balanced allocation has a higher cumulative backlog in 41 settings, a lower cumulative backlog in 4 and an equal cumulative backlog in 27. Its mean worst-queue unprocessed share is worse in 3 settings against each baseline. These counts are a grid description, not probabilities or evidence of population performance.

At base capacity and 25% cross-training, balanced ending backlog falls from 10,895 at 48 staff to 4,608 at 60 staff and zero at 72 staff. The 72-person case still has temporary within-period backlogs visible in the full weekly results. Resource sufficiency matters more than allocation alone in a persistent capacity shortfall.

With 48 staff and base capacity, no cross-training leaves 8,720 cases but has a worse mean worst-queue share of 77.84%. At 25% cross-training, ending backlog is 10,895 and that share is 69.94%. At 100% cross-training, backlog rises to 14,823 and the mean worst-queue share is 77.52%. This is the assumed flexibility/processing-rate trade-off; the 80% efficiency penalty is not an observed industry estimate.

## Forecast result and adverse evidence

Validation selected the previous-week forecast, with MAE 53.83 complaints per queue-week. Its held-out MAE is 75.92. The 8-week candidate later achieves 60.02, better than the frozen choice on test data; it is reported as a diagnostic and was not selected after seeing those outcomes. The other held-out errors are 61.76 for four weeks and 65.58 for thirteen weeks. Forecast selection did not promise held-out superiority.

The first validation-only attempt was archived after independent review requested stronger freeze guards. Corrected validation reproduced exactly the same candidate errors before the held-out run. No test-based tuning or source-window change occurred.

## Stress and limiting cases

| Fixed stress case | Balanced allocation outcome | Interpretation |
| --- | --- | --- |
| Zero staff | All 36,319 test cases remain; zero processed | Cases cannot disappear without capacity. |
| Zero intake, clean start | Zero backlog throughout | Zero denominators are handled explicitly. |
| Ample 240-person scenario | All 36,319 cases processed; zero weekly backlog | Capacity ceiling is no longer binding; this is outside the interactive grid. |
| No cross-trained staff | All policies have the same 8,720 ending cases | No adjustable staff assignments means the policies must coincide. |
| Technical specialist pool absent | 18,751 ending cases, versus 10,895 default | Flexible staff cannot erase the capacity loss. Actual available staff is reduced and reported. |
| One cross-trained absence on 4 August | 10,927 ending cases, 32 above default | The absent employee is removed from the feasible pool for one week and restored next week. |
| Doubled 4 August intake, original forecast path | 14,175 ending cases | Explicit unforecast exogenous shock, not altered observed history or a forecast refit. |
| Opening backlog equal to ceiling training means | 13,548 ending cases | Initial queues matter; no assumption of historical empty queues is inferred. |

See `outputs/weekly_results.csv`, `scenario_results.csv` and `stress_results.json` for every policy and period. Constraints, integer assignments, FIFO conservation and exact current-week comparisons are independently tested. These checks support the stated model, not an actionable workforce prescription.

Source: [Federal Communications Commission, CGB — Consumer Complaints Data](https://opendata.fcc.gov/Consumer/CGB-Consumer-Complaints-Data/3xyp-aqkj), public domain US Government work. The source is consumer-selected regulator intake; FCC does not independently verify the allegations. Staff, skill eligibility, processing rates and all backlog outputs are scenario/model quantities.
