"""Compare fresh analytical outputs while allowing honest new run timestamps/provenance hashes."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def analytical_payload(value):
    value=copy.deepcopy(value)
    summary=value["evaluationSummary"]
    summary.pop("input_sha256",None)
    summary.pop("validation_sha256",None)
    return value


def verify(directory:Path):
    run=json.loads((directory/"evaluation_run.json").read_text(encoding="utf-8"))
    if run["status"]!="COMPLETE": raise ValueError("Reproduction did not complete")
    for name,digest in run["artifacts"].items():
        if hashlib.sha256((directory/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f"Run artifact checksum mismatch: {name}")
    for name in ("scenario_results.csv","weekly_results.csv"):
        if (directory/name).read_bytes()!=(ROOT/"outputs"/name).read_bytes():
            raise ValueError(f"Analytical result mismatch: {name}")
    before=json.loads((ROOT/"outputs/browser_payload.json").read_text(encoding="utf-8"))
    after=json.loads((directory/"browser_payload.json").read_text(encoding="utf-8"))
    if analytical_payload(before)!=analytical_payload(after):
        raise ValueError("Analytical browser-payload values differ")
    first=json.loads((ROOT/"outputs/stress_results.json").read_text(encoding="utf-8"))
    second=json.loads((directory/"stress_results.json").read_text(encoding="utf-8"))
    if first!=second: raise ValueError("Stress results differ")
    return {"status":"PASS","scenario_rows":72*4,"weekly_queue_rows":72*4*12*3,
            "analytical_csv_bytes_identical":True,"analytical_payload_equal":True,"stress_results_equal":True,
            "timestamps":"Each run retains distinct actual timestamps and validation provenance"}


if __name__=="__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("directory",type=Path)
    print(json.dumps(verify(parser.parse_args().directory.resolve())))
