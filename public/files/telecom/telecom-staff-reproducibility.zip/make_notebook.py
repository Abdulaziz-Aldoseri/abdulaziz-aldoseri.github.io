"""Build the portable explained notebook; public copy has no saved execution outputs."""
from pathlib import Path
import json
import textwrap

ROOT=Path(__file__).resolve().parent
cells=[]
def md(text): cells.append({"cell_type":"markdown","metadata":{},"source":textwrap.dedent(text).strip()+"\n"})
def code(text): cells.append({"cell_type":"code","metadata":{},"execution_count":None,"outputs":[],"source":textwrap.dedent(text).strip()+"\n"})

md("""
# Where should a limited casework team spend next week's time?

**An independent decision study by Abdulaziz Aldoseri.**

A hypothetical telecom complaint-casework team has limited staff with different skills. Before each week begins, it must allocate whole cross-trained employees across Billing and commercial, Service and technical, and Privacy workstreams. Dedicated specialists stay in their eligible workstream. Unprocessed cases carry into the next week.

The observed records are consumer submissions to the US Federal Communications Commission, **not an operator's contact-centre queue**. The source has no observed employees, handling times, completion times or actual backlog. Staff, skills and processing rates are explicit scenarios. A model case-processing slot is not proof of complaint resolution, customer satisfaction or an achieved response deadline.

The question is whether balanced queue coverage is worth a different allocation of scarce processing capacity. We compare a fixed staffing split, an adaptive workload split, a current-week exact balanced allocation and a current-week actual-intake reference. All policies have the same feasible staff pools and their own simulated backlogs.

**Source:** [Federal Communications Commission, CGB — Consumer Complaints Data](https://opendata.fcc.gov/Consumer/CGB-Consumer-Complaints-Data/3xyp-aqkj), public domain US Government work. Modifications: fixed Phone/Internet cohort, documented issue mapping and exclusions, UTC daily/weekly aggregation, and independent hypothetical staffing simulation. Consumer-selected allegations are not independently verified by FCC. No endorsement is implied.
""")
md("""
## 1. Open and verify the reproduction package

**Local:** extract the study ZIP and open this notebook beside `staff_model.py` and `package_manifest.json`. Use Python 3.10 or later; model and evaluation require only the standard library. This notebook installs nothing and makes no network request in local mode.

**Optional Google Colab:** upload this notebook and select the reproduction ZIP when prompted. The embedded helper checks paths, member types, bounded sizes and all manifest hashes before any archive code is imported. No Drive mount or package installation is performed. Original notebook bytes are checked at extraction; runtime checks permit saved output/parameter edits to the working notebook while still verifying code and data. Hosted Colab execution has not been verified in this release.

The ZIP contains aggregate intake, not ticket-level identifiers or contact fields. Checksums verify integrity, not publisher identity: obtain the ZIP from the study download link and compare its published hash. An existing nonempty extraction directory is not overwritten.
""")
code((ROOT/"notebook_setup.py").read_text(encoding="utf-8"))
code("""
import importlib.util
import json
import subprocess
import sys
import tempfile
import html

try:
    IN_COLAB = importlib.util.find_spec("google.colab") is not None
except (ModuleNotFoundError, ImportError):
    IN_COLAB = False
PROJECT = Path.cwd().resolve()
if not (PROJECT / "staff_model.py").is_file():
    extracted = PROJECT / "telecom-staff-reproduction"
    if (extracted / "staff_model.py").is_file():
        verify_package(extracted, allow_notebook_edits=True)
        PROJECT = extracted
    elif IN_COLAB:
        from google.colab import files
        upload = files.upload()
        if len(upload) != 1:
            raise ValueError("Upload exactly one study reproduction ZIP.")
        filename, contents = next(iter(upload.items()))
        if not filename.lower().endswith(".zip"):
            raise ValueError("Choose the reproduction ZIP.")
        PROJECT = safe_extract_package(contents, extracted)
    else:
        raise FileNotFoundError("Open this notebook in the extracted folder beside staff_model.py.")
if not (PROJECT / "package_manifest.json").is_file():
    raise FileNotFoundError("The reproduction package manifest is required.")
verified_files = verify_package(PROJECT, allow_notebook_edits=True)
sys.path.insert(0, str(PROJECT))
from staff_model import Scenario, SCALE, forecast, replay
from verify_reproduction import verify
payload = json.loads((PROJECT / "outputs/browser_payload.json").read_text(encoding="utf-8"))
try:
    from IPython.display import display, HTML
except ImportError:
    def HTML(value): return value
    def display(value): print(value)
def show_table(rows):
    if not rows: return
    headers = list(rows[0])
    table = '<table><thead><tr>' + ''.join('<th>'+html.escape(str(h))+'</th>' for h in headers) + '</tr></thead><tbody>'
    for row in rows:
        table += '<tr>' + ''.join('<td>'+html.escape(str(row[h]))+'</td>' for h in headers) + '</tr>'
    display(HTML(table+'</tbody></table>'))
print(f"Verified {len(verified_files)} files. Loaded {len(payload['scenarios'])} scenarios and {len(payload['weeks'])} held-out weeks.")
""")
md("""
## 2. Know which inputs are observed

The preparation admits 102,757 complaints from a broad 205,892-record Phone/Internet projection. It excludes 100,600 unwanted-call records, 2,433 junk-fax records and 102 records with no issue label. All 252 calendar dates have broad-source observations. The public package carries only aggregates and source hashes.

`ticket_created` is the fixed UTC submission timestamp. The separate floating publisher date and the consumer's reported occurrence date are not used for staffing arrival time. This is a retrospective event-time replay, assuming an internal planner can observe submitted intake before the next weekly cutoff. Historical API availability and revisions are unknown.

Training: 6 January–27 April 2025, 16 weeks. Validation: 28 April–22 June, 8 weeks. Test: 23 June–14 September, 12 weeks. Membership, splits, scenarios and default week were fixed before fitting. The source's later October completeness discontinuity is outside this bounded study.
""")
code("""
import csv
prep = json.loads((PROJECT / "DATA_PREPARATION.json").read_text(encoding="utf-8"))
with (PROJECT / "data/weekly_intake.csv").open(encoding="utf-8", newline="") as handle:
    weekly = list(csv.DictReader(handle))
assert len(weekly) == 36
assert [r['split'] for r in weekly] == ['training']*16 + ['validation']*8 + ['test']*12
show_table([{'Split': key, 'Weeks': value['weeks'], 'Billing': value['intake_by_queue'][0], 'Technical': value['intake_by_queue'][1], 'Privacy': value['intake_by_queue'][2]} for key, value in prep['by_split'].items()])
assert prep['independent_aggregate_reconciled'] and prep['zero_broad_source_dates'] == []
""")
md("""
## 3. Read the choices, objective and constraints

Controls select total staff, cross-trained share and processing-capacity multiplier. Base specialist slots are 60, 40 and 30 cases per staff-week. Cross-trained staff provide 80% of that rate. Dedicated skill proportions are 45%, 45% and 10%. Every one of these workforce values is hypothetical, not measured in the FCC data.

With F cross-trained employees, the model enumerates every integer allocation `(x_billing, x_technical, x_privacy)` with nonnegative entries summing to F. Dedicated specialists remain fixed. Queue capacity is pooled and floored once to whole-case slots.

Projected cases are the policy's own opening backlog plus the forecast. The objective first minimizes the largest projected unprocessed share among nonempty queues, then total projected remaining cases, then internal staff reallocation; queue order breaks remaining ties. Empty queues have zero share. Exact enumeration establishes one-week optimality at that common state, not full-horizon or cross-policy trajectory dominance.

At week end, process at most opening backlog plus actual intake, oldest cohorts first. Unprocessed cases carry forward separately for each policy. This weekly pooling abstraction does not establish an hourly rota, measured waits or actual resolution.
""")
md("""
## 4. Reproduce validation before held-out evaluation

Candidates are means of the preceding 1, 4, 8 or 13 complete weeks. The shared selected forecast is fixed by validation MAE, with smaller-window ties. It uses only earlier weeks. Hindsight instead receives actual current-week intake and is labelled separately; it is not a global bound.

The next cell runs a fresh validation and complete 72-scenario evaluation in a new directory. It checks input hashes, actual freeze times, validation sidecar and no-overwrite guards. The original results remain unchanged. The final comparison requires identical analytical CSV bytes, equal payload values and equal stress outputs while preserving honest new run timestamps/provenance hashes.
""")
code("""
RUN = Path(tempfile.mkdtemp(prefix="telecom-staff-reproduction-")) / "outputs"
for stage in ('validate', 'evaluate'):
    result = subprocess.run([sys.executable, str(PROJECT / 'pipeline.py'), stage, '--output', str(RUN)], cwd=PROJECT, text=True, capture_output=True, check=True)
    print(stage + ': completed')
reproduction_check = verify(RUN)
assert reproduction_check['status'] == 'PASS'
print(reproduction_check)
show_table([{'Prior weeks': v['window'], 'Validation MAE': round(v['mae'], 2)} for v in payload['forecastValidation']])
print('Frozen window:', payload['selectedForecastWindow'])
show_table([{'Prior weeks': v['window'], 'Test MAE': round(v['mae'], 2)} for v in payload['forecastTest']])
""")
md("""
## 5. Inspect a staff allocation and its full trajectory

Change the three scenario values and selected week below. The grid values match the interactive page. Selecting a week shows one point on a complete policy trajectory; it does not reset backlog or modify only that week. Policy backlogs differ because earlier allocations differ.

Use staff `{0,24,36,48,60,72}`, cross-trained percent `{0,25,50,100}` and capacity percent `{75,100,125}`. Week index 0 is the preselected first held-out week. Counts labelled backlog or processed are simulated inside this model.
""")
code("""
STAFF = 48
CROSS_TRAINED_PERCENT = 25
CAPACITY_PERCENT = 100
WEEK_INDEX = 0
key = f'{STAFF}-{CROSS_TRAINED_PERCENT}-{CAPACITY_PERCENT}'
selected = next((s for s in payload['scenarios'] if s['id'] == key), None)
if selected is None or not 0 <= WEEK_INDEX < len(payload['weeks']):
    raise ValueError('Choose a scenario/week from the evaluated grid.')
row = selected['policies']['optimized']['weeks'][WEEK_INDEX]
print('Week:', payload['weeks'][WEEK_INDEX], '| dedicated + flexible staff:', selected['dedicated'], '+', selected['flex'])
show_table([{'Queue': q['label'], 'Dedicated': row['dedicated'][i], 'Cross-trained': row['allocation'][i], 'Forecast intake': round(payload['forecastScaled'][WEEK_INDEX][i]/SCALE,2), 'Observed intake': row['actualIntake'][i], 'Opening backlog': row['openingBacklog'][i], 'Model slots': row['capacity'][i], 'Processed in model': row['processed'][i], 'Ending backlog': row['endBacklog'][i]} for i,q in enumerate(payload['queues'])])
show_table([{'Week': payload['weeks'][w], **{p: sum(selected['policies'][p]['weeks'][w]['endBacklog']) for p in ('fixed','adaptive','optimized','hindsight')}} for w in range(12)])
show_table([{'Policy': p, 'Ending backlog': r['summary']['endingBacklog'], 'Sum weekly backlog': r['summary']['cumulativeBacklog'], 'Mean worst share (%)': round(100*r['summary']['meanWorstShare'],2), 'Internal reallocations': r['summary']['reallocated']} for p,r in selected['policies'].items()])
""")
md("""
## 6. Retain trade-offs, weak results and failures

The default balanced policy has a lower mean worst-queue unprocessed share, but more total backlog than both baselines in all 12 weeks. Across the full grid, cumulative backlog is higher in 41 settings, lower in 4 and tied in 27 against each baseline. Its mean worst-queue share is worse in three settings against each baseline. These are scenario counts, not probabilities.

Validation selected last week, but the eight-week candidate later has lower held-out forecast error. That adverse diagnostic is retained without changing the chosen forecast. Increasing flexibility also incurs the assumed 80% processing-rate penalty; universal cross-training is not guaranteed to help.

Stress cases below are explicitly modified model scenarios. Zero staff conserves all cases; ample staff clears them. An absence changes actual available staff, and initial backlog or a surge can persist through the horizon. The original forecast path is held fixed in the exogenous surge case.
""")
code("""
show_table([{'Stress': name, 'Balanced ending backlog': value['policies']['optimized']['endingBacklog'], 'Fixed ending backlog': value['policies']['fixed']['endingBacklog'], 'Balanced mean worst share (%)': round(value['policies']['optimized']['meanWorstShare']*100,2)} for name,value in payload['stressSummaries'].items()])
print('Whole-grid comparisons:', payload['evaluationSummary']['againstBaselines'])
for s in payload['scenarios']:
    for p, policy in s['policies'].items():
        for r in policy['weeks']:
            assert sum(r['allocation']) == s['flex']
            assert all(r['openingBacklog'][q] + r['actualIntake'][q] == r['processed'][q] + r['endBacklog'][q] for q in range(3))
print('All 72 × 12 × 4 staff/case conservation records checked.')
""")
md("""
## 7. Verify implementation and keep the decision in scope

Tests challenge the model with an independent labelled-person assignment oracle, exact fractional objectives, zero queues, skill loss, FIFO carryover, integer pool changes, absence/return, no future forecast data and freeze tampering. Tests establish the implementation's stated behavior; they do not certify a workforce recommendation.

The useful decision is to state the priority clearly: balanced queue coverage can be worth reduced total throughput, but an allocation model cannot erase an underlying capacity shortage. Before applying this structure to an actual operator, replace the hypothetical staff skills and processing rates with appropriate operational evidence and evaluate that different decision context.

See `METHODS.md`, `RESULTS.md`, `PROTOCOL.json` and the source register for exact definitions, full adverse results and provenance. Source attribution belongs with any exported chart/table: Federal Communications Commission, CGB — Consumer Complaints Data, public domain US Government work; independent aggregation and hypothetical staffing model.
""")
code("""
tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(PROJECT / 'tests'), '-v'], cwd=PROJECT, text=True, capture_output=True, check=True)
print(tests.stderr or tests.stdout)
print('Completed: clean reproduction, scenario inspection and independent-oracle tests. Hosted Colab UI was not part of this local check.')
""")

notebook={"cells":cells,"metadata":{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"},"language_info":{"name":"python","version":"3.12"}},"nbformat":4,"nbformat_minor":5}
for index,cell in enumerate(cells): cell["id"]=f"telecom-{index:02d}"
(ROOT/"telecom_staff.ipynb").write_text(json.dumps(notebook,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(f"Created notebook with {len(cells)} cells; outputs empty.")
