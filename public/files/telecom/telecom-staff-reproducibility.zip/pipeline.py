"""Freeze chronological validation, then evaluate all scenario policies from immutable aggregates."""
from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import itertools
import json
from fractions import Fraction
from pathlib import Path
from staff_model import Scenario,SCALE,BASE,POLICIES,QUEUES,forecast,replay

ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT/"outputs"
INPUT_FILES=("PROTOCOL.json","source_manifest.json","DATA_PREPARATION.json","REVIEW_GATE.json",
             "data/daily_intake.csv","data/weekly_intake.csv","staff_model.py","pipeline.py")


def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path:Path,value)->None:
    path.parent.mkdir(exist_ok=True,parents=True)
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite frozen/completed artifact: {path}")
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def load():
    protocol=json.loads((ROOT/"PROTOCOL.json").read_text(encoding="utf-8"))
    gate=json.loads((ROOT/"REVIEW_GATE.json").read_text(encoding="utf-8"))
    prep=json.loads((ROOT/"DATA_PREPARATION.json").read_text(encoding="utf-8"))
    if gate.get("status")!="PASS" or gate["protocol_sha256"]!=sha(ROOT/"PROTOCOL.json"):
        raise ValueError("Independent protocol/preparation review gate has not passed these protocol bytes")
    if prep["protocol_sha256"]!=sha(ROOT/"PROTOCOL.json") or prep["source_manifest_sha256"]!=sha(ROOT/"source_manifest.json"):
        raise ValueError("Preparation inputs changed after inspection")
    if gate["preparation_sha256"]!=sha(ROOT/"DATA_PREPARATION.json"):
        raise ValueError("Prepared-data review does not match these bytes")
    for item in prep["prepared_files"]:
        if item["file"] not in ("daily_intake.csv","weekly_intake.csv"):
            raise ValueError("Unexpected prepared data file")
        if sha(ROOT/"data"/item["file"])!=item["sha256"]:
            raise ValueError("Prepared source data changed")
    with (ROOT/"data/weekly_intake.csv").open(encoding="utf-8",newline="") as handle:
        rows=list(csv.DictReader(handle))
    weeks=[r["week_start_utc"] for r in rows]
    history=[tuple(int(r[q]) for q in QUEUES) for r in rows]
    if len(rows)!=36 or [r["split"] for r in rows]!=["training"]*16+["validation"]*8+["test"]*12:
        raise ValueError("Frozen calendar partition mismatch")
    hashes={name:sha(ROOT/name) for name in INPUT_FILES}
    return protocol,gate,history,weeks,hashes


def candidate_scores(protocol,history):
    candidates=[]
    for window in protocol["forecast"]["candidates_previous_calendar_weeks"]:
        errors=[sum(abs(forecast(history,w,window)[q]-SCALE*history[w][q]) for w in range(16,24)) for q in range(3)]
        candidates.append({"window":window,"absoluteErrorScaledByQueue":errors,"absoluteErrorScaled":sum(errors),
                           "mae":sum(errors)/(SCALE*8*3),"maeByQueue":[e/(SCALE*8) for e in errors]})
    return candidates


def validate():
    if OUTPUT.exists() and any(OUTPUT.iterdir()):
        raise FileExistsError("Validation requires an empty output directory; use a new directory for reproduction")
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    protocol,gate,history,weeks,hashes=load()
    candidates=candidate_scores(protocol,history)
    selected=min(candidates,key=lambda row:(row["absoluteErrorScaled"],row["window"]))["window"]
    if load()[-1]!=hashes:
        raise ValueError("Inputs changed during validation; nothing frozen")
    completed=dt.datetime.now(dt.timezone.utc).isoformat()
    result={"status":"validation-choice-frozen-before-test","frozen_utc":completed,
            "validation_started_utc":started,"validation_completed_utc":completed,
            "selectedWindow":selected,"validationWeeks":weeks[16:24],"candidates":candidates,
            "input_sha256":hashes,"protocolVersion":protocol["protocol_version"]}
    write(OUTPUT/"validation_freeze.json",result)
    write(OUTPUT/"validation_freeze.sha256.json",{"sha256":sha(OUTPUT/"validation_freeze.json"),"frozen_utc":completed,"input_sha256":hashes})
    print(json.dumps({"validation_frozen":True,"selected_window":selected,"candidates":candidates}))
    return result


def comparison(policies):
    opt=policies["optimized"]
    out={}
    for baseline in ("fixed","adaptive","hindsight"):
        other=policies[baseline]
        out[baseline]={"cumulativeBacklogDifference":opt["summary"]["cumulativeBacklog"]-other["summary"]["cumulativeBacklog"],
                       "endingBacklogDifference":opt["summary"]["endingBacklog"]-other["summary"]["endingBacklog"],
                       "meanWorstShareDifference":opt["summary"]["meanWorstShare"]-other["summary"]["meanWorstShare"],
                       "higherBacklogWeeks":sum(sum(a["endBacklog"])>sum(b["endBacklog"]) for a,b in zip(opt["weeks"],other["weeks"])),
                       "higherWorstShareWeeks":sum(a["maxUnprocessedShare"]>b["maxUnprocessedShare"]+1e-12 for a,b in zip(opt["weeks"],other["weeks"]))}
    return out


def evaluate():
    reserved=("browser_payload.json","test_metrics.json","stress_results.json","scenario_results.csv","weekly_results.csv","evaluation_run.json")
    if any((OUTPUT/name).exists() for name in reserved):
        raise FileExistsError("Evaluation already has outputs; use a new output directory for reproduction")
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    protocol,gate,history,weeks,hashes=load()
    freeze_hash=sha(OUTPUT/"validation_freeze.json")
    sidecar_hash=sha(OUTPUT/"validation_freeze.sha256.json")
    sidecar=json.loads((OUTPUT/"validation_freeze.sha256.json").read_text(encoding="utf-8"))
    frozen=json.loads((OUTPUT/"validation_freeze.json").read_text(encoding="utf-8"))
    if sidecar["sha256"]!=freeze_hash or sidecar["input_sha256"]!=hashes or frozen["input_sha256"]!=hashes:
        raise ValueError("Code/data changed after validation freeze; explicit reviewed revision is required")
    expected_candidates=candidate_scores(protocol,history)
    expected_window=min(expected_candidates,key=lambda row:(row["absoluteErrorScaled"],row["window"]))["window"]
    if frozen["candidates"]!=expected_candidates or frozen["selectedWindow"]!=expected_window:
        raise ValueError("Frozen validation values fail exact independent source recomputation")
    window=frozen["selectedWindow"]
    actual=history[24:]
    predicted=[forecast(history,w,window) for w in range(24,36)]
    train_totals=[sum(row[q] for row in history[:16]) for q in range(3)]
    training_weights=[Fraction(train_totals[q],BASE[q]) for q in range(3)]
    scenarios=[]
    workforce=protocol["workforce_scenario"]
    for count,flex_percent,capacity_percent in itertools.product(workforce["staff_counts"],workforce["cross_trained_percentages"],workforce["capacity_percentages"]):
        scenario=Scenario(count,flex_percent,capacity_percent)
        policies={p:replay(actual,predicted,scenario,training_weights,p) for p in POLICIES}
        scenarios.append({"id":scenario.key,"staff":count,"crossTrainedPercent":flex_percent,"capacityPercent":capacity_percent,
                          "dedicated":list(scenario.dedicated),"flex":scenario.flex,"policies":policies,"comparisons":comparison(policies)})
    stresses={}
    for name,spec in protocol["evaluation"]["stress_cases"].items():
        scenario=Scenario(spec["staff"],spec["cross_trained_percent"],spec["capacity_percent"])
        observed=list(actual); estimates=list(predicted); kwargs={}
        if name=="zero_intake":
            observed=[(0,0,0)]*12; estimates=[(0,0,0)]*12
        if name=="technical_specialists_absent": kwargs["absent_dedicated_queue"]=1
        if name=="unexpected_surge":
            index=weeks[24:].index(spec["week"])
            observed[index]=tuple(x*spec["actual_multiplier_all_queues"] for x in observed[index])
        if name=="flex_absence": kwargs["absent_flex_week"]=weeks[24:].index(spec["week"])
        if name=="opening_backlog": kwargs["initial_backlog"]=tuple((v+15)//16 for v in train_totals)
        policies={p:replay(observed,estimates,scenario,training_weights,p,**kwargs) for p in POLICIES}
        stresses[name]={"description":spec,"policies":policies,"comparisons":comparison(policies)}
    candidate_test=[]
    for n in protocol["forecast"]["candidates_previous_calendar_weeks"]:
        errors=[sum(abs(forecast(history,w,n)[q]-SCALE*history[w][q]) for w in range(24,36)) for q in range(3)]
        candidate_test.append({"window":n,"mae":sum(errors)/(SCALE*12*3),"maeByQueue":[e/(SCALE*12) for e in errors]})
    summary={"scenarioCount":len(scenarios),"weeksPerScenario":12,"policiesPerScenario":4,
             "selectedForecastWindow":window,"heldoutForecastCandidates":candidate_test,
             "input_sha256":hashes,"validation_sha256":sha(OUTPUT/"validation_freeze.json"),
             "defaultScenario":"48-25-100","defaultWeek":weeks[24],
             "againstBaselines":{p:{"higherCumulativeBacklogScenarios":sum(s["comparisons"][p]["cumulativeBacklogDifference"]>0 for s in scenarios),
                                      "lowerCumulativeBacklogScenarios":sum(s["comparisons"][p]["cumulativeBacklogDifference"]<0 for s in scenarios),
                                      "equalCumulativeBacklogScenarios":sum(s["comparisons"][p]["cumulativeBacklogDifference"]==0 for s in scenarios),
                                      "higherMeanWorstShareScenarios":sum(s["comparisons"][p]["meanWorstShareDifference"]>1e-12 for s in scenarios)} for p in ("fixed","adaptive")}}
    default=next(s for s in scenarios if s["id"]==summary["defaultScenario"])
    summary["default"]={"policies":{p:default["policies"][p]["summary"] for p in POLICIES},"comparisons":default["comparisons"]}
    payload={"schemaVersion":"1.0","projectId":"telecom-staff","title":"Where should a limited casework team spend next week's time?",
             "source":{"publisher":"Federal Communications Commission","title":"CGB — Consumer Complaints Data",
                       "url":protocol["source"]["dataset_url"],"license":"Public domain US Government work",
                       "credit":"Source: Federal Communications Commission, CGB — Consumer Complaints Data.",
                       "boundary":"Consumer-submitted Phone/Internet complaint intake to the US regulator, not an operator contact-centre queue; allegations are not independently verified.",
                       "period":"6 January–14 September 2025; weekly UTC aggregation"},
             "assumptions":{"baseCasesPerSpecialistWeek":list(BASE),"specialistSharePercent":[45,45,10],"crossTrainedEfficiencyPercent":80,
                            "capacityUnit":"Hypothetical case-processing slots per staff-week; no observed handling time or resolution outcome",
                            "backlog":"Simulated one-stage FIFO backlog; clean start, weekly pooling, retained terminal backlog",
                            "objective":"Minimize worst projected unprocessed share, then remaining cases and internal staff reallocation",
                            "hindsight":"Current-week actual-intake comparison, not a global horizon bound",
                            "interaction":"All scenario results are precomputed from the frozen evaluation"},
             "queues":[{"id":q["id"],"label":q["label"]} for q in protocol["queues"]],
             "weeks":weeks[24:],"observed":actual,"forecastScaled":predicted,"forecastScale":SCALE,
             "selectedForecastWindow":window,"forecastValidation":frozen["candidates"],"forecastTest":candidate_test,
             "controls":{"staff":workforce["staff_counts"],"crossTrainedPercent":workforce["cross_trained_percentages"],"capacityPercent":workforce["capacity_percentages"]},
             "default":{"scenarioId":"48-25-100","weekIndex":0},"scenarios":scenarios,
             "evaluationSummary":summary,
             "stressSummaries":{k:{"description":v["description"],"policies":{p:v["policies"][p]["summary"] for p in POLICIES},"comparisons":v["comparisons"]} for k,v in stresses.items()}}
    if load()[-1]!=hashes or sha(OUTPUT/"validation_freeze.json")!=freeze_hash or sha(OUTPUT/"validation_freeze.sha256.json")!=sidecar_hash:
        raise ValueError("Inputs or validation freeze changed during evaluation; no evaluated outputs written")
    write(OUTPUT/"browser_payload.json",payload)
    write(OUTPUT/"test_metrics.json",summary)
    write(OUTPUT/"stress_results.json",stresses)
    with (OUTPUT/"scenario_results.csv").open("w",encoding="utf-8",newline="") as handle:
        writer=csv.writer(handle,lineterminator="\n")
        cols=["cumulativeBacklog","endingBacklog","totalProcessed","unusedCapacity","meanWorstShare","worstShare","oldestAge","reallocated"]
        writer.writerow(["scenario_id","staff","cross_trained_percent","capacity_percent","policy",*cols])
        for s in scenarios:
            for policy in POLICIES:
                writer.writerow([s["id"],s["staff"],s["crossTrainedPercent"],s["capacityPercent"],policy,*[s["policies"][policy]["summary"][c] for c in cols]])
    with (OUTPUT/"weekly_results.csv").open("w",encoding="utf-8",newline="") as handle:
        writer=csv.writer(handle,lineterminator="\n")
        writer.writerow(["scenario_id","policy","week_start_utc","queue","dedicated_staff","flex_staff","actual_intake","opening_backlog","capacity","processed","ending_backlog","older_backlog","unprocessed_share"])
        for s in scenarios:
            for policy in POLICIES:
                for w,row in enumerate(s["policies"][policy]["weeks"]):
                    for q,queue in enumerate(QUEUES):
                        writer.writerow([s["id"],policy,weeks[24+w],queue,row["dedicated"][q],row["allocation"][q],row["actualIntake"][q],row["openingBacklog"][q],row["capacity"][q],row["processed"][q],row["endBacklog"][q],row["olderBacklog"][q],row["unprocessedShares"][q]])
    if load()[-1]!=hashes or sha(OUTPUT/"validation_freeze.json")!=freeze_hash or sha(OUTPUT/"validation_freeze.sha256.json")!=sidecar_hash:
        raise ValueError("Inputs changed while writing outputs; evaluation is not certified complete")
    completed=dt.datetime.now(dt.timezone.utc).isoformat()
    write(OUTPUT/"evaluation_run.json",{"status":"COMPLETE","evaluation_started_utc":started,"evaluation_completed_utc":completed,
                                       "input_sha256":hashes,"validation_sha256":freeze_hash,"validation_sidecar_sha256":sidecar_hash,
                                       "artifacts":{name:sha(OUTPUT/name) for name in reserved if name!="evaluation_run.json"}})
    print(json.dumps({"evaluated":True,"scenarios":len(scenarios),"default":summary["default"],"adverse":summary["againstBaselines"]}))
    return payload


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("stage",choices=["validate","evaluate"])
    parser.add_argument("--output",type=Path,help="Empty directory for a distinct reproduction run; original outputs are never overwritten")
    args=parser.parse_args()
    if args.output is not None: OUTPUT=args.output.resolve()
    if args.stage=="validate": validate()
    else: evaluate()
