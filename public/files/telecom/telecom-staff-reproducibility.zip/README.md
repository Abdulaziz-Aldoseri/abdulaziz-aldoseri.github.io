# Telecom complaint-casework staffing

An independent Decision Science and Analytics project by Abdulaziz Aldoseri.

Allocate whole cross-trained staff assignments across Billing and commercial, Service and technical, and Privacy workstreams before next week's intake is known. The model compares balanced queue coverage with two simple feasible staffing policies and a current-week hindsight reference.

Observed inputs are telecom complaints submitted to the US Federal Communications Commission. Staff, skills, processing rates and backlog are hypothetical model quantities. The data is regulator intake, not an operator contact-centre log; it contains no measured handling time or complaint-resolution outcome.

## Reproduce

Use Python 3.10 or later. The model, preparation and evaluation need only the Python standard library. Open `telecom_staff.ipynb` beside the extracted project files for the explained workflow. Optional Colab upload is supported by the notebook's checked ZIP extraction helper; hosted Colab itself has not been verified.

From the extracted folder:

```text
python -m unittest discover -s tests -v
python pipeline.py validate --output reproduction-output
python pipeline.py evaluate --output reproduction-output
python verify_reproduction.py reproduction-output
```

Choose a new output directory for each run. Existing results are never overwritten. Validation and evaluation timestamps differ between runs; the analytical scenario/weekly CSVs must match exactly. `verify_reproduction.py` checks those CSVs and analytical payload values while retaining each run's distinct provenance hashes and timestamps.

The ZIP contains prepared aggregates, model/pipeline, frozen protocol, review/input guards, evaluated results, tests and this notebook. It contains no ticket-level records, phone numbers, addresses, staff identities or private career documents. `retrieve_sources.py` documents the optional original public projection retrieval; original raw pages are not required to reproduce from the verified aggregates. Source records may later be revised, so a fresh download is not guaranteed to have the archived hashes.

## Read the evidence

- `METHODS.md`: decision context, source limitations, equations, baselines and replay timing.
- `PROTOCOL.json`: fixed chronology, scenario grid, objectives and stress cases.
- `source_manifest.json` and `DATA_PREPARATION.json`: attribution, exact resources, source hashes and exclusions.
- `RESULTS.md`: evaluated comparisons, adverse cases and interpretation.
- `outputs/validation_freeze.json`: forecast choice frozen before held-out decisions.
- `outputs/scenario_results.csv` and `outputs/weekly_results.csv`: complete evaluated grid.
- `outputs/stress_results.json`: explicitly simulated failure and stress cases.

Source: [Federal Communications Commission, CGB — Consumer Complaints Data](https://opendata.fcc.gov/Consumer/CGB-Consumer-Complaints-Data/3xyp-aqkj), public domain US Government work. Aggregation and the staffing model are independent modifications. Consumer-selected allegations are not independently verified by FCC. No endorsement or realized organizational impact is implied.
