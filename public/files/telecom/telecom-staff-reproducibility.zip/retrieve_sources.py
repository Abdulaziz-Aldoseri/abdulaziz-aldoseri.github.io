"""Retrieve only the four required FCC fields; keep original response bytes private."""
from __future__ import annotations
import concurrent.futures
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
BASE = "https://opendata.fcc.gov/resource/3xyp-aqkj.csv"
META = "https://opendata.fcc.gov/api/views/3xyp-aqkj.json"


def get(url: str, filename: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "Independent decision study source audit; public FCC data"})
    with urllib.request.urlopen(req, timeout=90) as response:
        blob = response.read()
        headers = {k: response.headers.get(k) for k in ("Content-Type", "ETag", "Last-Modified")}
    path = SOURCE / filename
    if path.exists() and path.read_bytes() != blob:
        raise RuntimeError(f"Refusing to overwrite different original source bytes: {filename}")
    path.write_bytes(blob)
    return {"file": filename, "url": url, "bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest(),
            "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "response_headers": headers}


def main() -> None:
    SOURCE.mkdir(exist_ok=True)
    before = get(META, "fcc-metadata-before.json")
    boundaries = ["2025-01-06", "2025-02-01", "2025-03-01", "2025-04-01", "2025-05-01",
                  "2025-06-01", "2025-07-01", "2025-08-01", "2025-09-01", "2025-09-15"]
    jobs = []
    for start, end in zip(boundaries, boundaries[1:]):
        where = f"ticket_created >= '{start}T00:00:00Z' AND ticket_created < '{end}T00:00:00Z' AND issue_type in ('Phone','Internet')"
        query = {"$select": "id,ticket_created,issue_type,issue", "$where": where,
                 "$order": "ticket_created,id", "$limit": "50000"}
        jobs.append((BASE + "?" + urllib.parse.urlencode(query), f"fcc-{start}-to-{end}.csv"))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        files = list(pool.map(lambda args: get(*args), jobs))
    where = "ticket_created >= '2025-01-06T00:00:00Z' AND ticket_created < '2025-09-15T00:00:00Z' AND issue_type in ('Phone','Internet')"
    query = {"$select": "count(*) as records,count(distinct id) as distinct_ids,min(ticket_created) as first_created,max(ticket_created) as last_created", "$where": where}
    counts = get(BASE.replace(".csv", ".json") + "?" + urllib.parse.urlencode(query), "fcc-exact-window-counts.json")
    after = get(META, "fcc-metadata-after.json")
    a = json.loads((SOURCE / before["file"]).read_bytes())
    b = json.loads((SOURCE / after["file"]).read_bytes())
    if a.get("rowsUpdatedAt") != b.get("rowsUpdatedAt"):
        raise RuntimeError("FCC data changed while retrieving pages; retain originals but do not admit as one snapshot")
    manifest = {"publisher": "Federal Communications Commission", "dataset_id": "3xyp-aqkj",
                "license_id": a.get("licenseId"), "source_version_rows_updated_epoch": a.get("rowsUpdatedAt"),
                "source_version_utc": dt.datetime.fromtimestamp(a["rowsUpdatedAt"], dt.timezone.utc).isoformat(),
                "same_metadata_version_before_and_after": True,
                "projection": ["id", "ticket_created", "issue_type", "issue"],
                "privacy": "No telephone, address, location, provider, employee or free-text narrative fields retrieved.",
                "coverage": "2025-01-06T00:00:00Z <= ticket_created < 2025-09-15T00:00:00Z; Phone/Internet",
                "files": [before, *files, counts, after]}
    (ROOT / "source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"files": len(files), "bytes": sum(f["bytes"] for f in files), "stable_source_version": manifest["source_version_utc"]}))


if __name__ == "__main__":
    main()
