"""Exact integer allocation and weekly FIFO replay, using only Python's standard library."""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import product
from typing import Sequence

SCALE = 104
BASE = (60, 40, 30)
QUEUES = ("billing", "technical", "privacy")
POLICIES = ("fixed", "adaptive", "optimized", "hindsight")


def integer(value, name: str, low: int = 0, high: int = 100000000) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ValueError(f"{name} must be an integer in [{low}, {high}]")
    return value


def vector(values: Sequence[int], name: str) -> tuple[int, int, int]:
    if len(values) != 3:
        raise ValueError(f"{name} needs exactly three queues")
    return tuple(integer(x, name) for x in values)


def apportion(total: int, weights: Sequence) -> tuple[int, int, int]:
    integer(total, "staff", high=1000)
    if len(weights) != 3:
        raise ValueError("three apportionment weights required")
    weights = tuple(Fraction(x) for x in weights)
    if any(x < 0 for x in weights):
        raise ValueError("negative apportionment weight")
    if sum(weights) == 0:
        weights = (Fraction(1),) * 3
    targets = [total * x / sum(weights) for x in weights]
    result = [t.numerator // t.denominator for t in targets]
    order = sorted(range(3), key=lambda q: (-(targets[q] - result[q]), q))
    for q in order[:total - sum(result)]:
        result[q] += 1
    return tuple(result)


@dataclass(frozen=True)
class Scenario:
    staff: int
    cross_trained_percent: int
    capacity_percent: int

    def __post_init__(self):
        integer(self.staff, "staff", high=1000)
        integer(self.cross_trained_percent, "cross trained percent", high=100)
        integer(self.capacity_percent, "capacity percent", low=1, high=1000)

    @property
    def flex(self) -> int:
        return self.staff * self.cross_trained_percent // 100

    @property
    def dedicated(self) -> tuple[int, int, int]:
        return apportion(self.staff - self.flex, (45, 45, 10))

    @property
    def key(self) -> str:
        return f"{self.staff}-{self.cross_trained_percent}-{self.capacity_percent}"


def capacities(scenario: Scenario, dedicated: Sequence[int], allocation: Sequence[int]) -> tuple[int, int, int]:
    dedicated, allocation = vector(dedicated, "dedicated staff"), vector(allocation, "flex allocation")
    return tuple(BASE[q] * scenario.capacity_percent * (100*dedicated[q] + 80*allocation[q]) // 10000 for q in range(3))


def movement(allocation: Sequence[int], previous: Sequence[int]) -> dict:
    allocation, previous = vector(allocation, "allocation"), vector(previous, "previous allocation")
    difference = sum(allocation) - sum(previous)
    l1 = sum(abs(a-b) for a,b in zip(allocation, previous))
    assert (l1 - abs(difference)) % 2 == 0
    return {"reallocated": (l1-abs(difference))//2, "entrants": max(difference,0), "absent": max(-difference,0)}


@lru_cache(maxsize=128)
def feasible_actions(scenario: Scenario, dedicated: tuple, flex: int) -> tuple:
    integer(flex, "available flex", high=1000)
    return tuple(((a,b,flex-a-b), capacities(scenario,dedicated,(a,b,flex-a-b)))
                 for a in range(flex+1) for b in range(flex-a+1))


def exact_allocation(projected_scaled: Sequence[int], scenario: Scenario, previous=(0,0,0),
                     dedicated=None, flex=None) -> tuple[int, int, int]:
    need = vector(projected_scaled, "projected cases scaled")
    previous = vector(previous, "previous allocation")
    dedicated = vector(scenario.dedicated if dedicated is None else dedicated, "dedicated")
    flex = scenario.flex if flex is None else integer(flex,"available flex",high=1000)
    best = None
    for allocation, capacity in feasible_actions(scenario,dedicated,flex):
        remaining = tuple(max(0,need[q]-SCALE*capacity[q]) for q in range(3))
        numer,denom = 0,1
        for r,d in zip(remaining,need):
            if d and r*denom > numer*d:
                numer,denom = r,d
        changes = movement(allocation,previous)["reallocated"]
        secondary = (sum(remaining),changes,allocation)
        if best is None or numer*best[1] < best[0]*denom or (numer*best[1] == best[0]*denom and secondary < best[2]):
            best = (numer,denom,secondary,allocation)
    assert best is not None
    return best[3]


def choose(policy: str, projected_scaled: Sequence[int], scenario: Scenario, training_weights: Sequence,
           previous: Sequence[int], dedicated: Sequence[int], flex: int) -> tuple[int,int,int]:
    need = vector(projected_scaled,"projected cases")
    if policy == "fixed":
        return apportion(flex,training_weights)
    if policy == "adaptive":
        dedicated_capacity = capacities(scenario,dedicated,(0,0,0))
        weights = [Fraction(max(0,need[q]-SCALE*dedicated_capacity[q]),BASE[q]) for q in range(3)]
        if sum(weights) > 0:
            return apportion(flex,weights)
        if sum(previous) == flex:
            return tuple(previous)
        return apportion(flex,previous if sum(previous) else training_weights)
    if policy in ("optimized","hindsight"):
        return exact_allocation(need,scenario,previous,dedicated,flex)
    raise ValueError(f"Unknown policy {policy}")


def forecast(history: Sequence[Sequence[int]], index: int, window: int) -> tuple[int,int,int]:
    if window not in (1,4,8,13) or index < window or index > len(history):
        raise ValueError("Invalid forecast history/window")
    history = [vector(r,"observed intake") for r in history[index-window:index]]
    return tuple(sum(r[q] for r in history) * (SCALE//window) for q in range(3))


def replay(actual: Sequence[Sequence[int]], forecast_scaled: Sequence[Sequence[int]], scenario: Scenario,
           training_weights: Sequence, policy: str, initial_backlog=(0,0,0), absent_flex_week=None,
           absent_dedicated_queue=None) -> dict:
    if len(actual) != len(forecast_scaled) or not actual:
        raise ValueError("matching nonempty actual/forecast weeks required")
    initial = vector(initial_backlog,"initial backlog")
    actual = [vector(row,"actual intake") for row in actual]
    forecast_scaled = [vector(row,"forecast") for row in forecast_scaled]
    cohorts = [[[-1,initial[q]]] if initial[q] else [] for q in range(3)]
    previous = (0,0,0)
    rows = []
    for week, (intake, forecast_row) in enumerate(zip(actual,forecast_scaled)):
        opening = tuple(sum(c[1] for c in cohorts[q]) for q in range(3))
        projected = tuple(SCALE*opening[q] + (SCALE*intake[q] if policy == "hindsight" else forecast_row[q]) for q in range(3))
        dedicated = list(scenario.dedicated)
        removed = 0
        if absent_dedicated_queue is not None:
            q = integer(absent_dedicated_queue,"absent dedicated queue",high=2)
            removed = dedicated[q]
            dedicated[q] = 0
        flex = scenario.flex - (1 if week == absent_flex_week and scenario.flex else 0)
        allocation = choose(policy,projected,scenario,training_weights,previous,dedicated,flex)
        if sum(allocation) != flex:
            raise AssertionError("Staff conservation failed")
        capacity = capacities(scenario,dedicated,allocation)
        processed, remaining, older, ages = [],[],[],[]
        for q in range(3):
            cohorts[q].append([week,intake[q]])
            left = capacity[q]
            for cohort in cohorts[q]:
                take = min(cohort[1],left)
                cohort[1] -= take
                left -= take
            cohorts[q] = [cohort for cohort in cohorts[q] if cohort[1]]
            remaining.append(sum(c[1] for c in cohorts[q]))
            older.append(sum(c[1] for c in cohorts[q] if c[0] < week))
            ages.append(max((week-c[0] for c in cohorts[q]),default=0))
            processed.append(capacity[q]-left)
            assert opening[q]+intake[q] == processed[q]+remaining[q]
        available = tuple(opening[q]+intake[q] for q in range(3))
        shares = [remaining[q]/available[q] if available[q] else 0 for q in range(3)]
        move = movement(allocation,previous)
        rows.append({"allocation":list(allocation),"dedicated":dedicated,"availableStaff":sum(dedicated)+flex,
                     "removedDedicatedStaff":removed,"capacity":list(capacity),"openingBacklog":list(opening),
                     "projectedScaled":list(projected),"actualIntake":list(intake),"processed":processed,
                     "endBacklog":remaining,"olderBacklog":older,"oldestAge":max(ages),"ageByQueue":ages,
                     "unprocessedShares":shares,"maxUnprocessedShare":max(shares),
                     "unusedCapacity":[capacity[q]-processed[q] for q in range(3)],**move})
        previous = allocation
    summary = {"cumulativeBacklog":sum(sum(r["endBacklog"]) for r in rows),
               "endingBacklog":sum(rows[-1]["endBacklog"]),"endingByQueue":rows[-1]["endBacklog"],
               "totalProcessed":sum(sum(r["processed"]) for r in rows),
               "unusedCapacity":sum(sum(r["unusedCapacity"]) for r in rows),
               "meanWorstShare":sum(r["maxUnprocessedShare"] for r in rows)/len(rows),
               "worstShare":max(r["maxUnprocessedShare"] for r in rows),
               "oldestAge":max(r["oldestAge"] for r in rows),
               "reallocated":sum(r["reallocated"] for r in rows)}
    assert sum(initial)+sum(sum(r) for r in actual) == summary["totalProcessed"]+summary["endingBacklog"]
    return {"weeks":rows,"summary":summary}
