import itertools
import random
import unittest
from fractions import Fraction
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from staff_model import Scenario, SCALE, apportion, capacities, exact_allocation, movement, forecast, replay, choose


class StaffModelTests(unittest.TestCase):
    def test_independent_person_assignment_oracle(self):
        rng = random.Random(14092026)
        for trial in range(90):
            flex = rng.randrange(7)
            scenario = Scenario(flex,100,rng.choice([75,100,125]))
            dedicated = tuple(rng.randrange(3) for _ in range(3))
            prior_labels = [rng.randrange(3) for _ in range(rng.randrange(7))]
            previous = tuple(prior_labels.count(q) for q in range(3))
            needed = tuple(rng.randrange(400)*104+rng.randrange(104) for _ in range(3))
            reference = None
            for labels in itertools.product(range(3),repeat=flex):
                allocation = tuple(labels.count(q) for q in range(3))
                capacity = []
                for q,base in enumerate([60,40,30]):
                    amount = Fraction(base*scenario.capacity_percent,100)*(dedicated[q]+Fraction(4,5)*allocation[q])
                    capacity.append(amount.numerator//amount.denominator)
                remain = [max(Fraction(needed[q],104)-capacity[q],0) for q in range(3)]
                share = max((remain[q]/Fraction(needed[q],104) if needed[q] else 0) for q in range(3))
                moves = (sum(abs(allocation[q]-previous[q]) for q in range(3))-abs(flex-sum(previous)))//2
                score = (share,sum(remain),moves,allocation)
                if reference is None or score < reference:
                    reference = score
            self.assertEqual(exact_allocation(needed,scenario,previous,dedicated,flex),reference[-1],trial)

    def test_staff_movement_absence_and_return_is_integer(self):
        self.assertEqual(movement((2,3,1),(3,3,1)),{"reallocated":0,"entrants":0,"absent":1})
        self.assertEqual(movement((3,3,1),(2,3,1)),{"reallocated":0,"entrants":1,"absent":0})
        self.assertEqual(movement((1,4,1),(3,3,1)),{"reallocated":1,"entrants":0,"absent":1})

    def test_adaptive_no_need_reapportions_after_absence(self):
        scenario=Scenario(10,100,100)
        allocation=choose("adaptive",(0,0,0),scenario,(2,2,1),(4,4,2),(0,0,0),9)
        self.assertEqual(sum(allocation),9)
        self.assertEqual(allocation,(4,3,2))

    def test_pooled_capacity_floored_once(self):
        self.assertEqual(capacities(Scenario(2,0,75),(0,0,2),(0,0,0))[2],45)
        self.assertEqual(capacities(Scenario(1,0,75),(0,0,1),(0,0,0))[2],22)

    def test_forecasts_do_not_read_current_or_future(self):
        history=[(q,q*2,0) for q in range(36)]
        result=forecast(history,24,13)
        changed=history[:24]+[(999999,999999,999999)]*12
        self.assertEqual(result,forecast(changed,24,13))
        self.assertEqual(result[0],sum(range(11,24))*8)

    def test_zero_staff_keeps_every_case_and_fifo_age(self):
        actual=[(10,4,1),(20,5,2),(30,6,3)]
        prediction=[tuple(x*SCALE for x in r) for r in actual]
        result=replay(actual,prediction,Scenario(0,100,100),(1,1,1),"optimized",initial_backlog=(2,0,0))
        self.assertEqual(result["summary"]["endingByQueue"],[62,15,6])
        self.assertEqual(result["summary"]["totalProcessed"],0)
        self.assertEqual(result["summary"]["oldestAge"],3)
        self.assertTrue(all(r["maxUnprocessedShare"]==1 for r in result["weeks"]))

    def test_zero_intake_no_backlog_or_undefined_shares(self):
        result=replay([(0,0,0)]*3,[(0,0,0)]*3,Scenario(12,25,100),(1,1,1),"optimized")
        self.assertEqual(result["summary"]["endingBacklog"],0)
        self.assertEqual(result["summary"]["meanWorstShare"],0)

    def test_all_policies_conserve_and_absence_feasible(self):
        actual=[(120,40,20),(20,110,50),(0,0,0),(30,35,4)]
        prediction=[tuple(x*SCALE for x in r) for r in actual]
        for policy in ("fixed","adaptive","optimized","hindsight"):
            result=replay(actual,prediction,Scenario(9,100,100),(2,3,1),policy,absent_flex_week=1)
            for w,r in enumerate(result["weeks"]):
                self.assertEqual(sum(r["allocation"]),8 if w==1 else 9)
                self.assertEqual(sum(r["openingBacklog"])+sum(actual[w]),sum(r["processed"])+sum(r["endBacklog"]))
            self.assertEqual(result["summary"]["endingBacklog"],0)

    def test_absent_skill_pool_reports_removed_staff(self):
        scenario=Scenario(12,0,100)
        result=replay([(50,50,50)],[(5200,5200,5200)],scenario,(1,1,1),"optimized",absent_dedicated_queue=1)
        row=result["weeks"][0]
        self.assertEqual(row["dedicated"][1],0)
        self.assertEqual(row["capacity"][1],0)
        self.assertEqual(row["endBacklog"][1],50)
        self.assertEqual(row["availableStaff"],12-scenario.dedicated[1])

    def test_invalid_inputs_fail(self):
        for args in [(-1,25,100),(12,101,100),(12,25,0),(True,25,100),(12.5,25,100)]:
            with self.assertRaises(ValueError): Scenario(*args)
        with self.assertRaises(ValueError): exact_allocation((-1,0,0),Scenario(2,100,100))
        with self.assertRaises(ValueError): apportion(2,[-1,0,1])
        with self.assertRaises(ValueError): forecast([(1,2,3)],1,4)
        with self.assertRaises(ValueError): replay([],[],Scenario(0,0,100),(1,1,1),"fixed")


if __name__ == "__main__":
    unittest.main()
