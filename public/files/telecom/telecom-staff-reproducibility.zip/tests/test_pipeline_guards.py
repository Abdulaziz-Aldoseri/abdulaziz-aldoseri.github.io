import contextlib
import io
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pipeline


class PipelineGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        original=Path(__file__).resolve().parents[1]
        for name in pipeline.INPUT_FILES:
            destination=self.root/name
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(original/name,destination)
        self.root_patch=patch.object(pipeline,"ROOT",self.root)
        self.output_patch=patch.object(pipeline,"OUTPUT",self.root/"outputs")
        self.root_patch.start(); self.output_patch.start()

    def tearDown(self):
        self.root_patch.stop(); self.output_patch.stop(); self.temp.cleanup()

    def validate(self):
        with contextlib.redirect_stdout(io.StringIO()): return pipeline.validate()

    def test_validation_refuses_overwrite(self):
        self.validate()
        before=(self.root/"outputs/validation_freeze.json").read_bytes()
        with self.assertRaises(FileExistsError): self.validate()
        self.assertEqual(before,(self.root/"outputs/validation_freeze.json").read_bytes())

    def test_changed_selected_window_rejected_before_test(self):
        result=self.validate()
        result["selectedWindow"]=4
        (self.root/"outputs/validation_freeze.json").write_text(json.dumps(result))
        with self.assertRaises(ValueError): pipeline.evaluate()
        self.assertFalse((self.root/"outputs/test_metrics.json").exists())

    def test_changed_selection_and_recomputed_sidecar_still_rejected(self):
        result=self.validate()
        path=self.root/"outputs/validation_freeze.json"
        result["selectedWindow"]=4
        path.write_text(json.dumps(result))
        sidepath=self.root/"outputs/validation_freeze.sha256.json"
        side=json.loads(sidepath.read_text())
        side["sha256"]=pipeline.sha(path)
        sidepath.write_text(json.dumps(side))
        with self.assertRaises(ValueError): pipeline.evaluate()

    def test_changed_prepared_data_rejected(self):
        self.validate()
        with (self.root/"data/weekly_intake.csv").open("a") as handle: handle.write("unexpected\n")
        with self.assertRaises(ValueError): pipeline.evaluate()

    def test_completed_output_refuses_new_evaluation(self):
        self.validate()
        marker=self.root/"outputs/test_metrics.json"
        marker.write_text("existing result")
        with self.assertRaises(FileExistsError): pipeline.evaluate()
        self.assertEqual(marker.read_text(),"existing result")

    def test_validation_rechecks_end_inputs(self):
        original_load=pipeline.load
        calls=0
        def changed():
            nonlocal calls
            calls+=1
            result=list(original_load())
            if calls==2: result[-1]={**result[-1],"pipeline.py":"changed"}
            return tuple(result)
        with patch.object(pipeline,"load",side_effect=changed):
            with self.assertRaises(ValueError): self.validate()
        self.assertFalse((self.root/"outputs/validation_freeze.json").exists())


if __name__=="__main__": unittest.main()
